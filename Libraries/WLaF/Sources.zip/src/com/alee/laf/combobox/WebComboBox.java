/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.combobox;

import com.alee.laf.WebLookAndFeel;
import com.alee.utils.ReflectUtils;
import com.alee.utils.laf.ShapeProvider;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;

/**
 * User: mgarin Date: 28.06.11 Time: 1:11
 */

public class WebComboBox extends JComboBox implements ShapeProvider
{
    public WebComboBox ()
    {
        super ();
    }

    public WebComboBox ( Vector<?> items )
    {
        super ( items );
    }

    public WebComboBox ( Object[] items )
    {
        super ( items );
    }

    public WebComboBox ( ComboBoxModel aModel )
    {
        super ( aModel );
    }

    public boolean isDrawBorder ()
    {
        return getWebUI ().isDrawBorder ();
    }

    public void setDrawBorder ( boolean drawBorder )
    {
        getWebUI ().setDrawBorder ( drawBorder );
    }

    public boolean isDrawFocus ()
    {
        return getWebUI ().isDrawFocus ();
    }

    public void setDrawFocus ( boolean drawFocus )
    {
        getWebUI ().setDrawFocus ( drawFocus );
    }

    public int getRound ()
    {
        return getWebUI ().getRound ();
    }

    public void setRound ( int round )
    {
        getWebUI ().setRound ( round );
    }

    public int getShadeWidth ()
    {
        return getWebUI ().getShadeWidth ();
    }

    public void setShadeWidth ( int shadeWidth )
    {
        getWebUI ().setShadeWidth ( shadeWidth );
    }

    public boolean isMouseWheelScrollingEnabled ()
    {
        return getWebUI ().isMouseWheelScrollingEnabled ();
    }

    public void setMouseWheelScrollingEnabled ( boolean enabled )
    {
        getWebUI ().setMouseWheelScrollingEnabled ( enabled );
    }

    public Shape provideShape ()
    {
        return getWebUI ().provideShape ();
    }

    public WebComboBoxCellRenderer getWebRenderer ()
    {
        return ( WebComboBoxCellRenderer ) getRenderer ();
    }

    public WebComboBoxUI getWebUI ()
    {
        return ( WebComboBoxUI ) getUI ();
    }

    public void updateUI ()
    {
        if ( getUI () == null || !( getUI () instanceof WebComboBoxUI ) )
        {
            try
            {
                setUI ( ( WebComboBoxUI ) ReflectUtils.createInstance ( WebLookAndFeel.comboBoxUI ) );
            }
            catch ( Throwable e )
            {
                e.printStackTrace ();
                setUI ( new WebComboBoxUI () );
            }
        }
        else
        {
            setUI ( getUI () );
        }
    }
}
