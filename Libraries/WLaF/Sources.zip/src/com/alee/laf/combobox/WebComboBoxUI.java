/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.combobox;

import com.alee.laf.StyleConstants;
import com.alee.laf.button.WebButton;
import com.alee.laf.combobox.icons.WebComboBoxStyle;
import com.alee.laf.scroll.WebScrollBarUI;
import com.alee.laf.scroll.WebScrollPaneUI;
import com.alee.laf.text.WebTextFieldUI;
import com.alee.utils.LafUtils;
import com.alee.utils.SwingUtils;
import com.alee.utils.laf.ShapeProvider;
import com.alee.utils.swing.WebDefaultCellEditor;
import sun.swing.DefaultLookup;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicComboPopup;
import javax.swing.plaf.basic.ComboPopup;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

/**
 * User: mgarin Date: 01.06.11 Time: 14:36
 */

public class WebComboBoxUI extends BasicComboBoxUI implements ShapeProvider
{
    public static ImageIcon DOWN_ICON = new ImageIcon ( WebComboBoxUI.class.getResource ( "icons/down.png" ) );

    private boolean drawBorder = WebComboBoxStyle.drawBorder;
    private int round = WebComboBoxStyle.round;
    private int shadeWidth = WebComboBoxStyle.shadeWidth;
    private boolean drawFocus = WebComboBoxStyle.drawFocus;
    private boolean mouseWheelScrollingEnabled = WebComboBoxStyle.mouseWheelScrollingEnabled;

    private MouseWheelListener mwl = null;

    public static ComponentUI createUI ( JComponent c )
    {
        return new WebComboBoxUI ();
    }

    public void installUI ( JComponent c )
    {
        super.installUI ( c );

        final JComboBox comboBox = ( JComboBox ) c;

        // Default settings
        SwingUtils.setOrientation ( comboBox );
        comboBox.setFocusable ( true );
        comboBox.setOpaque ( false );

        // Updating border
        updateBorder ();

        // Drfault renderer
        if ( !( comboBox.getRenderer () instanceof WebComboBoxCellRenderer ) )
        {
            comboBox.setRenderer ( new WebComboBoxCellRenderer ( comboBox ) );
        }

        // Rollover scrolling listener
        mwl = new MouseWheelListener ()
        {
            public void mouseWheelMoved ( MouseWheelEvent e )
            {
                if ( mouseWheelScrollingEnabled && comboBox.isEnabled () )
                {
                    int newIndex = Math.min ( Math.max ( 0, comboBox.getSelectedIndex () + e.getWheelRotation () ),
                            comboBox.getModel ().getSize () - 1 );
                    comboBox.setSelectedIndex ( newIndex );
                }
            }
        };
        comboBox.addMouseWheelListener ( mwl );
    }

    private void updateBorder ()
    {
        if ( drawBorder )
        {
            comboBox.setBorder ( BorderFactory.createEmptyBorder ( shadeWidth + 1, shadeWidth + 1, shadeWidth + 1, shadeWidth + 1 ) );
        }
        else
        {
            comboBox.setBorder ( null );
        }
    }

    public void uninstallUI ( JComponent c )
    {
        c.removeMouseWheelListener ( mwl );

        super.uninstallUI ( c );
    }

    protected void installComponents ()
    {
        comboBox.setLayout ( createLayoutManager () );

        arrowButton = createArrowButton ();
        comboBox.add ( arrowButton, "1,0" );
        if ( arrowButton != null )
        {
            configureArrowButton ();
        }

        if ( comboBox.isEditable () )
        {
            addEditor ();
        }

        comboBox.add ( currentValuePane, "0,0" );
    }

    protected ComboBoxEditor createEditor ()
    {
        final ComboBoxEditor editor = super.createEditor ();
        Component e = editor.getEditorComponent ();
        e.addFocusListener ( new FocusAdapter ()
        {
            public void focusGained ( FocusEvent e )
            {
                comboBox.repaint ();
            }

            public void focusLost ( FocusEvent e )
            {
                comboBox.repaint ();
            }
        } );
        if ( e instanceof JComponent )
        {
            ( ( JComponent ) e ).setOpaque ( false );
        }
        if ( e instanceof JTextField )
        {
            JTextField textField = ( JTextField ) e;
            textField.setUI ( new WebTextFieldUI ( textField, false ) );
            textField.setMargin ( new Insets ( 0, 1, 0, 1 ) );
        }
        return editor;
    }

    protected JButton createArrowButton ()
    {
        WebButton arrow = new WebButton ();
        arrow.setLeftRightSpacing ( 4 );
        arrow.setUndecorated ( true );
        arrow.setDrawFocus ( false );
        arrow.setMoveIconOnPress ( false );

        arrow.setName ( "ComboBox.arrowButton" );
        arrow.setIcon ( DOWN_ICON );

        return arrow;
    }

    public void configureArrowButton ()
    {
        super.configureArrowButton ();
        if ( arrowButton != null )
        {
            arrowButton.setFocusable ( false );
        }
    }

    protected ComboPopup createPopup ()
    {
        return new BasicComboPopup ( comboBox )
        {
            protected JScrollPane createScroller ()
            {
                JScrollPane scroll = super.createScroller ();
                scroll.setOpaque ( false );
                scroll.getViewport ().setOpaque ( false );

                WebScrollPaneUI scrollPaneUI = ( WebScrollPaneUI ) scroll.getUI ();
                scrollPaneUI.setDrawBorder ( false );

                WebScrollBarUI scrollBarUI = ( WebScrollBarUI ) scroll.getVerticalScrollBar ().getUI ();
                scrollBarUI.setScrollBorder ( scrollPaneUI.getDarkBorder () );

                return scroll;
            }

            protected JList createList ()
            {
                JList list = super.createList ();
                list.setOpaque ( false );
                return list;
            }

            public void show ()
            {
                // informing listeners
                comboBox.firePopupMenuWillBecomeVisible ();

                // Updating list selection
                setListSelection ( comboBox.getSelectedIndex () );

                // Updating popup size
                boolean cellEditor = isComboboxCellEditor ();
                setupPopupSize ( cellEditor );

                // Displaying popup
                ComponentOrientation orientation = comboBox.getComponentOrientation ();
                int sideShear = ( drawBorder ? shadeWidth : ( cellEditor ? -1 : 0 ) );
                int topShear = ( drawBorder ? shadeWidth : 0 ) - ( cellEditor ? 0 : 1 );
                show ( comboBox, orientation.isLeftToRight () ? sideShear : comboBox.getWidth () - getWidth () - sideShear,
                        comboBox.getHeight () - topShear );
            }

            private void setupPopupSize ( boolean cellEditor )
            {
                Dimension popupSize = comboBox.getSize ();
                if ( drawBorder )
                {
                    popupSize.width -= shadeWidth * 2;
                }
                if ( cellEditor )
                {
                    popupSize.width += 2;
                }

                Insets insets = getInsets ();
                popupSize.setSize ( popupSize.width - ( insets.right + insets.left ),
                        getPopupHeightForRowCount ( comboBox.getMaximumRowCount () ) );

                Rectangle popupBounds = computePopupBounds ( 0, comboBox.getBounds ().height, popupSize.width, popupSize.height );
                Dimension scrollSize = popupBounds.getSize ();

                scroller.setMaximumSize ( scrollSize );
                scroller.setPreferredSize ( scrollSize );
                scroller.setMinimumSize ( scrollSize );

                list.revalidate ();
            }

            private void setListSelection ( int selectedIndex )
            {
                if ( selectedIndex == -1 )
                {
                    list.clearSelection ();
                }
                else
                {
                    list.setSelectedIndex ( selectedIndex );
                    list.ensureIndexIsVisible ( selectedIndex );
                }
            }
        };
    }

    public boolean isComboboxCellEditor ()
    {
        if ( comboBox != null )
        {
            Object cellEditor = comboBox.getClientProperty ( WebDefaultCellEditor.COMBOBOX_CELL_EDITOR );
            return cellEditor != null && ( Boolean ) cellEditor;
        }
        else
        {
            return false;
        }
    }

    public Shape provideShape ()
    {
        if ( drawBorder )
        {
            return LafUtils.getWebBorderShape ( comboBox, shadeWidth, round );
        }
        else
        {
            return SwingUtils.size ( comboBox );
        }
    }

    public boolean isDrawBorder ()
    {
        return drawBorder;
    }

    public void setDrawBorder ( boolean drawBorder )
    {
        this.drawBorder = drawBorder;
        updateBorder ();
    }

    public boolean isDrawFocus ()
    {
        return drawFocus;
    }

    public void setDrawFocus ( boolean drawFocus )
    {
        this.drawFocus = drawFocus;
    }

    public int getRound ()
    {
        return round;
    }

    public void setRound ( int round )
    {
        this.round = round;
    }

    public int getShadeWidth ()
    {
        return shadeWidth;
    }

    public void setShadeWidth ( int shadeWidth )
    {
        this.shadeWidth = shadeWidth;
        updateBorder ();
    }

    public boolean isMouseWheelScrollingEnabled ()
    {
        return mouseWheelScrollingEnabled;
    }

    public void setMouseWheelScrollingEnabled ( boolean enabled )
    {
        this.mouseWheelScrollingEnabled = enabled;
    }

    public void paint ( Graphics g, JComponent c )
    {
        hasFocus = comboBox.hasFocus ();
        Rectangle r = rectangleForCurrentValue ();

        // Background
        paintCurrentValueBackground ( g, r, hasFocus );

        // Selected uneditable value
        if ( !comboBox.isEditable () )
        {
            paintCurrentValue ( g, r, hasFocus );
        }
    }

    public void paintCurrentValueBackground ( Graphics g, Rectangle bounds, boolean hasFocus )
    {
        Graphics2D g2d = ( Graphics2D ) g;

        if ( drawBorder )
        {
            // Border and background
            LafUtils.drawWebBorder ( g2d, comboBox,
                    drawFocus && SwingUtils.hasFocusOwner ( comboBox ) ? StyleConstants.fieldFocusColor : StyleConstants.shadeColor,
                    shadeWidth, round, true, true );
        }
        else
        {
            // Simple background
            Rectangle cb = SwingUtils.size ( comboBox );
            g2d.setPaint ( LafUtils.getWebGradientPaint ( cb ) );
            g2d.fillRect ( cb.x, cb.y, cb.width, cb.height );
        }
    }

    public void paintCurrentValue ( Graphics g, Rectangle bounds, boolean hasFocus )
    {
        // Selected element font color fix method

        ListCellRenderer renderer = comboBox.getRenderer ();
        Component c;

        if ( hasFocus && !isPopupVisible ( comboBox ) )
        {
            c = renderer.getListCellRendererComponent ( listBox, comboBox.getSelectedItem (), -1, true, false );
        }
        else
        {
            c = renderer.getListCellRendererComponent ( listBox, comboBox.getSelectedItem (), -1, false, false );
            c.setBackground ( UIManager.getColor ( "ComboBox.background" ) );
        }
        c.setFont ( comboBox.getFont () );
        //                if ( hasFocus && !isPopupVisible(comboBox) ) {
        //                    c.setForeground(listBox.getSelectionForeground());
        //                    c.setBackground(listBox.getSelectionBackground());
        //                }
        //                else {
        if ( comboBox.isEnabled () )
        {
            c.setForeground ( comboBox.getForeground () );
            c.setBackground ( comboBox.getBackground () );
        }
        else
        {
            c.setForeground ( DefaultLookup.getColor ( comboBox, this, "ComboBox.disabledForeground", null ) );
            c.setBackground ( DefaultLookup.getColor ( comboBox, this, "ComboBox.disabledBackground", null ) );
        }
        //                }


        // Fix for 4238829: should lay out the JPanel.
        boolean shouldValidate = false;
        if ( c instanceof JPanel )
        {
            shouldValidate = true;
        }

        int x = bounds.x;
        int y = bounds.y;
        int w = bounds.width;
        int h = bounds.height;
        //                Insets padding = getInsets ();
        //                if ( padding != null )
        //                {
        //                    x = bounds.x + padding.left;
        //                    y = bounds.y + padding.top;
        //                    w = bounds.width - ( padding.left + padding.right );
        //                    h = bounds.height - ( padding.top + padding.bottom );
        //                }

        currentValuePane.paintComponent ( g, c, comboBox, x, y, w, h, shouldValidate );
    }
}
