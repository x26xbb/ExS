/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.checkbox;

import com.alee.laf.StyleConstants;
import com.alee.laf.list.WebListElement;
import com.alee.laf.tree.WebTreeElement;
import com.alee.utils.ColorUtils;
import com.alee.utils.ImageUtils;
import com.alee.utils.LafUtils;
import com.alee.utils.SwingUtils;
import com.alee.utils.laf.ShapeProvider;
import com.alee.utils.swing.Timer;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicCheckBoxUI;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

/**
 * User: mgarin Date: 28.04.11 Time: 14:47
 */

public class WebCheckBoxUI extends BasicCheckBoxUI implements ShapeProvider
{
    public static final int MAX_DARKNESS = 5;

    public static List<ImageIcon> CHECK_STATES = new ArrayList<ImageIcon> ();
    public static ImageIcon DISABLED_CHECK = null;

    public static int updateDelay = 40;

    static
    {
        CHECK_STATES.add ( StyleConstants.EMPTY_ICON );
        for ( int i = 1; i <= 4; i++ )
        {
            CHECK_STATES.add ( new ImageIcon ( WebCheckBoxUI.class.getResource ( "icons/c" + i + ".png" ) ) );
        }

        DISABLED_CHECK = ImageUtils.getDisabledCopy ( "WebCheckBox.disabled.check", CHECK_STATES.get ( CHECK_STATES.size () - 1 ) );
    }

    private Color borderColor = WebCheckBoxStyle.borderColor;
    private Color darkBorderColor = WebCheckBoxStyle.darkBorderColor;
    private Color disabledBorderColor = WebCheckBoxStyle.disabledBorderColor;

    private Color topBgColor = WebCheckBoxStyle.topBgColor;
    private Color bottomBgColor = WebCheckBoxStyle.bottomBgColor;
    private Color topSelectedBgColor = WebCheckBoxStyle.topSelectedBgColor;
    private Color bottomSelectedBgColor = WebCheckBoxStyle.bottomSelectedBgColor;

    private int round = WebCheckBoxStyle.round;
    private int shadeWidth = WebCheckBoxStyle.shadeWidth;
    private Insets margin = WebCheckBoxStyle.margin;

    private boolean animated = WebCheckBoxStyle.animated;
    private boolean rolloverDarkBorderOnly = WebCheckBoxStyle.rolloverDarkBorderOnly;

    public Stroke borderStroke = new BasicStroke ( 1.5f );

    private int iconWidth = 16;
    private int iconHeight = 16;

    private int bgDarkness = 0;
    private boolean rollover;
    private Timer bgTimer;

    private int checkIcon;
    private boolean checking;
    private Timer checkTimer;

    private JCheckBox checkBox = null;

    private MouseAdapter mouseAdapter;
    private ItemListener itemListener;

    public static ComponentUI createUI ( JComponent c )
    {
        return new WebCheckBoxUI ();
    }

    public void installUI ( final JComponent c )
    {
        super.installUI ( c );

        // Saving checkBox to local variable
        checkBox = ( JCheckBox ) c;

        // Default settings
        SwingUtils.setOrientation ( checkBox );
        checkBox.setOpaque ( false );

        // Initial check state
        checkIcon = checkBox.isSelected () ? CHECK_STATES.size () - 1 : 0;

        // Updating border and icon
        updateBorder ();
        updateIcon ( checkBox );

        // Animation timers and listeners
        bgTimer = new Timer ( "WebCheckBoxUI.bgUpdater", updateDelay, new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                if ( rollover && bgDarkness < MAX_DARKNESS )
                {
                    bgDarkness++;
                    c.repaint ();
                }
                else if ( !rollover && bgDarkness > 0 )
                {
                    bgDarkness--;
                    c.repaint ();
                }
                else
                {
                    bgTimer.stop ();
                }
            }
        } );
        mouseAdapter = new MouseAdapter ()
        {
            public void mouseEntered ( MouseEvent e )
            {
                rollover = true;
                if ( isAnimated () && c.isEnabled () )
                {
                    bgTimer.start ();
                }
                else
                {
                    bgDarkness = MAX_DARKNESS;
                    c.repaint ();
                }
            }

            public void mouseExited ( MouseEvent e )
            {
                rollover = false;
                if ( isAnimated () && c.isEnabled () )
                {
                    bgTimer.start ();
                }
                else
                {
                    bgDarkness = 0;
                    c.repaint ();
                }
            }
        };
        checkBox.addMouseListener ( mouseAdapter );
        checkTimer = new Timer ( "WebCheckBoxUI.iconUpdater", updateDelay, new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                if ( checking && checkIcon < CHECK_STATES.size () - 1 )
                {
                    checkIcon++;
                    c.repaint ();
                }
                else if ( !checking && checkIcon > 0 )
                {
                    checkIcon--;
                    c.repaint ();
                }
                else
                {
                    checkTimer.stop ();
                }
            }
        } );
        itemListener = new ItemListener ()
        {
            public void itemStateChanged ( ItemEvent e )
            {
                if ( isAnimated () && c.isEnabled () )
                {
                    if ( checkBox.isSelected () )
                    {
                        checking = true;
                        checkTimer.start ();
                    }
                    else
                    {
                        checking = false;
                        checkTimer.start ();
                    }
                }
                else
                {
                    checkTimer.stop ();
                    checkIcon = checkBox.isSelected () ? CHECK_STATES.size () - 1 : 0;
                    c.repaint ();
                }
            }
        };
        checkBox.addItemListener ( itemListener );
    }

    public void uninstallUI ( JComponent c )
    {
        checkBox.removeMouseListener ( mouseAdapter );
        checkBox.removeItemListener ( itemListener );

        super.uninstallUI ( c );
    }

    public Shape provideShape ()
    {
        return LafUtils.getWebBorderShape ( checkBox, getShadeWidth (), getRound () );
    }

    private void updateBorder ()
    {
        checkBox.setBorder ( BorderFactory.createEmptyBorder ( margin.top, margin.left, margin.bottom, margin.right ) );
    }

    public Insets getMargin ()
    {
        return margin;
    }

    public void setMargin ( Insets margin )
    {
        this.margin = margin;
        updateBorder ();
    }

    public boolean isAnimated ()
    {
        return animated && ( checkBox == null || checkBox.getParent () == null ||
                !( checkBox.getParent () instanceof WebListElement || checkBox.getParent () instanceof WebTreeElement ) );
    }

    public void setAnimated ( boolean animated )
    {
        this.animated = animated;
    }

    public boolean isRolloverDarkBorderOnly ()
    {
        return rolloverDarkBorderOnly;
    }

    public void setRolloverDarkBorderOnly ( boolean rolloverDarkBorderOnly )
    {
        this.rolloverDarkBorderOnly = rolloverDarkBorderOnly;
    }

    public Color getBorderColor ()
    {
        return borderColor;
    }

    public void setBorderColor ( Color borderColor )
    {
        this.borderColor = borderColor;
    }

    public Color getDarkBorderColor ()
    {
        return darkBorderColor;
    }

    public void setDarkBorderColor ( Color darkBorderColor )
    {
        this.darkBorderColor = darkBorderColor;
    }

    public Color getDisabledBorderColor ()
    {
        return disabledBorderColor;
    }

    public void setDisabledBorderColor ( Color disabledBorderColor )
    {
        this.disabledBorderColor = disabledBorderColor;
    }

    public Color getTopBgColor ()
    {
        return topBgColor;
    }

    public void setTopBgColor ( Color topBgColor )
    {
        this.topBgColor = topBgColor;
    }

    public Color getBottomBgColor ()
    {
        return bottomBgColor;
    }

    public void setBottomBgColor ( Color bottomBgColor )
    {
        this.bottomBgColor = bottomBgColor;
    }

    public Color getTopSelectedBgColor ()
    {
        return topSelectedBgColor;
    }

    public void setTopSelectedBgColor ( Color topSelectedBgColor )
    {
        this.topSelectedBgColor = topSelectedBgColor;
    }

    public Color getBottomSelectedBgColor ()
    {
        return bottomSelectedBgColor;
    }

    public void setBottomSelectedBgColor ( Color bottomSelectedBgColor )
    {
        this.bottomSelectedBgColor = bottomSelectedBgColor;
    }

    public int getRound ()
    {
        return round;
    }

    public void setRound ( int round )
    {
        this.round = round;
    }

    public int getShadeWidth ()
    {
        return shadeWidth;
    }

    public void setShadeWidth ( int shadeWidth )
    {
        this.shadeWidth = shadeWidth;
    }

    private void updateIcon ( final JCheckBox checkBox )
    {
        checkBox.setIcon ( new Icon ()
        {
            public void paintIcon ( Component c, Graphics g, int x, int y )
            {
                Graphics2D g2d = ( Graphics2D ) g;
                Object aa = LafUtils.setupAntialias ( g2d );

                // Button size and shape
                Rectangle iconRect =
                        new Rectangle ( x + shadeWidth, y + shadeWidth, iconWidth - shadeWidth * 2 - 1, iconHeight - shadeWidth * 2 - 1 );
                RoundRectangle2D shape =
                        new RoundRectangle2D.Double ( iconRect.x, iconRect.y, iconRect.width, iconRect.height, round * 2, round * 2 );

                // Shade
                if ( c.isEnabled () )
                {
                    LafUtils.drawShade ( g2d, shape,
                            c.isEnabled () && c.isFocusOwner () ? StyleConstants.fieldFocusColor : StyleConstants.shadeColor, shadeWidth );
                }

                // Background
                int radius = Math.round ( ( float ) Math.sqrt ( iconRect.width * iconRect.width / 2 ) );
                g2d.setPaint ( new RadialGradientPaint ( iconRect.x + iconRect.width / 2, iconRect.y + iconRect.height / 2, radius,
                        new float[]{ 0f, 1f }, getBgColors ( checkBox ) ) );
                g2d.fill ( shape );

                // Border
                Stroke os = LafUtils.setupStroke ( g2d, borderStroke );
                g2d.setPaint ( c.isEnabled () ?
                        ( rolloverDarkBorderOnly ? ColorUtils.getProgress ( borderColor, darkBorderColor, getProgress () ) :
                                darkBorderColor ) : disabledBorderColor );
                g2d.draw ( shape );
                LafUtils.restoreStroke ( g2d, os );

                // Check icon
                if ( checkIcon > 0 )
                {
                    ImageIcon icon = checkBox.isEnabled () ? CHECK_STATES.get ( checkIcon ) : DISABLED_CHECK;
                    g2d.drawImage ( icon.getImage (), x + iconWidth / 2 - icon.getIconWidth () / 2,
                            y + iconHeight / 2 - icon.getIconHeight () / 2, checkBox );
                }

                LafUtils.restoreAntialias ( g2d, aa );
            }

            public int getIconWidth ()
            {
                return iconWidth;
            }

            public int getIconHeight ()
            {
                return iconHeight;
            }
        } );
    }

    private Color[] getBgColors ( JCheckBox checkBox )
    {
        if ( checkBox.isEnabled () )
        {
            float progress = getProgress ();
            if ( progress < 1f )
            {
                return new Color[]{ ColorUtils.getProgress ( topBgColor, topSelectedBgColor, progress ),
                        ColorUtils.getProgress ( bottomBgColor, bottomSelectedBgColor, progress ) };
            }
            else
            {
                return new Color[]{ topSelectedBgColor, bottomSelectedBgColor };
            }
        }
        else
        {
            return new Color[]{ topBgColor, bottomBgColor };
        }
    }

    private float getProgress ()
    {
        return ( float ) bgDarkness / MAX_DARKNESS;
    }
}
