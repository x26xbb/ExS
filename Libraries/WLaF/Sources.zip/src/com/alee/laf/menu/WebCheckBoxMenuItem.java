/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.menu;

import com.alee.laf.WebLookAndFeel;
import com.alee.managers.hotkey.HotkeyData;
import com.alee.utils.ReflectUtils;
import com.alee.utils.SwingUtils;

import javax.swing.*;

/**
 * User: mgarin Date: 19.09.11 Time: 18:41
 */

public class WebCheckBoxMenuItem extends JCheckBoxMenuItem
{
    public WebCheckBoxMenuItem ()
    {
        super ();
    }

    public WebCheckBoxMenuItem ( Action a )
    {
        super ( a );
    }

    public WebCheckBoxMenuItem ( Icon icon )
    {
        super ( icon );
    }

    public WebCheckBoxMenuItem ( String text )
    {
        super ( text );
    }

    public WebCheckBoxMenuItem ( String text, boolean b )
    {
        super ( text, b );
    }

    public WebCheckBoxMenuItem ( String text, Icon icon )
    {
        super ( text, icon );
    }

    public WebCheckBoxMenuItem ( String text, Icon icon, boolean b )
    {
        super ( text, icon, b );
    }

    public void setHotkey ( HotkeyData hotkey )
    {
        SwingUtils.setHotkey ( this, hotkey );
    }

    public WebCheckBoxMenuItemUI getWebUI ()
    {
        return ( WebCheckBoxMenuItemUI ) getUI ();
    }

    public void updateUI ()
    {
        if ( getUI () == null || !( getUI () instanceof WebCheckBoxMenuItemUI ) )
        {
            try
            {
                setUI ( ( WebCheckBoxMenuItemUI ) ReflectUtils.createInstance ( WebLookAndFeel.checkBoxMenuItemUI ) );
            }
            catch ( Throwable e )
            {
                e.printStackTrace ();
                setUI ( new WebCheckBoxMenuItemUI () );
            }
        }
        else
        {
            setUI ( getUI () );
        }
    }
}
