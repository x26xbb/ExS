/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.list;

import com.alee.extended.background.DefaultPainter;
import com.alee.laf.StyleConstants;
import com.alee.utils.LafUtils;

import java.awt.*;

/**
 * User: mgarin Date: 24.08.12 Time: 14:52
 */

public class WebListElementPainter extends DefaultPainter<WebListElement>
{
    public WebListElementPainter ()
    {
        super ();
    }

    public Insets getMargin ( WebListElement element )
    {
        return new Insets ( element.getShadeWidth () + 3, element.getShadeWidth () + 3, element.getShadeWidth () + 3,
                element.getShadeWidth () + 3 );
    }

    public void paint ( Graphics2D g2d, Rectangle bounds, WebListElement element )
    {
        if ( element.isSelected () )
        {
            paintSelectedBackground ( g2d, element );
        }
        else if ( element.isRollover () )
        {
            paintRolloverBackground ( g2d, element );
        }
        else
        {
            paintNormalBackground ( g2d, element );
        }
    }

    protected void paintSelectedBackground ( Graphics2D g2d, WebListElement element )
    {
        LafUtils.drawWebBorder ( g2d, element, StyleConstants.shadeColor, element.getShadeWidth (), element.getRound (), true, true );
    }

    protected void paintRolloverBackground ( Graphics2D g2d, WebListElement element )
    {
        LafUtils.drawWebBorder ( g2d, element, StyleConstants.shadeColor, element.getShadeWidth (), element.getRound (), true, true,
                0.35f );
    }

    protected void paintNormalBackground ( Graphics2D g2d, WebListElement element )
    {
        //
    }
}