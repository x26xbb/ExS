/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.list;

import com.alee.extended.background.Painter;

import javax.swing.*;
import java.awt.*;

/**
 * User: mgarin Date: 28.04.11 Time: 12:57
 */

public class WebListCellRenderer extends DefaultListCellRenderer
{
    private int rolloverIndex;
    protected WebListElement renderer;

    public WebListCellRenderer ()
    {
        super ();
        this.rolloverIndex = -1;
        this.renderer = new WebListElement ();
    }

    public int getRolloverIndex ()
    {
        return rolloverIndex;
    }

    public void setRolloverIndex ( int rolloverIndex )
    {
        this.rolloverIndex = rolloverIndex;
    }

    public WebListElement getRenderer ()
    {
        return renderer;
    }

    public Painter getPainter ()
    {
        return getRenderer ().getPainter ();
    }

    public void setPainter ( Painter painter )
    {
        getRenderer ().setPainter ( painter );
    }

    public Component getListCellRendererComponent ( JList list, Object value, int index, boolean isSelected, boolean cellHasFocus )
    {
        renderer.setSelected ( isSelected );
        renderer.setRollover ( getRolloverIndex () == index );
        renderer.setCellHasFocus ( cellHasFocus );

        renderer.setEnabled ( list.isEnabled () );
        renderer.setFont ( list.getFont () );
        renderer.setForeground ( isSelected ? list.getSelectionForeground () : list.getForeground () );
        renderer.setComponentOrientation ( list.getComponentOrientation () );

        if ( value instanceof Icon )
        {
            renderer.setIcon ( ( Icon ) value );
            renderer.setText ( "" );
        }
        else
        {
            renderer.setIcon ( null );
            renderer.setText ( value == null ? "" : value.toString () );
        }

        return renderer;
    }

    /**
     * Workaround to provide update functionality on painter update
     */

    public boolean equals ( Object obj )
    {
        return false;
    }

    /**
     * A subclass of WebListCellRenderer that implements UIResource
     */

    public static class UIResource extends WebListCellRenderer implements javax.swing.plaf.UIResource
    {
        //
    }
}
