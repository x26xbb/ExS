/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.list;

import com.alee.extended.background.Painter;
import com.alee.laf.label.WebLabel;

/**
 * User: mgarin Date: 02.09.11 Time: 14:25
 */

public class WebListElement extends WebLabel
{
    private Painter painter;
    private int round = WebListElementStyle.round;
    private int shadeWidth = WebListElementStyle.shadeWidth;

    private boolean selected = false;
    private boolean isRollover = false;
    private boolean cellHasFocus = false;

    public WebListElement ()
    {
        super ();
        setPainter ( new WebListElementPainter () );
    }

    public void updatePainter ()
    {
        super.setPainter ( painter );
    }

    public Painter getPainter ()
    {
        return painter;
    }

    public void setPainter ( Painter painter )
    {
        this.painter = painter;
        updatePainter ();
    }

    public int getRound ()
    {
        return round;
    }

    public void setRound ( int round )
    {
        this.round = round;
    }

    public int getShadeWidth ()
    {
        return shadeWidth;
    }

    public void setShadeWidth ( int shadeWidth )
    {
        this.shadeWidth = shadeWidth;
        updatePainter ();
    }

    public boolean isSelected ()
    {
        return selected;
    }

    public void setSelected ( boolean selected )
    {
        this.selected = selected;
    }

    public boolean isRollover ()
    {
        return isRollover;
    }

    public void setRollover ( boolean rollover )
    {
        isRollover = rollover;
    }

    public boolean isCellHasFocus ()
    {
        return cellHasFocus;
    }

    public void setCellHasFocus ( boolean cellHasFocus )
    {
        this.cellHasFocus = cellHasFocus;
    }

    /**
     * Overridden for performance reasons.
     */

    // Doesn't work well on OpenJDK

    //    public void repaint ()
    //    {
    //    }
    //
    //    public void repaint ( long tm, int x, int y, int width, int height )
    //    {
    //    }
    //
    //    public void repaint ( Rectangle r )
    //    {
    //    }

    //    public void validate ()
    //    {
    //    }
    //
    //    public void invalidate ()
    //    {
    //    }
    //
    //    public void revalidate ()
    //    {
    //    }
}
