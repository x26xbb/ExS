/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.list;

import com.alee.laf.list.editor.ListCellEditor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

/**
 * User: mgarin Date: 06.07.11 Time: 22:25
 */

public class ListUtils
{
    /*
    * Adds editor to list
    */

    public static void installEditor ( final JList list, final ListCellEditor listCellEditor )
    {
        final Runnable startEdit = new Runnable ()
        {
            public void run ()
            {
                final int index = list.getSelectedIndex ();
                if ( list.getSelectedIndices ().length != 1 || index == -1 )
                {
                    return;
                }

                final Object oldValue = list.getModel ().getElementAt ( index );
                if ( !listCellEditor.isCellEditable ( list, index, oldValue ) )
                {
                    return;
                }

                final JComponent editor = listCellEditor.createEditor ( list, index, oldValue );

                editor.setBounds ( computeCellEditorBounds ( index, oldValue, list, listCellEditor ) );
                list.addComponentListener ( new ComponentAdapter ()
                {
                    public void componentResized ( ComponentEvent e )
                    {
                        checkEditorBounds ();
                    }

                    private void checkEditorBounds ()
                    {
                        Rectangle newBounds = computeCellEditorBounds ( index, oldValue, list, listCellEditor );
                        if ( newBounds != null && !newBounds.equals ( editor.getBounds () ) )
                        {
                            editor.setBounds ( newBounds );
                            list.revalidate ();
                            list.repaint ();
                        }
                    }
                } );

                list.add ( editor );
                list.revalidate ();
                list.repaint ();

                if ( editor.isFocusable () )
                {
                    editor.requestFocus ();
                    editor.requestFocusInWindow ();
                }

                final Runnable cancelEdit = new Runnable ()
                {
                    public void run ()
                    {
                        list.remove ( editor );
                        list.revalidate ();
                        list.repaint ();

                        listCellEditor.editCancelled ( list, index );
                    }
                };
                final Runnable finishEdit = new Runnable ()
                {
                    public void run ()
                    {
                        // Selected indices to restore them later
                        int[] indices = list.getSelectedIndices ();

                        Object newValue = listCellEditor.getEditorValue ( list, index, oldValue );
                        boolean changed = listCellEditor.updateModelValue ( list, index, oldValue, newValue, true );

                        list.remove ( editor );
                        list.revalidate ();
                        list.repaint ();

                        if ( changed )
                        {
                            list.setSelectedIndices ( indices );
                            listCellEditor.editFinished ( list, index, oldValue, newValue );
                        }
                        else
                        {
                            listCellEditor.editCancelled ( list, index );
                        }
                    }
                };
                listCellEditor.setupEditorActions ( list, oldValue, cancelEdit, finishEdit );

                listCellEditor.editStarted ( list, index );
            }
        };
        listCellEditor.installEditor ( list, startEdit );
    }

    private static Rectangle computeCellEditorBounds ( int index, Object value, JList list, ListCellEditor listCellEditor )
    {

        Rectangle cellBounds = list.getCellBounds ( index, index );
        if ( cellBounds != null )
        {
            Rectangle editorBounds = listCellEditor.getEditorBounds ( list, index, value, cellBounds );
            return new Rectangle ( cellBounds.x + editorBounds.x, cellBounds.y + editorBounds.y, editorBounds.width, editorBounds.height );
        }
        else
        {
            return null;
        }
    }

    /*
    * Removes editor from list
    */

    public static void uninstallEditor ( JList list, ListCellEditor listCellEditor )
    {
        listCellEditor.uninstallEditor ( list );
    }
}
