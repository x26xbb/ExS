/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf.list.editor;

import javax.swing.*;
import java.awt.*;

/**
 * User: mgarin Date: 06.07.11 Time: 22:29
 */

public interface ListCellEditor
{
    /**
     * List listeners setup method for editing start, editing will be started upon calling startEdit.run() method
     */
    public void installEditor ( JList list, Runnable startEdit );

    /**
     * Editor removal method
     */
    public void uninstallEditor ( JList list );

    /**
     * Should allow this cell editing or not
     */
    public boolean isCellEditable ( JList list, int index, Object value );

    /**
     * Editor creation method
     */
    public JComponent createEditor ( JList list, int index, Object value );

    /**
     * Editor bounds on the list cell retrieval method
     */
    public Rectangle getEditorBounds ( JList list, int index, Object value, Rectangle cellBounds );

    /**
     * Editor listeners setup method for edit finish/cancel actions, editing will be finished or cancelled upon calling
     * finishEdit/cancelEdit.run() methods
     */
    public void setupEditorActions ( JList list, Object value, Runnable cancelEdit, Runnable finishEdit );

    /**
     * Final editor value retrieval. This method should return new value that will be put into the list model right away instead of the old
     * value.
     */
    public Object getEditorValue ( JList list, int index, Object oldValue );

    /**
     * Model and list update. Returns true if value has changed and model was succesfully updated
     */
    public boolean updateModelValue ( JList list, int index, Object oldValue, Object newValue, boolean updateSelection );

    /**
     * Methods informing about edit start/end/cancel
     */

    public void editStarted ( JList list, int index );

    public void editFinished ( JList list, int index, Object oldValue, Object newValue );

    public void editCancelled ( JList list, int index );
}
