/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.laf;

import com.alee.extended.image.WebImage;
import com.alee.extended.label.WebLinkLabel;
import com.alee.extended.layout.VerticalFlowLayout;
import com.alee.extended.panel.GroupPanel;
import com.alee.extended.window.ComponentMoveAdapter;
import com.alee.laf.label.WebLabel;
import com.alee.laf.panel.WebPanel;
import com.alee.laf.separator.WebSeparator;
import com.alee.managers.language.LM;
import com.alee.managers.language.LanguageManager;
import com.alee.managers.version.VersionInfo;
import com.alee.managers.version.VersionManager;
import com.alee.utils.SwingUtils;
import com.alee.utils.SystemUtils;

import javax.swing.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * User: mgarin Date: 03.08.12 Time: 15:35
 */

public class LibraryInfoDialog extends JFrame
{
    private static LibraryInfoDialog instance;

    public static LibraryInfoDialog getInstance ()
    {
        if ( instance == null )
        {
            instance = new LibraryInfoDialog ();
        }
        return instance;
    }

    private LibraryInfoDialog ()
    {
        super ();
        setIconImages ( WebLookAndFeel.getImages () );
        LanguageManager.registerComponent ( this, "weblaf.info.title" );
        ComponentMoveAdapter.install ( this );

        WebPanel content = new WebPanel ( new VerticalFlowLayout ( 30, 30 ) );
        content.setMargin ( 60, 70, 60, 70 );
        content.setUndecorated ( false );
        content.setWebColored ( true );
        content.setDrawSides ( false, false, false, false );
        add ( content );

        content.add ( createLibraryVersionPanel () );
        content.add ( new WebSeparator ( false, WebSeparator.HORIZONTAL ) );
        content.add ( createJavaVersionPanel () );
        content.add ( new WebSeparator ( false, WebSeparator.HORIZONTAL ) );
        content.add ( createOsVersionPanel () );

        setResizable ( false );
        pack ();
        setLocationRelativeTo ( null );
        setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
    }

    private WebPanel createLibraryVersionPanel ()
    {
        VersionInfo versionInfo = VersionManager.getLibraryVersion ();

        WebImage icon = new WebImage ( WebLookAndFeel.getIcon ( 32 ) );

        WebLinkLabel version = new WebLinkLabel ( versionInfo.toString () );
        version.setLink ( "http://weblookandfeel.com", false );
        SwingUtils.changeFontSize ( SwingUtils.setBoldFont ( version ), 1 );

        WebLabel date = new WebLabel ( LM.get ( "weblaf.info.updated" ) + " " +
                new SimpleDateFormat ( "dd MMM yyyy" ).format ( new Date ( versionInfo.getDate () ) ) );

        return new GroupPanel ( 15, icon, new GroupPanel ( false, version, date ) );
    }

    private WebPanel createJavaVersionPanel ()
    {
        WebImage javaIcon = new WebImage ( new ImageIcon ( LibraryInfoDialog.class.getResource ( "icons/java.png" ) ) );

        WebLinkLabel javaVersion = new WebLinkLabel ( LM.get ( "weblaf.info.java.version" ) + SystemUtils.getJavaVersion () );
        javaVersion.setLink ( "http://www.oracle.com", false );
        SwingUtils.changeFontSize ( SwingUtils.setBoldFont ( javaVersion ), 1 );

        WebLabel javaName = new WebLabel ( SystemUtils.getJavaName () );

        return new GroupPanel ( 15, javaIcon, new GroupPanel ( false, javaVersion, javaName ) );
    }

    private WebPanel createOsVersionPanel ()
    {
        WebImage osIcon = new WebImage ( SystemUtils.getOsIcon ( 32 ) );

        WebLabel version = new WebLabel ( SystemUtils.getOsName () );
        SwingUtils.changeFontSize ( SwingUtils.setBoldFont ( version ), 1 );

        WebLabel osVersion = new WebLabel ( LM.get ( "weblaf.info.os.arch" ) + " " + SystemUtils.getOsArch () );

        return new GroupPanel ( 15, osIcon, new GroupPanel ( false, version, osVersion ) );
    }

    public static void main ( String[] args )
    {
        // Basic library jar info frame
        WebLookAndFeel.install ();
        LibraryInfoDialog.getInstance ().setVisible ( true );
    }
}