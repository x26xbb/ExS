/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups.futurico;

import com.alee.examples.WebLookAndFeelDemo;
import com.alee.examples.groups.DefaultExample;
import com.alee.extended.background.NinePatchStatePainter;
import com.alee.extended.panel.GroupPanel;
import com.alee.laf.button.WebButton;
import com.alee.laf.text.WebPasswordField;
import com.alee.laf.text.WebTextField;
import com.alee.utils.XmlUtils;

import javax.swing.*;
import java.awt.*;

/**
 * User: mgarin Date: 14.03.12 Time: 14:37
 */

public class FuturicoFieldsExample extends DefaultExample
{
    public static ImageIcon searchIcon = new ImageIcon ( FuturicoFieldsExample.class.getResource ( "icons/field/search.png" ) );
    public static ImageIcon pSearchIcon = new ImageIcon ( FuturicoFieldsExample.class.getResource ( "icons/field/psearch.png" ) );

    public String getTitle ()
    {
        return "Futurico text fields";
    }

    public String getDescription ()
    {
        return "Futurico-styled text fields";
    }

    public boolean isFillWidth ()
    {
        return true;
    }

    public Component getPreview ( WebLookAndFeelDemo owner )
    {
        // Painters used for example fields
        NinePatchStatePainter painter1 = XmlUtils.loadNinePatchStatePainter ( getResource ( "field.xml" ) );

        // Simple fields
        WebTextField field1 = new WebTextField ( "Styled text field" );
        field1.setPainter ( painter1 );
        field1.setForeground ( Color.WHITE );
        WebTextField field2 = new WebTextField ( "Disabled text field" );
        field2.setEnabled ( false );
        field2.setPainter ( painter1 );
        field2.setForeground ( Color.WHITE );
        WebPasswordField field3 = new WebPasswordField ( "Styled password field" );
        field3.setPainter ( painter1 );
        field3.setForeground ( Color.WHITE );

        // Field with trailing component
        WebTextField field4 = new WebTextField ( "Styled text field with leading component" );
        field4.setComponentSpacing ( 6 );
        field4.setPainter ( XmlUtils.loadNinePatchStatePainter ( getResource ( "sfield.xml" ) ) );
        field4.setForeground ( Color.WHITE );
        WebButton sButton = new WebButton ();
        sButton.setFocusable ( false );
        sButton.setUndecorated ( true );
        sButton.setLeftRightSpacing ( 0 );
        sButton.setMoveIconOnPress ( false );
        sButton.setCursor ( Cursor.getDefaultCursor () );
        sButton.setIcon ( searchIcon );
        sButton.setPressedIcon ( pSearchIcon );
        field4.setTrailingComponent ( sButton );

        return new GroupPanel ( false, field1, field2, field3, field4 );
    }
}