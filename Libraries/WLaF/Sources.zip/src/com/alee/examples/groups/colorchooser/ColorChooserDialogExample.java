/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups.colorchooser;

import com.alee.examples.WebLookAndFeelDemo;
import com.alee.examples.groups.DefaultExample;
import com.alee.examples.groups.FeatureState;
import com.alee.extended.colorchooser.WebColorChooser;
import com.alee.extended.panel.GroupPanel;
import com.alee.laf.StyleConstants;
import com.alee.laf.button.WebButton;
import com.alee.utils.ImageUtils;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * User: mgarin Date: 16.02.12 Time: 18:18
 */

public class ColorChooserDialogExample extends DefaultExample
{
    public String getTitle ()
    {
        return "Color chooser dialog";
    }

    public String getDescription ()
    {
        return "Web-styled color chooser dialog";
    }

    public FeatureState getFeatureState ()
    {
        return FeatureState.beta;
    }

    public Component getPreview ( final WebLookAndFeelDemo owner )
    {
        // Simple color chooser
        final WebButton colorChooserButton = new WebButton ( "255, 255, 255", ImageUtils.createColorIcon ( Color.WHITE ) );
        colorChooserButton.setLeftRightSpacing ( 0 );
        colorChooserButton.addActionListener ( new ActionListener ()
        {
            private WebColorChooser colorChooser = null;
            private Color lastColor = Color.WHITE;

            public void actionPerformed ( ActionEvent e )
            {
                if ( colorChooser == null )
                {
                    colorChooser = new WebColorChooser ( owner );
                    colorChooser.setColor ( lastColor );
                }
                colorChooser.setVisible ( true );

                if ( colorChooser.getResult () == StyleConstants.OK_OPTION )
                {
                    Color color = colorChooser.getColor ();
                    lastColor = color;

                    colorChooserButton.setIcon ( ImageUtils.createColorIcon ( color ) );
                    colorChooserButton.setText ( color.getRed () + ", " + color.getGreen () + ", " + color.getBlue () );
                }
            }
        } );

        return new GroupPanel ( colorChooserButton );
    }
}