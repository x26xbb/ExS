/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups.android;

import com.alee.examples.WebLookAndFeelDemo;
import com.alee.examples.groups.DefaultExample;
import com.alee.extended.background.NinePatchStatePainter;
import com.alee.extended.image.WebImage;
import com.alee.extended.panel.GroupPanel;
import com.alee.laf.text.WebPasswordField;
import com.alee.laf.text.WebTextField;
import com.alee.utils.XmlUtils;

import java.awt.*;

/**
 * User: mgarin Date: 12.03.12 Time: 15:54
 */

public class AndroidFieldsExample extends DefaultExample
{
    public String getTitle ()
    {
        return "Android text fields";
    }

    public String getDescription ()
    {
        return "Android-styled text fields";
    }

    public boolean isFillWidth ()
    {
        return true;
    }

    public Component getPreview ( WebLookAndFeelDemo owner )
    {
        // Single painter used for all example fields
        NinePatchStatePainter npfbp = XmlUtils.loadNinePatchStatePainter ( getResource ( "field.xml" ) );

        // Simple fields
        WebTextField field1 = new WebTextField ( "Styled text field" );
        field1.setPainter ( npfbp );
        WebTextField field2 = new WebTextField ( "Disabled text field" );
        field2.setEnabled ( false );
        field2.setPainter ( npfbp );
        WebPasswordField field3 = new WebPasswordField ( "Styled password field" );
        field3.setPainter ( npfbp );

        // Field with leading component
        WebTextField field4 = new WebTextField ( "Styled text field with leading component" );
        field4.setLeadingComponent ( new WebImage ( loadIcon ( "search.png" ) ) );
        field4.setComponentSpacing ( 6 );
        field4.setPainter ( npfbp );

        return new GroupPanel ( false, field1, field2, field3, field4 );
    }
}