/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups;

import com.alee.extended.breadcrumb.WebBreadcrumb;
import com.alee.extended.breadcrumb.WebBreadcrumbButton;
import com.alee.extended.breadcrumb.WebBreadcrumbLabel;
import com.alee.extended.image.WebImage;
import com.alee.laf.GlobalConstants;
import com.alee.laf.label.WebLabel;
import com.alee.laf.menu.WebMenuItem;
import com.alee.laf.menu.WebPopupMenu;
import com.alee.laf.panel.WebPanel;
import com.alee.laf.scroll.WebScrollPane;
import com.alee.laf.tabbedpane.TabbedPaneStyle;
import com.alee.laf.text.WebEditorPane;
import com.alee.managers.tooltip.TooltipManager;
import com.alee.utils.FileUtils;
import com.alee.utils.ImageUtils;
import com.alee.utils.SwingUtils;
import com.alee.utils.TextUtils;
import com.alee.utils.reflection.JarEntry;
import com.alee.utils.reflection.JarEntryType;
import com.alee.utils.reflection.JarStructure;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.zip.ZipFile;

/**
 * User: mgarin Date: 05.03.12 Time: 12:38
 */

public class SourceViewer extends WebPanel
{
    public static ImageIcon browseIcon = new ImageIcon ( SourceViewer.class.getResource ( "icons/browse.png" ) );

    private JarStructure jarStructure;

    private WebBreadcrumb classPath;
    private ViewTabbedPane viewTabbedPane;
    private ChangeListener viewChangeListener;

    public SourceViewer ( JarStructure jarStructure )
    {
        super ();

        this.jarStructure = jarStructure;

        classPath = new WebBreadcrumb ( true );
        classPath.setEncloseLastElement ( true );
        classPath.setDrawSides ( false, false, true, false );
        classPath.setShadeWidth ( 0 );
        classPath.setMargin ( 4, 6, 4, 6 );
        add ( classPath, BorderLayout.NORTH );

        viewTabbedPane = new ViewTabbedPane ();
        viewTabbedPane.setTabbedPaneStyle ( TabbedPaneStyle.attached );
        viewChangeListener = new ChangeListener ()
        {
            public void stateChanged ( ChangeEvent e )
            {
                updateClassPath ( viewTabbedPane.getSelectedEntry () );
            }
        };
        viewTabbedPane.addChangeListener ( viewChangeListener );
        add ( viewTabbedPane, BorderLayout.CENTER );

        updateClassPath ( ( JarEntry ) null );
    }

    public JarStructure getJarStructure ()
    {
        return jarStructure;
    }

    public void updateClassPath ( Object classObject )
    {
        updateClassPath ( classObject.getClass () );
    }

    public void updateClassPath ( Class classType )
    {
        updateClassPath ( jarStructure.getClassEntry ( classType ) );
    }

    public void updateClassPath ( final JarEntry lastEntry )
    {
        classPath.removeAll ();

        // Root element
        final JarEntry root = jarStructure.getRoot ();
        final WebBreadcrumbButton rootElement = new WebBreadcrumbButton ();
        rootElement.setIcon ( root.getIcon () );
        TooltipManager.setTooltip ( rootElement, root.getIcon (), jarStructure.getJarLocation () );
        rootElement.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                final WebPopupMenu rootMenu = new WebPopupMenu ();

                WebMenuItem showInFS = new WebMenuItem ( "Show in folder", browseIcon );
                showInFS.addActionListener ( new ActionListener ()
                {
                    public void actionPerformed ( ActionEvent e )
                    {
                        try
                        {
                            File jarFile = new File ( jarStructure.getJarLocation () );
                            Desktop.getDesktop ().browse ( jarFile.getParentFile ().toURI () );
                        }
                        catch ( Throwable ex )
                        {
                            ex.printStackTrace ();
                        }
                    }
                } );
                rootMenu.add ( showInFS );

                List<JarEntry> entries = jarStructure.getChildEntries ( root );
                if ( entries.size () > 0 )
                {
                    rootMenu.addSeparator ();
                    for ( JarEntry entry : entries )
                    {
                        rootMenu.add ( createEntryMenuItem ( entry ) );
                    }
                }

                boolean ltr = rootElement.getComponentOrientation ().isLeftToRight ();
                rootMenu.show ( rootElement, ltr ? 1 : rootElement.getWidth () - 1 - rootMenu.getPreferredSize ().width,
                        rootElement.getHeight () + 2 );
            }
        } );
        classPath.add ( rootElement );

        if ( lastEntry != null )
        {
            // All other elements
            List<JarEntry> path = lastEntry.getPath ();
            for ( final JarEntry entry : path )
            {
                if ( entry.getType ().equals ( JarEntryType.packageEntry ) )
                {
                    final WebBreadcrumbButton element = new WebBreadcrumbButton ();
                    element.setIcon ( entry.getIcon () );
                    element.setText ( entry.getName () );
                    element.addActionListener ( new ActionListener ()
                    {
                        public void actionPerformed ( ActionEvent e )
                        {
                            List<JarEntry> entries = jarStructure.getChildEntries ( entry );
                            if ( entries.size () > 0 )
                            {
                                final WebPopupMenu packageMenu = new WebPopupMenu ();
                                for ( JarEntry menuEntry : entries )
                                {
                                    packageMenu.add ( createEntryMenuItem ( menuEntry ) );
                                }

                                boolean ltr = rootElement.getComponentOrientation ().isLeftToRight ();
                                packageMenu.show ( element, ltr ? classPath.getOverlap () : element.getWidth () - classPath.getOverlap () -
                                        packageMenu.getPreferredSize ().width, element.getHeight () + 2 );
                            }
                        }
                    } );
                    classPath.add ( element );
                }
                else
                {
                    WebBreadcrumbLabel element = new WebBreadcrumbLabel ();
                    element.setIcon ( entry.getIcon () );
                    element.setText ( entry.getName () );
                    classPath.add ( element );
                }
            }
        }

        classPath.updateBreadcrumb ();

        if ( lastEntry != null )
        {
            if ( lastEntry.getType ().equals ( JarEntryType.jar ) || lastEntry.getType ().equals ( JarEntryType.packageEntry ) )
            {
                // Queueing last element menu to let breadcrumb update element locations first
                SwingUtilities.invokeLater ( new Runnable ()
                {
                    public void run ()
                    {
                        // Opening last element menu if it is a package
                        ( ( WebBreadcrumbButton ) classPath.getLastComponent () ).doClick ();
                    }
                } );
            }
            else
            {
                // Viewing last element if it is a file
                viewTabbedPane.removeChangeListener ( viewChangeListener );
                viewEntry ( lastEntry );
                viewTabbedPane.addChangeListener ( viewChangeListener );
            }
        }
    }

    public void viewEntry ( JarEntry entry )
    {
        viewTabbedPane.viewEntry ( entry, createEntryViewer ( entry ) );
    }

    public void closeEntryView ( JarEntry entry )
    {
        viewTabbedPane.closeEntryView ( entry );
    }

    private Component createEntryViewer ( JarEntry entry )
    {
        if ( entry.getType ().equals ( JarEntryType.classEntry ) || entry.getType ().equals ( JarEntryType.javaEntry ) )
        {
            // Source code (.java/.class files)
            final WebEditorPane source = new WebEditorPane ();
            source.setEditable ( false );
            source.setMargin ( new Insets ( 5, 5, 5, 5 ) );
            WebScrollPane sourceScroll = new WebScrollPane ( source, false );
            sourceScroll.setVerticalScrollBarPolicy ( WebScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
            source.setContentType ( "text/java" );
            source.addMouseListener ( new MouseAdapter ()
            {
                public void mousePressed ( MouseEvent e )
                {
                    // Additional feature to dive into related classes
                    if ( SwingUtilities.isMiddleMouseButton ( e ) || SwingUtils.isCtrl ( e ) && SwingUtilities.isLeftMouseButton ( e ) )
                    {
                        int pos = source.getUI ().viewToModel ( source, e.getPoint () );
                        String word = TextUtils.getWord ( source.getText (), pos );
                        if ( word != null )
                        {
                            JarEntry classByName = jarStructure.findClassByName ( word );
                            if ( classByName != null && ( classByName.getType ().equals ( JarEntryType.classEntry ) ||
                                    classByName.getType ().equals ( JarEntryType.javaEntry ) ) )
                            {
                                updateClassPath ( classByName );
                            }
                        }
                    }
                }
            } );
            source.setText ( loadSource ( entry ) );
            source.setCaretPosition ( 0 );
            return sourceScroll;
        }
        else if ( entry.getType ().equals ( JarEntryType.fileEntry ) )
        {
            String ext = FileUtils.getFileExtPart ( entry.getName (), false ).toLowerCase ();
            if ( GlobalConstants.IMAGE_FORMATS.contains ( ext ) )
            {
                // Image file
                WebImage image = new WebImage ();
                image.setIcon ( ImageUtils.loadImage ( getEntryInputStream ( entry ) ) );
                WebScrollPane imageScroll = new WebScrollPane ( image, false );
                imageScroll.setVerticalScrollBarPolicy ( WebScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
                imageScroll.setHorizontalScrollBarPolicy ( WebScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS );
                return imageScroll;
            }
            else
            {
                // Text files
                WebEditorPane text = new WebEditorPane ();
                text.setEditable ( false );
                text.setMargin ( new Insets ( 5, 5, 5, 5 ) );
                WebScrollPane textScroll = new WebScrollPane ( text, false );
                textScroll.setVerticalScrollBarPolicy ( WebScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
                text.setContentType ( ext.equals ( "xml" ) ? "text/xml" : "text/plain" );
                text.setText ( FileUtils.readToString ( getEntryInputStream ( entry ) ) );
                text.setCaretPosition ( 0 );
                return textScroll;
            }
        }
        return new WebLabel ();
    }

    private static final String commentStart = "/*";
    private static final String commentEnd = "*/\n\n";

    private String loadSource ( JarEntry lastEntry )
    {
        String source = FileUtils.readToString ( getEntryInputStream ( lastEntry ) );

        // Removing space-eating license notice
        if ( source.startsWith ( "/*" ) )
        {
            int index = source.indexOf ( commentEnd );
            if ( index != -1 )
            {
                source = source.substring ( index + commentEnd.length () );
            }
        }

        return source;
    }

    private InputStream getEntryInputStream ( JarEntry entry )
    {
        try
        {
            return new ZipFile ( jarStructure.getJarLocation () ).getInputStream ( entry.getZipEntry () );
        }
        catch ( IOException e )
        {
            e.printStackTrace ();
            return null;
        }
    }

    private WebMenuItem createEntryMenuItem ( final JarEntry entry )
    {
        WebMenuItem entryItem = new WebMenuItem ( entry.getName (), entry.getIcon () );
        entryItem.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                updateClassPath ( entry );
            }
        } );
        return entryItem;
    }

    public void addViewListener ( ViewListener listener )
    {
        this.viewTabbedPane.addViewListener ( listener );
    }

    public void removeViewListener ( ViewListener listener )
    {
        this.viewTabbedPane.removeViewListener ( listener );
    }
}