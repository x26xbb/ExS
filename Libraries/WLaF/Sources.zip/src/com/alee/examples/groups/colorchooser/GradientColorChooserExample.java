/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups.colorchooser;

import com.alee.examples.WebLookAndFeelDemo;
import com.alee.examples.groups.DefaultExample;
import com.alee.examples.groups.FeatureState;
import com.alee.extended.colorchooser.GradientColorData;
import com.alee.extended.colorchooser.GradientData;
import com.alee.extended.colorchooser.WebGradientColorChooser;
import com.alee.extended.panel.FlowPanel;
import com.alee.extended.panel.GroupPanel;
import com.alee.extended.panel.WebButtonGroup;
import com.alee.laf.button.WebButton;
import com.alee.laf.label.WebLabel;
import com.alee.managers.settings.SettingsManager;
import com.alee.managers.tooltip.TooltipManager;
import com.alee.utils.SwingUtils;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * User: mgarin Date: 27.11.12 Time: 14:56
 */

public class GradientColorChooserExample extends DefaultExample
{
    public String getTitle ()
    {
        return "Gradient color chooser";
    }

    public String getDescription ()
    {
        return "Web-styled gradient color chooser";
    }

    public FeatureState getFeatureState ()
    {
        return FeatureState.beta;
    }

    public Component getPreview ( final WebLookAndFeelDemo owner )
    {
        // Default value
        final GradientData defaultValue = SettingsManager.getDefaultValue ( GradientData.class );

        // Simple color chooser
        final WebGradientColorChooser colorChooser = new WebGradientColorChooser ();
        colorChooser.setPreferredWidth ( 350 );
        SettingsManager.registerComponent ( colorChooser, "GradientColorChooserExample.gradientData", GradientData.class );

        // Reset button
        final WebButton colored = new WebButton ( loadIcon ( "colored.png" ) );
        TooltipManager.setTooltip ( colored, "Various colors" );
        colored.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                // Simply apply default gradient values
                colorChooser.setGradientData ( defaultValue.clone () );
            }
        } );

        // Black & white colors button
        final WebButton blackAndWhite = new WebButton ( loadIcon ( "bw.png" ) );
        TooltipManager.setTooltip ( blackAndWhite, "Black and white colors" );
        blackAndWhite.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                // Apply gradient values through SettingsManager
                // Notice that component will be automatically updated due to external settings changes!
                GradientData blackAndWhite = new GradientData ();
                blackAndWhite.addGradientColorData ( new GradientColorData ( 0f, Color.BLACK ) );
                blackAndWhite.addGradientColorData ( new GradientColorData ( 1f, Color.WHITE ) );
                SettingsManager.set ( "GradientColorChooserExample.gradientData", blackAndWhite );
            }
        } );

        // Tip labels
        WebLabel tip = SwingUtils.setBoldFont ( new WebLabel ( "Useful usage tips:" ) );
        WebLabel tip1 = new WebLabel ( "To choose color - simply double click on any color" );
        WebLabel tip2 = new WebLabel ( "To add new color - just click on any free space on the line" );
        WebLabel tip3 = new WebLabel ( "To remove color - drag it up or use right or middle mouse button" );
        WebLabel tip4 = new WebLabel ( "To copy color - press ALT and drag an existing color" );

        WebButtonGroup buttonGroup = new WebButtonGroup ( colored, blackAndWhite );
        buttonGroup.setButtonsFocusable ( false );
        GroupPanel colorChooserPanel = new GroupPanel ( 20, colorChooser, new FlowPanel ( 5, buttonGroup ) );
        GroupPanel groupPanel = new GroupPanel ( 5, false, colorChooserPanel, 10, tip, tip1, tip2, tip3, tip4 );
        groupPanel.setMargin ( 15 );

        return groupPanel;
    }
}