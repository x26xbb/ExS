/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups.ninepatch;

import com.alee.examples.WebLookAndFeelDemo;
import com.alee.examples.groups.DefaultExample;
import com.alee.examples.groups.ExamplesManager;
import com.alee.laf.button.WebToggleButton;
import com.alee.laf.panel.WebPanel;
import com.alee.laf.toolbar.WebToolBar;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * User: mgarin Date: 12.03.12 Time: 13:25
 */

public class NinePatchStylesExample extends DefaultExample
{
    private Component currentView = null;

    public String getTitle ()
    {
        return "Nine-patch styling";
    }

    public String getDescription ()
    {
        return "Nine-patch styled components";
    }

    public Component getPreview ( WebLookAndFeelDemo owner )
    {
        final WebPanel content = new WebPanel ();

        WebToolBar toolBar = new WebToolBar ();
        content.add ( toolBar, BorderLayout.NORTH );

        for ( StyleType styleType : StyleType.values () )
        {
            WebToggleButton styleButton = new WebToggleButton ( styleType.getName (), styleType.getIcon () );

            final Component view = ExamplesManager.createGroupView ( owner, new StyledComponentsGroup ( styleType ) );

            styleButton.addActionListener ( new ActionListener ()
            {
                public void actionPerformed ( ActionEvent e )
                {
                    if ( currentView != view )
                    {
                        content.remove ( currentView );
                        content.add ( view, BorderLayout.CENTER );
                        content.revalidate ();
                        content.repaint ();
                        currentView = view;
                    }
                }
            } );
        }

        return null;
    }
}