/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups;

import com.alee.laf.separator.WebSeparator;
import com.alee.laf.tabbedpane.WebTabbedPane;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * User: mgarin Date: 23.01.12 Time: 11:52
 */

public interface ExampleGroup
{
    public Icon getGroupIcon ();

    public String getGroupName ();

    public String getGroupDescription ();

    public boolean isSingleExample ();

    public boolean isShowWatermark ();

    public FeatureState getFeatureGroupState ();

    public List<Example> getGroupExamples ();

    public void modifyExampleTab ( int tabIndex, WebTabbedPane tabbedPane );

    public WebSeparator modifySeparator ( WebSeparator separator );

    public Color getPreferredForeground ();

    public double getContentPartSize ();
}
