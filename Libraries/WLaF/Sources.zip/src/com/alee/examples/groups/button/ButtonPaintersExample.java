/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups.button;

import com.alee.examples.WebLookAndFeelDemo;
import com.alee.examples.groups.DefaultExample;
import com.alee.extended.background.DefaultPainter;
import com.alee.extended.background.Painter;
import com.alee.extended.panel.GroupPanel;
import com.alee.laf.button.WebButton;
import com.alee.utils.LafUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.GeneralPath;

/**
 * User: mgarin Date: 06.06.12 Time: 17:59
 */

public class ButtonPaintersExample extends DefaultExample
{
    public String getTitle ()
    {
        return "Button painters";
    }

    public String getDescription ()
    {
        return "Custom button painters";
    }

    public Component getPreview ( WebLookAndFeelDemo owner )
    {
        // Custom button painter
        // This painter only changes view on button focus and disabled state changes
        Painter painter = new ButtonPainter ();

        // Simple button to demostrate painter in action
        WebButton b = new WebButton ( "Simple" );
        b.setPainter ( painter );

        // Iconed button to demostrate painter in action
        WebButton db = new WebButton ( "Iconed", loadIcon ( "icon.png" ) );
        db.setPainter ( painter );

        return new GroupPanel ( 4, b, db );
    }

    public static class ButtonPainter extends DefaultPainter<WebButton>
    {
        // Border colors
        private Color topBorder = new Color ( 159, 159, 159 );
        private Color bottomBorder = new Color ( 111, 111, 111 );
        private Color topDisabledBorder = new Color ( 179, 179, 179 );
        private Color bottomDisabledBorder = new Color ( 131, 131, 131 );

        // Inner border colors
        private Color topInnerBorder = new Color ( 255, 255, 255, 150 );
        private Color bottomInnerBorder = new Color ( 255, 255, 255, 90 );

        // Background colors
        private Color topBg = new Color ( 232, 232, 232 );
        private Color bottomBg = new Color ( 203, 203, 203 );
        private Color topFocusedBg = new Color ( 169, 194, 214 );
        private Color bottomFocusedBg = new Color ( 140, 170, 195 );
        private Color topDisabledBg = new Color ( 242, 242, 242 );
        private Color bottomDisabledBg = new Color ( 213, 213, 213 );

        public ButtonPainter ()
        {
            super ();
            setMargin ( 5, 5, 5, 5 );
        }

        public void paint ( Graphics2D g2d, Rectangle bounds, WebButton c )
        {
            // Background
            g2d.setPaint ( getBackgroundPaint ( c ) );
            g2d.fillRect ( 2, 2, c.getWidth () - 4, c.getHeight () - 4 );

            // Inner border
            g2d.setPaint ( new GradientPaint ( 0, 2, topInnerBorder, 0, c.getHeight () - 4, bottomInnerBorder ) );
            g2d.draw ( getInnerBorderShape ( c ) );

            // Shade & Outer border color
            g2d.setPaint ( new GradientPaint ( 0, 1, c.isEnabled () ? topBorder : topDisabledBorder, 0, c.getHeight () - 2,
                    c.isEnabled () ? bottomBorder : bottomDisabledBorder ) );

            // Semi-transparent shade
            if ( c.isEnabled () )
            {
                Composite composite = LafUtils.setupAlphaComposite ( g2d, 0.4f );
                g2d.drawRoundRect ( 0, 0, c.getWidth () - 1, c.getHeight () - 1, 4, 4 );
                LafUtils.restoreComposite ( g2d, composite );
            }

            // Outer border
            g2d.drawRoundRect ( 1, 1, c.getWidth () - 3, c.getHeight () - 3, 2, 2 );
        }

        private Paint getBackgroundPaint ( JComponent c )
        {
            return new GradientPaint ( 0, 1, c.isEnabled () ? ( c.isFocusOwner () ? topFocusedBg : topBg ) : topDisabledBg, 0,
                    c.getHeight () - 2, c.isEnabled () ? ( c.isFocusOwner () ? bottomFocusedBg : bottomBg ) : bottomDisabledBg );
        }

        private Shape getInnerBorderShape ( JComponent c )
        {
            GeneralPath gp = new GeneralPath ( GeneralPath.WIND_EVEN_ODD );
            gp.moveTo ( 2, c.getHeight () - 5 );
            gp.lineTo ( 2, 2 );
            gp.lineTo ( c.getWidth () - 3, 2 );
            gp.lineTo ( c.getWidth () - 3, c.getHeight () - 5 );
            return gp;
        }
    }
}