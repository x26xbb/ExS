/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.examples.groups;

import com.alee.extended.icon.OrientedIcon;
import com.alee.laf.separator.WebSeparator;
import com.alee.laf.tabbedpane.WebTabbedPane;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

/**
 * User: mgarin Date: 30.01.12 Time: 13:08
 */

public abstract class DefaultExampleGroup implements ExampleGroup
{
    public boolean isSingleExample ()
    {
        return false;
    }

    public boolean isShowWatermark ()
    {
        return true;
    }

    public FeatureState getFeatureGroupState ()
    {
        return FeatureState.release;
    }

    public void modifyExampleTab ( int tabIndex, WebTabbedPane tabbedPane )
    {
        //
    }

    public WebSeparator modifySeparator ( WebSeparator separator )
    {
        return separator;
    }

    public Color getPreferredForeground ()
    {
        return Color.BLACK;
    }

    public double getContentPartSize ()
    {
        return 0.5f;
    }

    public ImageIcon loadGroupIcon ( String path )
    {
        return new OrientedIcon ( getIconResource ( path ) );
    }

    public ImageIcon loadIcon ( String path )
    {
        return new ImageIcon ( getIconResource ( path ) );
    }

    private URL getIconResource ( String path )
    {
        return getClass ().getResource ( "icons/" + path );
    }

    public URL getResource ( String path )
    {
        return getClass ().getResource ( "resources/" + path );
    }
}