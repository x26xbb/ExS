/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.panel;

import com.alee.laf.panel.WebPanel;
import com.alee.laf.toolbar.WhiteSpace;
import info.clearthought.layout.TableLayout;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;

/**
 * User: mgarin Date: 19.05.11 Time: 14:18
 */

public class GroupPanel extends WebPanel
{
    public static final String FILL_CELL = "fill.component.cell";

    public GroupPanel ( Object... components )
    {
        this ( true, components );
    }

    public GroupPanel ( boolean horizontal, Object... components )
    {
        this ( 0, horizontal, components );
    }

    public GroupPanel ( int gap, Object... components )
    {
        this ( gap, true, components );
    }

    public GroupPanel ( int gap, boolean horizontal, Object... components )
    {
        super ();
        setOpaque ( false );

        // Creating layout date
        List<Object> comps = Arrays.asList ( components );
        double[] li = new double[ comps.size () ];
        for ( int i = 0; i < comps.size (); i++ )
        {
            Object object = comps.get ( i );
            double constraint = TableLayout.PREFERRED;
            if ( object instanceof JComponent )
            {
                Boolean b = ( Boolean ) ( ( JComponent ) object ).getClientProperty ( FILL_CELL );
                if ( b != null )
                {
                    constraint = TableLayout.FILL;
                }
            }
            else if ( object instanceof Integer )
            {
                constraint = ( Integer ) object;
            }
            li[ i ] = constraint;
        }

        TableLayout tableLayout =
                new TableLayout ( horizontal ? new double[][]{ li, { TableLayout.FILL } } : new double[][]{ { TableLayout.FILL }, li } );
        tableLayout.setVGap ( gap );
        tableLayout.setHGap ( gap );
        setLayout ( tableLayout );

        for ( int i = 0; i < comps.size (); i++ )
        {
            String constraint = horizontal ? ( i + ",0" ) : ( "0," + i );
            Object object = comps.get ( i );
            if ( object instanceof Component )
            {
                add ( ( Component ) object, constraint );
            }
            else if ( object instanceof Integer )
            {
                add ( new WhiteSpace ( ( Integer ) object, horizontal ? WhiteSpace.HORIZONTAL : WhiteSpace.VERTICAL ), constraint );
            }
        }
    }
}
