/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.panel;

/**
 * User: mgarin Date: 09.04.12 Time: 18:08
 * <p/>
 * This is a special WebCollapsiblePane events listener that fires four kinds of events. Two of them are fired before the collapsible pane
 * finished either collapsing or expanding and two other fired after. Notice that both events could be fired almost in the same time in case
 * WebCollapsiblePane is not animated or its animation is speeded up.
 */

public interface CollapsiblePaneListener
{
    /*
    * Notifies when WebCollapsiblePane starts to expand
    */

    public void expanding ( WebCollapsiblePane pane );

    /*
    * Notifies when WebCollapsiblePane finished expanding
    */

    public void expanded ( WebCollapsiblePane pane );

    /*
    * Notifies when WebCollapsiblePane starts to collapse
    */

    public void collapsing ( WebCollapsiblePane pane );

    /*
    * Notifies when WebCollapsiblePane finished collapsing
    */

    public void collapsed ( WebCollapsiblePane pane );
}
