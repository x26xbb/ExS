/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.panel;

import com.alee.laf.StyleConstants;
import com.alee.laf.button.WebButton;
import com.alee.laf.label.WebLabel;
import com.alee.laf.panel.WebPanel;
import com.alee.utils.CollectionUtils;
import com.alee.utils.ImageUtils;
import com.alee.utils.swing.Timer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * User: mgarin Date: 09.11.11 Time: 14:38
 * <p/>
 * This extended components allows you to quickly create and manipulate a collapsible pane.
 */

public class WebCollapsiblePane extends WebPanel implements SwingConstants
{
    public static final ImageIcon expand = new ImageIcon ( WebCollapsiblePane.class.getResource ( "icons/expand.png" ) );
    public static final ImageIcon collapse = new ImageIcon ( WebCollapsiblePane.class.getResource ( "icons/collapse.png" ) );

    private List<CollapsiblePaneListener> listeners = new ArrayList<CollapsiblePaneListener> ();

    private ImageIcon collapseIcon = collapse;
    private ImageIcon cachedCollapseIcon = null;
    private ImageIcon cachedDisabledCollapseIcon = null;
    private ImageIcon expandIcon = expand;
    private ImageIcon cachedExpandIcon = null;
    private ImageIcon cachedDisabledExpandIcon = null;

    private int titlePlacement = SwingConstants.TOP;
    private boolean rotateExpandCollapseIcons = true;
    private boolean animate = StyleConstants.animate;

    private boolean expanded = true;
    private float expandState = 1f;
    private float expandSpeed = 0.2f;
    private Timer animator = null;

    private boolean customTitle = false;
    private JComponent titleComponent;
    private Component content = null;

    private WebPanel headerPanel;
    private WebButton expandButton;
    private WebPanel contentPanel;

    public WebCollapsiblePane ()
    {
        this ( "" );
    }

    public WebCollapsiblePane ( String title )
    {
        this ( title, ( ImageIcon ) null );
    }

    public WebCollapsiblePane ( String title, ImageIcon icon )
    {
        this ( title, icon, null );
    }

    public WebCollapsiblePane ( String title, Component content )
    {
        this ( title, null, content );
    }

    public WebCollapsiblePane ( String title, ImageIcon icon, Component content )
    {
        super ();
        // putClientProperty ( SwingUtils.HANDLES_ENABLE_STATE, true );

        this.content = content;

        setDrawFocus ( true );
        setUndecorated ( false );
        setRound ( StyleConstants.smallRound );
        setLayout ( new BorderLayout ( 0, 0 ) );

        add ( createHeaderPanel ( title, icon ), BorderLayout.NORTH );

        contentPanel = new WebPanel ()
        {
            public Dimension getPreferredSize ()
            {
                Dimension ps = super.getPreferredSize ();
                if ( WebCollapsiblePane.this.content != null )
                {
                    ps.width = WebCollapsiblePane.this.content.getPreferredSize ().width;
                }
                if ( expandState < 1f )
                {
                    ps.height = Math.round ( ps.height * expandState );
                }
                return ps;
            }
        };
        contentPanel.setOpaque ( false );
        contentPanel.setLayout ( new BorderLayout ( 0, 0 ) );
        add ( contentPanel, BorderLayout.CENTER );

        if ( this.content != null )
        {
            contentPanel.add ( this.content, BorderLayout.CENTER );
        }
    }

    private WebPanel createHeaderPanel ( String title, ImageIcon icon )
    {
        headerPanel = new WebPanel ();
        headerPanel.setOpaque ( true );
        headerPanel.setUndecorated ( false );
        headerPanel.setDrawSides ( false, false, true, false );
        headerPanel.setShadeWidth ( 0 );
        headerPanel.setLayout ( new BorderLayout () );
        headerPanel.addMouseListener ( new MouseAdapter ()
        {
            public void mouseReleased ( MouseEvent e )
            {
                if ( SwingUtilities.isLeftMouseButton ( e ) && e.getX () >= 0 && e.getY () >= 0 &&
                        e.getX () <= getWidth () && e.getY () <= getHeight () )
                {
                    invertExpandState ();
                }
            }
        } );

        titleComponent = createDefaultTitleComponent ( title, icon );
        updateTitleBorder ();
        headerPanel.add ( titleComponent, BorderLayout.CENTER );

        expandButton = new WebButton ( collapseIcon );
        expandButton.setUndecorated ( true );
        expandButton.setDrawFocus ( false );
        expandButton.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                invertExpandState ();
            }
        } );
        headerPanel.add ( expandButton, BorderLayout.LINE_END );

        updateExpandCollapseIcons ();

        return headerPanel;
    }

    private JComponent createDefaultTitleComponent ( String title, ImageIcon icon )
    {
        WebLabel defaultTitle = new WebLabel ( title, icon, WebLabel.LEADING );
        defaultTitle.setDrawShade ( true );
        return defaultTitle;
    }

    private void updateTitleBorder ()
    {
        if ( titleComponent != null && !customTitle )
        {
            // Computing new margin
            Insets margin = getIcon () == null ? new Insets ( 2, 4, 2, 0 ) : new Insets ( 2, 2, 2, 0 );
            switch ( titlePlacement )
            {
                case LEFT:
                {
                    margin = new Insets ( margin.right, margin.top, margin.left, margin.bottom );
                    break;
                }
                case RIGHT:
                {
                    margin = new Insets ( margin.left, margin.bottom, margin.right, margin.top );
                    break;
                }
            }

            // Updating title margin
            WebLabel defaultTitle = ( WebLabel ) titleComponent;
            defaultTitle.setMargin ( margin );
        }
    }

    /**
     * Collapse and expand methods
     */

    public void invertExpandState ()
    {
        invertExpandState ( animate );
    }

    public void invertExpandState ( boolean animate )
    {
        setExpanded ( !isExpanded (), animate );
    }

    public boolean isExpanded ()
    {
        return expanded;
    }

    public void setExpanded ( boolean expanded )
    {
        setExpanded ( expanded, isShowing () && animate );
    }

    public void setExpanded ( boolean expanded, boolean animate )
    {
        if ( isEnabled () )
        {
            if ( expanded )
            {
                expand ( animate );
            }
            else
            {
                collapse ( animate );
            }
        }
    }

    public void collapse ()
    {
        collapse ( animate );
    }

    public void collapse ( boolean animate )
    {
        if ( !expanded )
        {
            return;
        }

        stopAnimation ();

        expanded = false;
        updateExpandCollapseIcons ();

        if ( isShowing () )
        {
            expandButton.requestFocusInWindow ();
        }

        fireCollapsing ();

        if ( animate && isShowing () )
        {
            animator = new Timer ( "WebCollapsiblePane.collapseTimer", StyleConstants.avgAnimationDelay, new ActionListener ()
            {
                public void actionPerformed ( ActionEvent e )
                {
                    if ( expandState > 0f )
                    {
                        expandState = Math.max ( 0, expandState - expandSpeed );
                        WebCollapsiblePane.this.revalidate ();
                    }
                    else
                    {
                        hideContent ();
                        animator.stop ();
                    }
                }
            } );
            animator.start ();
        }
        else
        {
            expandState = 0f;
            hideContent ();
        }
    }

    private void hideContent ()
    {
        // Hide bottom title border 
        headerPanel.setDrawBottom ( false );

        // Hide content
        if ( content != null )
        {
            content.setVisible ( false );
        }

        // Update collapsible pane 
        revalidate ();
        repaint ();

        // Inform about event
        fireCollapsed ();
    }

    public void expand ()
    {
        expand ( animate );
    }

    public void expand ( boolean animate )
    {
        if ( expanded )
        {
            return;
        }

        stopAnimation ();

        expanded = true;
        updateExpandCollapseIcons ();

        if ( isShowing () )
        {
            expandButton.requestFocusInWindow ();
        }

        if ( content != null )
        {
            content.setVisible ( true );
        }

        headerPanel.setDrawBottom ( true );

        fireExpanding ();

        if ( animate && isShowing () )
        {
            animator = new Timer ( "WebCollapsiblePane.expandTimer", StyleConstants.avgAnimationDelay, new ActionListener ()
            {
                public void actionPerformed ( ActionEvent e )
                {
                    if ( expandState < 1f )
                    {
                        expandState = Math.min ( 1f, expandState + expandSpeed );
                        WebCollapsiblePane.this.revalidate ();
                    }
                    else
                    {
                        showContent ();
                        animator.stop ();
                    }
                }
            } );
            animator.start ();
        }
        else
        {
            expandState = 1f;
            showContent ();
        }
    }

    private void showContent ()
    {
        WebCollapsiblePane.this.revalidate ();
        WebCollapsiblePane.this.repaint ();
        fireExpanded ();
    }

    private void stopAnimation ()
    {
        if ( animator != null && animator.isRunning () )
        {
            animator.stop ();
        }
    }

    /**
     * Should animate expand and collapse transitions
     */

    public boolean isAnimate ()
    {
        return animate;
    }

    public void setAnimate ( boolean animate )
    {
        this.animate = animate;
    }

    /**
     * Title text
     */

    public void setTitle ( String title )
    {
        if ( !customTitle )
        {
            ( ( WebLabel ) titleComponent ).setText ( title );
        }
    }

    public String getTitle ()
    {
        return customTitle ? null : ( ( WebLabel ) titleComponent ).getText ();
    }

    /**
     * Title icon
     */

    public void setIcon ( Icon icon )
    {
        if ( !customTitle )
        {
            ( ( WebLabel ) titleComponent ).setIcon ( icon );
            updateTitleBorder ();
        }
    }

    public Icon getIcon ()
    {
        return customTitle ? null : ( ( WebLabel ) titleComponent ).getIcon ();
    }

    /**
     * Collapse button icon
     */

    public ImageIcon getCollapseIcon ()
    {
        return collapseIcon;
    }

    public void setCollapseIcon ( ImageIcon collapseIcon )
    {
        this.collapseIcon = collapseIcon;
        clearCachedCollapseIcons ();
        updateExpandCollapseIcons ();
    }

    /**
     * Expand button icon
     */

    public ImageIcon getExpandIcon ()
    {
        return expandIcon;
    }

    public void setExpandIcon ( ImageIcon expandIcon )
    {
        this.expandIcon = expandIcon;
        clearCachedExpandIcons ();
        updateExpandCollapseIcons ();
    }

    /**
     * Should rotate expand and collapse icons according to title position
     */

    public boolean isRotateExpandCollapseIcons ()
    {
        return rotateExpandCollapseIcons;
    }

    public void setRotateExpandCollapseIcons ( boolean rotateExpandCollapseIcons )
    {
        this.rotateExpandCollapseIcons = rotateExpandCollapseIcons;
        clearCachedCollapseIcons ();
        clearCachedExpandIcons ();
        updateExpandCollapseIcons ();
    }

    /**
     * Collapsible pane title placement
     */

    // todo Various title placement
    //    public int getTitlePlacement ()
    //    {
    //        return titlePlacement;
    //    }
    //
    //    public void setTitlePlacement ( int titlePlacement )
    //    {
    //        this.titlePlacement = titlePlacement;
    //        updateTitleBorder ();
    //        clearCachedCollapseIcons ();
    //        clearCachedExpandIcons ();
    //        updateExpandCollapseIcons ();
    //    }

    /**
     * Collapse and expand icons update methods
     */

    private void updateExpandCollapseIcons ()
    {
        if ( expanded )
        {
            expandButton.setIcon ( getCachedCollapseIcon () );
            expandButton.setDisabledIcon ( getCachedDisabledCollapseIcon () );
        }
        else
        {
            expandButton.setIcon ( expandIcon );
            expandButton.setDisabledIcon ( ImageUtils.createDisabledCopy ( expandIcon ) );
        }
    }

    private void clearCachedCollapseIcons ()
    {
        cachedCollapseIcon = null;
        cachedDisabledCollapseIcon = null;
    }

    private ImageIcon getCachedCollapseIcon ()
    {
        if ( cachedCollapseIcon == null )
        {
            switch ( titlePlacement )
            {
                case TOP:
                {
                    cachedCollapseIcon = collapseIcon;
                    break;
                }
                case BOTTOM:
                {
                    cachedCollapseIcon = ImageUtils.rotateImage180 ( collapseIcon );
                    break;
                }
                case LEFT:
                {
                    cachedCollapseIcon = ImageUtils.rotateImage90CCW ( collapseIcon );
                    break;
                }
                case RIGHT:
                {
                    cachedCollapseIcon = ImageUtils.rotateImage90CW ( collapseIcon );
                    break;
                }
            }
        }
        return cachedCollapseIcon;
    }

    private ImageIcon getCachedDisabledCollapseIcon ()
    {
        if ( cachedDisabledCollapseIcon == null )
        {
            cachedDisabledCollapseIcon = ImageUtils.createDisabledCopy ( getCachedCollapseIcon () );
        }
        return cachedDisabledCollapseIcon;
    }

    private void clearCachedExpandIcons ()
    {
        cachedExpandIcon = null;
        cachedDisabledExpandIcon = null;
    }

    private ImageIcon getCachedExpandIcon ()
    {
        if ( cachedExpandIcon == null )
        {
            switch ( titlePlacement )
            {
                case TOP:
                {
                    cachedExpandIcon = expandIcon;
                    break;
                }
                case BOTTOM:
                {
                    cachedExpandIcon = ImageUtils.rotateImage180 ( expandIcon );
                    break;
                }
                case LEFT:
                {
                    cachedExpandIcon = ImageUtils.rotateImage90CCW ( expandIcon );
                    break;
                }
                case RIGHT:
                {
                    cachedExpandIcon = ImageUtils.rotateImage90CW ( expandIcon );
                    break;
                }
            }
        }
        return cachedExpandIcon;
    }

    private ImageIcon getCachedDisabledExpandIcon ()
    {
        if ( cachedDisabledExpandIcon == null )
        {
            cachedDisabledExpandIcon = ImageUtils.createDisabledCopy ( getCachedExpandIcon () );
        }
        return cachedDisabledExpandIcon;
    }

    /**
     * Header panel
     */

    public WebPanel getHeaderPanel ()
    {
        return headerPanel;
    }

    /**
     * Expand button
     */

    public WebButton getExpandButton ()
    {
        return expandButton;
    }

    /**
     * Collapsible pane title component
     */

    public JComponent getTitleComponent ()
    {
        return titleComponent;
    }

    public void setTitleComponent ( JComponent titleComponent )
    {
        if ( this.titleComponent != null )
        {
            headerPanel.remove ( this.titleComponent );
        }
        if ( titleComponent != null )
        {
            headerPanel.add ( titleComponent, BorderLayout.CENTER );
        }
        this.titleComponent = titleComponent;
        this.customTitle = true;
    }

    /**
     * Collapsible pane content
     */

    public Component getContent ()
    {
        return content;
    }

    public void setContent ( Component content )
    {
        if ( this.content != null )
        {
            contentPanel.remove ( content );
        }

        this.content = content;
        content.setVisible ( expandState > 0f );

        contentPanel.add ( content, BorderLayout.CENTER );
        revalidate ();
    }

    /**
     * Collapsible pane listeners
     */

    public List<CollapsiblePaneListener> getListeners ()
    {
        return listeners;
    }

    public void setListeners ( List<CollapsiblePaneListener> listeners )
    {
        this.listeners = listeners;
    }

    public void addCollapsiblePaneListener ( CollapsiblePaneListener listener )
    {
        listeners.add ( listener );
    }

    public void removeCollapsiblePaneListener ( CollapsiblePaneListener listener )
    {
        listeners.remove ( listener );
    }

    private void fireCollapsing ()
    {
        for ( CollapsiblePaneListener listener : CollectionUtils.clone ( listeners ) )
        {
            listener.collapsing ( this );
        }
    }

    private void fireCollapsed ()
    {
        for ( CollapsiblePaneListener listener : CollectionUtils.clone ( listeners ) )
        {
            listener.collapsed ( this );
        }
    }

    private void fireExpanding ()
    {
        for ( CollapsiblePaneListener listener : CollectionUtils.clone ( listeners ) )
        {
            listener.expanding ( this );
        }
    }

    private void fireExpanded ()
    {
        for ( CollapsiblePaneListener listener : CollectionUtils.clone ( listeners ) )
        {
            listener.expanded ( this );
        }
    }
}
