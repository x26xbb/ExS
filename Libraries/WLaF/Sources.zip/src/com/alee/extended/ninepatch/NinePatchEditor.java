/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.ninepatch;

import com.alee.laf.StyleConstants;
import com.alee.laf.scroll.WebScrollPane;
import com.alee.managers.hotkey.HotkeyRunnable;
import com.alee.utils.*;
import com.alee.utils.ninepatch.NinePatchIcon;
import com.alee.utils.ninepatch.NinePatchInterval;
import com.alee.utils.swing.MouseEventType;
import info.clearthought.layout.TableLayout;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * User: mgarin Date: 19.12.11 Time: 12:59
 * <p/>
 * This editor (and nine-patch files parsing) is not based on the Android small editor (http://developer.android.com/guide/developing/tools/draw9patch.html)
 * - NinePatchEditor is much more advanced and user-friendly. It allows fully visual and quick nine-patch editing, nine-patch information
 * copying and also creation of new nine-patch files based on any image file that could be loaded by WebLookAndFeel library.
 */

public class NinePatchEditor extends JComponent
{
    public static final Color STRETCH_GUIDELINES_COLOR = new Color ( 60, 150, 0 );
    public static final Color STRETCH_COLOR = new Color ( 80, 150, 0, 100 );
    public static final Color CONTENT_GUIDELINES_COLOR = new Color ( 80, 80, 80, 200 );
    public static final Color CONTENT_COLOR = new Color ( 90, 90, 255, 100 );
    public static final Color METRICS_BORDER = new Color ( 191, 191, 191 );
    public static final Color METRICS_TOP = Color.WHITE;
    public static final Color METRICS_BOTTOM = new Color ( 229, 233, 238 );
    public static final int RULER_LENGTH = 20;
    public static final int ADDITIONAL_SPACE = 80;
    public static final int SNAP = 3;
    public static final int MIN_ZOOM = 1;
    public static final int MAX_ZOOM = 32;

    private List<ChangeListener> changeListeners = new ArrayList<ChangeListener> ();
    private List<ZoomChangeListener> zoomChangeListeners = new ArrayList<ZoomChangeListener> ();

    private List<NinePatchInfo> history = new ArrayList<NinePatchInfo> ();
    private int historyState = -1;

    private BufferedImage ninePatchImage;
    private NinePatchIcon ninePatchIcon;

    private boolean showGuideSpacing = true;
    private boolean showRuler = true;
    private boolean fillStretchAreas = true;
    private boolean fillContentArea = true;
    private int zoom = 5;

    private WebScrollPane view;

    private boolean changed = false;
    private boolean someDragged = false;

    private HotkeyRunnable undoRunnable;
    private HotkeyRunnable redoRunnable;

    public NinePatchEditor ()
    {
        super ();

        ninePatchImage = null;
        ninePatchIcon = null;

        SwingUtils.setOrientation ( this );
        setFocusable ( true );
        setLayout ( new TableLayout ( new double[][]{ { RULER_LENGTH, TableLayout.PREFERRED, TableLayout.FILL },
                { RULER_LENGTH, TableLayout.PREFERRED, TableLayout.FILL } } ) );

        setFont ( new JLabel ().getFont ().deriveFont ( 10f ) );

        view = new WebScrollPane ( this, false );

        NinePatchEditorMouseAdapter npema = new NinePatchEditorMouseAdapter ();
        addMouseListener ( npema );
        addMouseMotionListener ( npema );
        addMouseWheelListener ( npema );
    }

    public WebScrollPane getView ()
    {
        return view;
    }

    public boolean isSomeDragged ()
    {
        return someDragged;
    }

    public boolean isChanged ()
    {
        return changed;
    }

    public void setChanged ( boolean changed )
    {
        this.changed = changed;
    }

    public int getZoom ()
    {
        return zoom;
    }

    public void setZoom ( int zoom )
    {
        this.zoom = Math.max ( MIN_ZOOM, Math.min ( zoom, MAX_ZOOM ) );
        revalidate ();
        repaint ();
        fireZoomChanged ();
    }

    public boolean isFillStretchAreas ()
    {
        return fillStretchAreas;
    }

    public void setFillStretchAreas ( boolean fillStretchAreas )
    {
        this.fillStretchAreas = fillStretchAreas;
        repaint ();
    }

    public boolean isFillContentArea ()
    {
        return fillContentArea;
    }

    public void setFillContentArea ( boolean fillContentArea )
    {
        this.fillContentArea = fillContentArea;
        repaint ();
    }

    public boolean isShowGuideSpacing ()
    {
        return showGuideSpacing;
    }

    public void setShowGuideSpacing ( boolean showGuideSpacing )
    {
        this.showGuideSpacing = showGuideSpacing;
        repaint ();
    }

    public boolean isShowRuler ()
    {
        return showRuler;
    }

    public void setShowRuler ( boolean showRuler )
    {
        this.showRuler = showRuler;
        repaint ();
    }

    public BufferedImage getImage ()
    {
        // Returns parsed raw image
        return ninePatchIcon.getImage ();
    }

    public BufferedImage getNinePatchImage ()
    {
        // Returns edited image
        assembleImage ();
        return ninePatchImage;
    }

    public void setNinePatchImage ( BufferedImage ninePatchImage )
    {
        // Ignore action if something is being dragged
        if ( isSomeDragged () )
        {
            return;
        }

        // Create new NinePatchIcon from imagefile
        disassembleImage ( ninePatchImage );

        // Updates shown image
        validateIcon ();
        revalidate ();
        repaint ();

        // Add initial state to history
        clearHistory ();
        saveHistoryState ();

        // Reset any changes done
        this.changed = false;

        // Inform about changes
        fireStateChanged ();
    }

    public void setNinePatchIcon ( NinePatchIcon ninePatchIcon )
    {
        // Ignore action if something is being dragged
        if ( isSomeDragged () )
        {
            return;
        }

        // Set new NinePatchIcon
        this.ninePatchIcon = ninePatchIcon;

        // Updates shown image
        validateIcon ();
        revalidate ();
        repaint ();

        // Add initial state to history
        clearHistory ();
        saveHistoryState ();

        // Reset any changes done
        this.changed = false;

        // Inform about changes
        fireStateChanged ();
    }

    public void setNinePatchInfo ( NinePatchInfo ninePatchInfo )
    {
        // Some cases in which we ignore this action
        if ( this.ninePatchIcon == null || ninePatchInfo == null || isSomeDragged () ||
                getNinePatchInfo ().equals ( ninePatchInfo ) )
        {
            return;
        }

        // Revalidate NinePatchInfo data
        ninePatchIcon.setVerticalStretch ( ninePatchInfo.getVerticalStretch () );
        verifyVerticalStretchAreas ();
        ninePatchIcon.setHorizontalStretch ( ninePatchInfo.getHorizontalStretch () );
        verifyHorizontalStretchAreas ();
        ninePatchIcon.setMargin ( ninePatchInfo.getMargin () );
        verifyMargin ();

        // Updates shown image
        validateIcon ();
        revalidate ();
        repaint ();

        // Add state to history
        saveHistoryState ();
    }

    public NinePatchInfo getNinePatchInfo ()
    {
        if ( ninePatchIcon == null )
        {
            return null;
        }

        NinePatchInfo ninePatchInfo = new NinePatchInfo ();
        ninePatchInfo.setImageSize ( ninePatchIcon.getRealImageSize () );
        ninePatchInfo.setHorizontalStretch ( ninePatchIcon.getHorizontalStretch () );
        ninePatchInfo.setVerticalStretch ( ninePatchIcon.getVerticalStretch () );
        ninePatchInfo.setMargin ( ninePatchIcon.getMargin () );
        return ninePatchInfo;
    }

    public NinePatchIcon getNinePatchIcon ()
    {
        return ninePatchIcon;
    }

    public void undo ()
    {
        if ( !isSomeDragged () && historyState > 0 )
        {
            historyState = historyState - 1;
            restoreHistoryState ( history.get ( historyState ) );
        }
    }

    public void redo ()
    {
        if ( !isSomeDragged () && historyState < history.size () - 1 )
        {
            historyState = historyState + 1;
            restoreHistoryState ( history.get ( historyState ) );
        }
    }

    private void restoreHistoryState ( NinePatchInfo state )
    {
        // Ignore action if history state doesn't fit current image
        if ( !state.getImageSize ().equals ( ninePatchIcon.getRealImageSize () ) )
        {
            return;
        }

        // Update NinePatchIcon data
        ninePatchIcon.setMargin ( SwingUtils.copy ( state.getMargin () ) );
        ninePatchIcon.setHorizontalStretch ( NinePatchUtils.copy ( state.getHorizontalStretch () ) );
        ninePatchIcon.setVerticalStretch ( NinePatchUtils.copy ( state.getVerticalStretch () ) );

        // Updates shown image
        validateIcon ();
        revalidate ();
        repaint ();
        fireStateChanged ();

        changed = historyState > 0;
    }

    private void saveHistoryState ()
    {
        if ( ninePatchIcon != null )
        {
            // Removing all undone states starting from end till the current state
            for ( int i = history.size () - 1; i > historyState; i-- )
            {
                history.remove ( i );
            }

            // Adding new state
            NinePatchInfo info = new NinePatchInfo ();
            info.setImageSize ( ninePatchIcon.getRealImageSize () );
            info.setMargin ( SwingUtils.copy ( ninePatchIcon.getMargin () ) );
            info.setHorizontalStretch ( NinePatchUtils.copy ( ninePatchIcon.getHorizontalStretch () ) );
            info.setVerticalStretch ( NinePatchUtils.copy ( ninePatchIcon.getVerticalStretch () ) );
            history.add ( info );
            historyState = history.size () - 1;

            // Updating changes state
            changed = true;
        }
    }

    private void clearHistory ()
    {
        history.clear ();
        historyState = -1;
    }

    private class NinePatchEditorMouseAdapter extends MouseAdapter
    {
        private boolean cameraDragged = false;

        private boolean hContentAreaDragged = false;
        private boolean hContentStartDragged = false;
        private boolean hContentEndDragged = false;
        private boolean vContentAreaDragged = false;
        private boolean vContentStartDragged = false;
        private boolean vContentEndDragged = false;
        private boolean contentAreaDragged = false;

        private boolean hStretchAreaDragged = false;
        private boolean hStretchStartDragged = false;
        private boolean hStretchEndDragged = false;
        private boolean vStretchAreaDragged = false;
        private boolean vStretchStartDragged = false;
        private boolean vStretchEndDragged = false;

        private boolean addingHorizontalStretch = false;
        private boolean addingVerticalStretch = false;
        private boolean removingHorizontalStretch = false;
        private boolean removingVerticalStretch = false;

        private int startX = -1;
        private int startY = -1;
        private Rectangle startRect = null;

        private Insets startMargin = null;

        private NinePatchInterval changedInterval = null;
        private NinePatchInterval removedInterval = null;

        public void mouseWheelMoved ( MouseWheelEvent e )
        {
            mouseEvent ( e, MouseEventType.mouseWheelMoved );
        }

        public void mousePressed ( MouseEvent e )
        {
            mouseEvent ( e, MouseEventType.mousePressed );
        }

        public void mouseDragged ( MouseEvent e )
        {
            mouseEvent ( e, MouseEventType.mouseDragged );
        }

        public void mouseReleased ( MouseEvent e )
        {
            mouseEvent ( e, MouseEventType.mouseReleased );
        }

        public void mouseEntered ( MouseEvent e )
        {
            mouseEvent ( e, MouseEventType.mouseEntered );
        }

        public void mouseExited ( MouseEvent e )
        {
            mouseEvent ( e, MouseEventType.mouseExited );
        }

        public void mouseMoved ( MouseEvent e )
        {
            mouseEvent ( e, MouseEventType.mouseMoved );
        }

        private void mouseEvent ( MouseEvent e, MouseEventType mouseEventType )
        {
            // Current cursor position
            final int x = e.getX ();
            final int y = e.getY ();

            // Request focus on any action inside
            if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
            {
                NinePatchEditor.this.requestFocusInWindow ();
            }

            // Zoom change
            if ( !someDragged && mouseEventType.equals ( MouseEventType.mouseWheelMoved ) &&
                    ( SwingUtils.isCtrl ( e ) || SwingUtils.isAlt ( e ) ) )
            {
                MouseWheelEvent mwe = ( MouseWheelEvent ) e;
                setZoom ( getZoom () - mwe.getWheelRotation () );
                setCursor ( Cursor.getDefaultCursor () );
                return;
            }

            // Visible area drag
            if ( SwingUtilities.isMiddleMouseButton ( e ) && ( cameraDragged || !someDragged ) )
            {
                if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                {
                    someDragged = true;
                    cameraDragged = true;
                    startRect = getVisibleRect ();
                    e = SwingUtilities.convertMouseEvent ( NinePatchEditor.this, e, view );
                    startX = e.getX ();
                    startY = e.getY ();
                    setCursor ( Cursor.getPredefinedCursor ( Cursor.HAND_CURSOR ) );
                }
                else if ( cameraDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                {
                    e = SwingUtilities.convertMouseEvent ( NinePatchEditor.this, e, view );
                    view.getWebHorizontalScrollBar ().setValue ( startRect.x - ( e.getX () - startX ) );
                    view.getWebVerticalScrollBar ().setValue ( startRect.y - ( e.getY () - startY ) );
                    setCursor ( Cursor.getPredefinedCursor ( Cursor.HAND_CURSOR ) );
                }
                else if ( cameraDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                {
                    someDragged = false;
                    cameraDragged = false;
                    setCursor ( Cursor.getDefaultCursor () );
                }
                return;
            }

            // Continue only if icon presented
            if ( ninePatchIcon == null || ninePatchImage == null )
            {
                return;
            }

            // Variables
            final BufferedImage image = getImage ();
            final int cw = NinePatchEditor.this.getWidth ();
            final int ch = NinePatchEditor.this.getHeight ();
            final int iw = image.getWidth () * zoom;
            final int ih = image.getHeight () * zoom;
            final Insets margin = ninePatchIcon.getMargin ();
            final int imageStartX = ( cw + ( showRuler ? RULER_LENGTH : 0 ) ) / 2 - iw / 2;
            final int imageStartY = ( ch + ( showRuler ? RULER_LENGTH : 0 ) ) / 2 - ih / 2;

            // Content area coordinates
            final int contentStartX = getContentStartX ( imageStartX, cw, iw, margin );
            final int contentEndX = getContentEndX ( imageStartX, cw, iw, margin );
            final int contentStartY = getContentStartY ( imageStartY, ch, ih, margin );
            final int contentEndY = getContentEndY ( imageStartY, ch, ih, margin );

            // Content area drag
            if ( hContentAreaDragged ||
                    !someDragged && new Rectangle ( contentStartX, imageStartY + ih, contentEndX - contentStartX, zoom ).contains ( x, y ) )
            {
                // Dragging horizontal content area
                if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                {
                    someDragged = true;
                    hContentAreaDragged = true;
                    startX = x;
                    startMargin = margin;
                }
                else if ( hContentAreaDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                {
                    int changeX = ( x - startX ) / zoom;
                    int left = startMargin.left + changeX;
                    if ( left < 0 )
                    {
                        left = 0;
                    }
                    if ( left > image.getWidth () - 1 )
                    {
                        left = image.getWidth () - 1;
                    }
                    int right = startMargin.right - changeX;
                    if ( right < 0 )
                    {
                        right = 0;
                    }
                    if ( right > image.getWidth () - 1 )
                    {
                        right = image.getWidth () - 1;
                    }
                    ninePatchIcon.setMargin ( new Insets ( startMargin.top, left, startMargin.bottom, right ) );
                    repaint ();
                    fireStateChanged ();
                }
                else if ( hContentAreaDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                {
                    someDragged = false;
                    hContentAreaDragged = false;
                    saveHistoryState ();
                    fireStateChanged ();
                }
                setCursor ( Cursor.getPredefinedCursor ( Cursor.MOVE_CURSOR ) );
                return;
            }
            if ( vContentAreaDragged ||
                    !someDragged && new Rectangle ( imageStartX + iw, contentStartY, zoom, contentEndY - contentStartY ).contains ( x, y ) )
            {
                // Dragging vertical content area
                if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                {
                    someDragged = true;
                    vContentAreaDragged = true;
                    startY = y;
                    startMargin = margin;
                }
                else if ( vContentAreaDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                {
                    int changeY = ( y - startY ) / zoom;
                    int top = startMargin.top + changeY;
                    if ( top < 0 )
                    {
                        top = 0;
                    }
                    if ( top > image.getHeight () - 1 )
                    {
                        top = image.getHeight () - 1;
                    }
                    int bottom = startMargin.bottom - changeY;
                    if ( bottom < 0 )
                    {
                        bottom = 0;
                    }
                    if ( bottom > image.getHeight () - 1 )
                    {
                        bottom = image.getHeight () - 1;
                    }
                    ninePatchIcon.setMargin ( new Insets ( top, startMargin.left, bottom, startMargin.right ) );
                    repaint ();
                    fireStateChanged ();
                }
                else if ( vContentAreaDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                {
                    someDragged = false;
                    vContentAreaDragged = false;
                    saveHistoryState ();
                    fireStateChanged ();
                }
                setCursor ( Cursor.getPredefinedCursor ( Cursor.MOVE_CURSOR ) );
                return;
            }

            // Content area resize
            if ( hContentStartDragged || !someDragged && y >= imageStartY && contentStartX + getSnap () >= x &&
                    contentStartX - getSnap () <= x )
            {
                // Dragging horizontal content area start
                if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                {
                    someDragged = true;
                    hContentStartDragged = true;
                    startX = x;
                    startMargin = margin;
                }
                else if ( hContentStartDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                {
                    int changeX = ( x - startX ) / zoom;
                    int left = startMargin.left + changeX;
                    if ( left < 0 )
                    {
                        left = 0;
                    }
                    if ( left > image.getWidth () - startMargin.right - 1 )
                    {
                        left = image.getWidth () - startMargin.right - 1;
                    }
                    ninePatchIcon.setMargin ( new Insets ( startMargin.top, left, startMargin.bottom, startMargin.right ) );
                    repaint ();
                    fireStateChanged ();
                }
                else if ( hContentStartDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                {
                    someDragged = false;
                    hContentStartDragged = false;
                    saveHistoryState ();
                    fireStateChanged ();
                }
                setCursor ( Cursor.getPredefinedCursor ( Cursor.E_RESIZE_CURSOR ) );
                return;
            }
            if ( hContentEndDragged || !someDragged && y >= imageStartY && contentEndX + getSnap () >= x &&
                    contentEndX - getSnap () <= x )
            {
                // Dragging horizontal content area end
                if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                {
                    someDragged = true;
                    hContentEndDragged = true;
                    startX = x;
                    startMargin = margin;
                }
                else if ( hContentEndDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                {
                    int changeX = ( x - startX ) / zoom;
                    int right = startMargin.right - changeX;
                    if ( right < 0 )
                    {
                        right = 0;
                    }
                    if ( right > image.getWidth () - startMargin.left - 1 )
                    {
                        right = image.getWidth () - startMargin.left - 1;
                    }
                    ninePatchIcon.setMargin ( new Insets ( startMargin.top, startMargin.left, startMargin.bottom, right ) );
                    repaint ();
                    fireStateChanged ();
                }
                else if ( hContentEndDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                {
                    someDragged = false;
                    hContentEndDragged = false;
                    saveHistoryState ();
                    fireStateChanged ();
                }
                setCursor ( Cursor.getPredefinedCursor ( Cursor.E_RESIZE_CURSOR ) );
                return;
            }
            if ( vContentStartDragged || !someDragged && x >= imageStartX && contentStartY + getSnap () >= y &&
                    contentStartY - getSnap () <= y )
            {
                // Dragging vertical content area start
                if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                {
                    someDragged = true;
                    vContentStartDragged = true;
                    startY = y;
                    startMargin = margin;
                }
                else if ( vContentStartDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                {
                    int changeY = ( y - startY ) / zoom;
                    int top = startMargin.top + changeY;
                    if ( top < 0 )
                    {
                        top = 0;
                    }
                    if ( top > image.getHeight () - startMargin.bottom - 1 )
                    {
                        top = image.getHeight () - startMargin.bottom - 1;
                    }
                    ninePatchIcon.setMargin ( new Insets ( top, startMargin.left, startMargin.bottom, startMargin.right ) );
                    repaint ();
                    fireStateChanged ();
                }
                else if ( vContentStartDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                {
                    someDragged = false;
                    vContentStartDragged = false;
                    saveHistoryState ();
                    fireStateChanged ();
                }
                setCursor ( Cursor.getPredefinedCursor ( Cursor.S_RESIZE_CURSOR ) );
                return;
            }
            if ( vContentEndDragged || !someDragged && x >= imageStartX && contentEndY + getSnap () >= y &&
                    contentEndY - getSnap () <= y )
            {
                // Dragging vertical content area end
                if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                {
                    someDragged = true;
                    vContentEndDragged = true;
                    startY = y;
                    startMargin = margin;
                }
                else if ( vContentEndDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                {
                    int changeY = ( y - startY ) / zoom;
                    int bottom = startMargin.bottom - changeY;
                    if ( bottom < 0 )
                    {
                        bottom = 0;
                    }
                    if ( bottom > image.getHeight () - startMargin.top - 1 )
                    {
                        bottom = image.getHeight () - startMargin.top - 1;
                    }
                    ninePatchIcon.setMargin ( new Insets ( startMargin.top, startMargin.left, bottom, startMargin.right ) );
                    repaint ();
                    fireStateChanged ();
                }
                else if ( vContentEndDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                {
                    someDragged = false;
                    vContentEndDragged = false;
                    saveHistoryState ();
                    fireStateChanged ();
                }
                setCursor ( Cursor.getPredefinedCursor ( Cursor.S_RESIZE_CURSOR ) );
                return;
            }

            // Stretch
            for ( NinePatchInterval npi : ninePatchIcon.getHorizontalStretch () )
            {
                if ( !npi.isPixel () )
                {
                    // Stretch areas drag
                    if ( hStretchAreaDragged && changedInterval.isSame ( npi ) || !someDragged &&
                            new Rectangle ( imageStartX + npi.getStart () * zoom, imageStartY - zoom,
                                    ( npi.getEnd () - npi.getStart () + 1 ) * zoom, zoom + ( fillStretchAreas ? ih : 0 ) )
                                    .contains ( x, y ) )
                    {
                        // Dragging horizontal stretch area
                        if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                        {
                            someDragged = true;
                            hStretchAreaDragged = true;
                            startX = x;
                            changedInterval = npi.clone ();
                        }
                        else if ( hStretchAreaDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                        {
                            int changeX = ( x - startX ) / zoom;
                            int start = changedInterval.getStart () + changeX;
                            if ( start < 0 )
                            {
                                start = 0;
                            }
                            if ( start > image.getWidth () - 1 )
                            {
                                start = image.getWidth () - 1;
                            }
                            int end = changedInterval.getEnd () + changeX;
                            if ( end < 0 )
                            {
                                end = 0;
                            }
                            if ( end > image.getWidth () - 1 )
                            {
                                end = image.getWidth () - 1;
                            }
                            npi.setStart ( start );
                            npi.setEnd ( end );
                            repaint ();
                        }
                        else if ( hStretchAreaDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                        {
                            someDragged = false;
                            hStretchAreaDragged = false;
                            verifyHorizontalStretchAreas ();
                            repaint ();
                            saveHistoryState ();
                            fireStateChanged ();
                        }
                        setCursor ( Cursor.getPredefinedCursor ( Cursor.MOVE_CURSOR ) );
                        return;
                    }

                    // Stretch areas resize cursor  
                    if ( y <= imageStartY + ih )
                    {
                        if ( hStretchStartDragged && changedInterval.isSame ( npi ) || !someDragged &&
                                imageStartX + npi.getStart () * zoom - getSnap () <= x &&
                                x <= imageStartX + npi.getStart () * zoom + getSnap () )
                        {
                            // Dragging horizontal stretch area start
                            if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                            {
                                someDragged = true;
                                hStretchStartDragged = true;
                                startX = x;
                                changedInterval = npi.clone ();
                            }
                            else if ( hStretchStartDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                            {
                                int changeX = ( x - startX ) / zoom;
                                int start = changedInterval.getStart () + changeX;
                                if ( start < 0 )
                                {
                                    start = 0;
                                }
                                if ( start > changedInterval.getEnd () )
                                {
                                    start = changedInterval.getEnd ();
                                }
                                npi.setStart ( start );
                                repaint ();
                            }
                            else if ( hStretchStartDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                            {
                                someDragged = false;
                                hStretchStartDragged = false;
                                verifyHorizontalStretchAreas ();
                                repaint ();
                                saveHistoryState ();
                                fireStateChanged ();
                            }
                            setCursor ( Cursor.getPredefinedCursor ( Cursor.E_RESIZE_CURSOR ) );
                            return;
                        }
                        if ( hStretchEndDragged && changedInterval.isSame ( npi ) || !someDragged &&
                                imageStartX + ( npi.getEnd () + 1 ) * zoom - getSnap () <= x &&
                                x <= imageStartX + ( npi.getEnd () + 1 ) * zoom + getSnap () )
                        {
                            // Dragging horizontal stretch area end
                            if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                            {
                                someDragged = true;
                                hStretchEndDragged = true;
                                startX = x;
                                changedInterval = npi.clone ();
                            }
                            else if ( hStretchEndDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                            {
                                int changeX = ( x - startX ) / zoom;
                                int end = changedInterval.getEnd () + changeX;
                                if ( end < changedInterval.getStart () )
                                {
                                    end = changedInterval.getStart ();
                                }
                                if ( end > image.getWidth () - 1 )
                                {
                                    end = image.getWidth () - 1;
                                }
                                npi.setEnd ( end );
                                repaint ();
                            }
                            else if ( hStretchEndDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                            {
                                someDragged = false;
                                hStretchEndDragged = false;
                                verifyHorizontalStretchAreas ();
                                repaint ();
                                saveHistoryState ();
                                fireStateChanged ();
                            }
                            setCursor ( Cursor.getPredefinedCursor ( Cursor.E_RESIZE_CURSOR ) );
                            return;
                        }
                    }
                }
            }
            for ( NinePatchInterval npi : ninePatchIcon.getVerticalStretch () )
            {
                if ( !npi.isPixel () )
                {
                    // Stretch areas drag
                    if ( vStretchAreaDragged && changedInterval.isSame ( npi ) || !someDragged &&
                            new Rectangle ( imageStartX - zoom, imageStartY + npi.getStart () * zoom, zoom + ( fillStretchAreas ? iw : 0 ),
                                    ( npi.getEnd () - npi.getStart () + 1 ) * zoom ).contains ( x, y ) )
                    {
                        // Dragging vertical stretch area
                        if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                        {
                            someDragged = true;
                            vStretchAreaDragged = true;
                            startY = y;
                            changedInterval = npi.clone ();
                        }
                        else if ( vStretchAreaDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                        {
                            int changeY = ( y - startY ) / zoom;
                            int start = changedInterval.getStart () + changeY;
                            if ( start < 0 )
                            {
                                start = 0;
                            }
                            if ( start > image.getHeight () - 1 )
                            {
                                start = image.getHeight () - 1;
                            }
                            int end = changedInterval.getEnd () + changeY;
                            if ( end < 0 )
                            {
                                end = 0;
                            }
                            if ( end > image.getHeight () - 1 )
                            {
                                end = image.getHeight () - 1;
                            }
                            npi.setStart ( start );
                            npi.setEnd ( end );
                            repaint ();
                        }
                        else if ( vStretchAreaDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                        {
                            someDragged = false;
                            vStretchAreaDragged = false;
                            verifyVerticalStretchAreas ();
                            repaint ();
                            saveHistoryState ();
                            fireStateChanged ();
                        }
                        setCursor ( Cursor.getPredefinedCursor ( Cursor.MOVE_CURSOR ) );
                        return;
                    }

                    // Stretch areas resize cursor  
                    if ( x <= imageStartX + iw )
                    {
                        if ( vStretchStartDragged && changedInterval.isSame ( npi ) || !someDragged &&
                                imageStartY + npi.getStart () * zoom - getSnap () <= y &&
                                y <= imageStartY + npi.getStart () * zoom + getSnap () )
                        {
                            // Dragging vertical stretch area start
                            if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                            {
                                someDragged = true;
                                vStretchStartDragged = true;
                                startY = y;
                                changedInterval = npi.clone ();
                            }
                            else if ( vStretchStartDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                            {
                                int changeY = ( y - startY ) / zoom;
                                int start = changedInterval.getStart () + changeY;
                                if ( start < 0 )
                                {
                                    start = 0;
                                }
                                if ( start > changedInterval.getEnd () )
                                {
                                    start = changedInterval.getEnd ();
                                }
                                npi.setStart ( start );
                                repaint ();
                            }
                            else if ( vStretchStartDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                            {
                                someDragged = false;
                                vStretchStartDragged = false;
                                verifyVerticalStretchAreas ();
                                repaint ();
                                saveHistoryState ();
                                fireStateChanged ();
                            }
                            setCursor ( Cursor.getPredefinedCursor ( Cursor.S_RESIZE_CURSOR ) );
                            return;
                        }
                        if ( vStretchEndDragged && changedInterval.isSame ( npi ) || !someDragged &&
                                imageStartY + ( npi.getEnd () + 1 ) * zoom - getSnap () <= y &&
                                y <= imageStartY + ( npi.getEnd () + 1 ) * zoom + getSnap () )
                        {
                            // Dragging vertical stretch area end
                            if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                            {
                                someDragged = true;
                                vStretchEndDragged = true;
                                startY = y;
                                changedInterval = npi.clone ();
                            }
                            else if ( vStretchEndDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                            {
                                int changeY = ( y - startY ) / zoom;
                                int end = changedInterval.getEnd () + changeY;
                                if ( end < changedInterval.getStart () )
                                {
                                    end = changedInterval.getStart ();
                                }
                                if ( end > image.getHeight () - 1 )
                                {
                                    end = image.getHeight () - 1;
                                }
                                npi.setEnd ( end );
                                repaint ();
                            }
                            else if ( vStretchEndDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                            {
                                someDragged = false;
                                vStretchEndDragged = false;
                                verifyVerticalStretchAreas ();
                                repaint ();
                                saveHistoryState ();
                                fireStateChanged ();
                            }
                            setCursor ( Cursor.getPredefinedCursor ( Cursor.S_RESIZE_CURSOR ) );
                            return;
                        }
                    }
                }
            }

            // Dragging content area
            if ( fillContentArea )
            {
                if ( contentAreaDragged || !someDragged &&
                        new Rectangle ( contentStartX, contentStartY, contentEndX - contentStartX, contentEndY - contentStartY )
                                .contains ( x, y ) )
                {
                    // Dragging vertical content area
                    if ( mouseEventType.equals ( MouseEventType.mousePressed ) )
                    {
                        someDragged = true;
                        contentAreaDragged = true;
                        startX = x;
                        startY = y;
                        startMargin = margin;
                    }
                    else if ( contentAreaDragged && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                    {
                        int changeY = ( y - startY ) / zoom;
                        int top = startMargin.top + changeY;
                        if ( top < 0 )
                        {
                            top = 0;
                        }
                        if ( top > image.getHeight () - 1 )
                        {
                            top = image.getHeight () - 1;
                        }
                        int bottom = startMargin.bottom - changeY;
                        if ( bottom < 0 )
                        {
                            bottom = 0;
                        }
                        if ( bottom > image.getHeight () - 1 )
                        {
                            bottom = image.getHeight () - 1;
                        }
                        int changeX = ( x - startX ) / zoom;
                        int left = startMargin.left + changeX;
                        if ( left < 0 )
                        {
                            left = 0;
                        }
                        if ( left > image.getWidth () - 1 )
                        {
                            left = image.getWidth () - 1;
                        }
                        int right = startMargin.right - changeX;
                        if ( right < 0 )
                        {
                            right = 0;
                        }
                        if ( right > image.getWidth () - 1 )
                        {
                            right = image.getWidth () - 1;
                        }
                        ninePatchIcon.setMargin ( new Insets ( top, left, bottom, right ) );
                        repaint ();
                        fireStateChanged ();
                    }
                    else if ( contentAreaDragged && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                    {
                        someDragged = false;
                        contentAreaDragged = false;
                        saveHistoryState ();
                        fireStateChanged ();
                    }
                    setCursor ( Cursor.getPredefinedCursor ( Cursor.MOVE_CURSOR ) );
                    return;
                }
            }

            // Adding new stretch areas
            if ( SwingUtilities.isLeftMouseButton ( e ) )
            {
                if ( addingHorizontalStretch || !someDragged )
                {
                    if ( mouseEventType.equals ( MouseEventType.mousePressed ) && x > imageStartX &&
                            x < imageStartX + iw && y < imageStartY )
                    {
                        someDragged = true;
                        addingHorizontalStretch = true;
                        startX = x;
                        changedInterval = new NinePatchInterval ( ( x - imageStartX ) / zoom, false );
                        ninePatchIcon.addHorizontalStretch ( changedInterval );
                        repaint ();
                    }
                    else if ( addingHorizontalStretch && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                    {
                        int start = ( startX - imageStartX ) / zoom;
                        int end = ( x - imageStartX ) / zoom;
                        changedInterval.setStart ( Math.max ( 0, Math.min ( start, end ) ) );
                        changedInterval.setEnd ( Math.min ( image.getWidth () - 1, Math.max ( start, end ) ) );
                        repaint ();
                    }
                    else if ( addingHorizontalStretch && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                    {
                        someDragged = false;
                        addingHorizontalStretch = false;
                        verifyHorizontalStretchAreas ();
                        repaint ();
                        saveHistoryState ();
                        fireStateChanged ();
                    }
                }
                if ( addingVerticalStretch || !someDragged )
                {
                    if ( mouseEventType.equals ( MouseEventType.mousePressed ) && y > imageStartY &&
                            y < imageStartY + ih && x < imageStartX )
                    {
                        someDragged = true;
                        addingVerticalStretch = true;
                        startY = y;
                        changedInterval = new NinePatchInterval ( ( y - imageStartY ) / zoom, false );
                        ninePatchIcon.addVerticalStretch ( changedInterval );
                        repaint ();
                    }
                    else if ( addingVerticalStretch && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                    {
                        int start = ( startY - imageStartY ) / zoom;
                        int end = ( y - imageStartY ) / zoom;
                        changedInterval.setStart ( Math.max ( 0, Math.min ( start, end ) ) );
                        changedInterval.setEnd ( Math.min ( image.getHeight () - 1, Math.max ( start, end ) ) );
                        repaint ();
                    }
                    else if ( addingVerticalStretch && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                    {
                        someDragged = false;
                        addingVerticalStretch = false;
                        verifyVerticalStretchAreas ();
                        repaint ();
                        saveHistoryState ();
                        fireStateChanged ();
                    }
                }
            }

            // Removing stretch areas   
            if ( SwingUtilities.isRightMouseButton ( e ) )
            {
                if ( removingHorizontalStretch || !someDragged )
                {
                    if ( mouseEventType.equals ( MouseEventType.mousePressed ) && x > imageStartX &&
                            x < imageStartX + iw && y < imageStartY )
                    {
                        someDragged = true;
                        removingHorizontalStretch = true;
                        startX = x;
                        removedInterval = new NinePatchInterval ( ( x - imageStartX ) / zoom, false );
                        finishHorizontalRemoval ();
                        repaint ();
                    }
                    else if ( removingHorizontalStretch && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                    {
                        int start = ( startX - imageStartX ) / zoom;
                        int end = ( x - imageStartX ) / zoom;
                        removedInterval.setStart ( Math.max ( 0, Math.min ( start, end ) ) );
                        removedInterval.setEnd ( Math.min ( image.getWidth () - 1, Math.max ( start, end ) ) );
                        finishHorizontalRemoval ();
                        repaint ();
                    }
                    else if ( removingHorizontalStretch && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                    {
                        someDragged = false;
                        removingHorizontalStretch = false;
                        repaint ();
                        saveHistoryState ();
                        fireStateChanged ();
                    }
                }
                if ( removingVerticalStretch || !someDragged )
                {
                    if ( mouseEventType.equals ( MouseEventType.mousePressed ) && y > imageStartY &&
                            y < imageStartY + ih && x < imageStartX )
                    {
                        someDragged = true;
                        removingVerticalStretch = true;
                        startY = y;
                        removedInterval = new NinePatchInterval ( ( y - imageStartY ) / zoom, false );
                        finishVerticalRemoval ();
                        repaint ();
                    }
                    else if ( removingVerticalStretch && mouseEventType.equals ( MouseEventType.mouseDragged ) )
                    {
                        int start = ( startY - imageStartY ) / zoom;
                        int end = ( y - imageStartY ) / zoom;
                        removedInterval.setStart ( Math.max ( 0, Math.min ( start, end ) ) );
                        removedInterval.setEnd ( Math.min ( image.getHeight () - 1, Math.max ( start, end ) ) );
                        finishVerticalRemoval ();
                        repaint ();
                    }
                    else if ( removingVerticalStretch && mouseEventType.equals ( MouseEventType.mouseReleased ) )
                    {
                        someDragged = false;
                        removingVerticalStretch = false;
                        repaint ();
                        saveHistoryState ();
                        fireStateChanged ();
                    }
                }
            }

            // Default cursor
            setCursor ( Cursor.getDefaultCursor () );
        }

        private void finishHorizontalRemoval ()
        {
            boolean[] filled = getHorizontalFilledPixels ();
            for ( int i = removedInterval.getStart (); i <= removedInterval.getEnd (); i++ )
            {
                filled[ i ] = false;
            }
            ninePatchIcon.setHorizontalStretch ( NinePatchUtils.parseStretchIntervals ( filled ) );
            validateIcon ();
        }

        private void finishVerticalRemoval ()
        {
            boolean[] filled = getVerticalFilledPixels ();
            for ( int i = removedInterval.getStart (); i <= removedInterval.getEnd (); i++ )
            {
                filled[ i ] = false;
            }
            ninePatchIcon.setVerticalStretch ( NinePatchUtils.parseStretchIntervals ( filled ) );
            validateIcon ();
        }
    }

    private void validateIcon ()
    {
        // todo
    }

    private boolean hasHorizontalStretch ()
    {
        for ( NinePatchInterval npi : ninePatchIcon.getHorizontalStretch () )
        {
            if ( !npi.isPixel () )
            {
                return true;
            }
        }
        return false;
    }

    private int getSnap ()
    {
        return Math.max ( SNAP, zoom / 2 );
    }

    private void verifyHorizontalStretchAreas ()
    {
        // Verifies that there is no excessive intervals by regrouping all pixels info
        boolean[] filled = getHorizontalFilledPixels ();
        ninePatchIcon.setHorizontalStretch ( NinePatchUtils.parseStretchIntervals ( filled ) );
    }

    private boolean[] getHorizontalFilledPixels ()
    {
        boolean[] filled = new boolean[ getImage ().getWidth () ];
        for ( NinePatchInterval npi : ninePatchIcon.getHorizontalStretch () )
        {
            for ( int i = npi.getStart (); i <= npi.getEnd (); i++ )
            {
                if ( !npi.isPixel () && i < filled.length )
                {
                    filled[ i ] = true;
                }
            }
        }
        return filled;
    }

    private void verifyVerticalStretchAreas ()
    {
        // Verifies that there is no excessive intervals by regrouping all pixels info
        boolean[] filled = getVerticalFilledPixels ();
        ninePatchIcon.setVerticalStretch ( NinePatchUtils.parseStretchIntervals ( filled ) );
    }

    private boolean[] getVerticalFilledPixels ()
    {
        boolean[] filled = new boolean[ getImage ().getHeight () ];
        for ( NinePatchInterval npi : ninePatchIcon.getVerticalStretch () )
        {
            for ( int i = npi.getStart (); i <= npi.getEnd (); i++ )
            {
                if ( !npi.isPixel () && i < filled.length )
                {
                    filled[ i ] = true;
                }
            }
        }
        return filled;
    }

    private void verifyMargin ()
    {
        // Verifies that margins fit the image size properly
        Insets margin = ninePatchIcon.getMargin ();

        int maxVmargin = getImage ().getHeight () - 1;
        if ( margin.top > maxVmargin )
        {
            margin.top = maxVmargin;
        }
        if ( margin.bottom + margin.top > maxVmargin )
        {
            margin.bottom = maxVmargin - margin.top;
        }

        int maxHmargin = getImage ().getWidth () - 1;
        if ( margin.left > maxHmargin )
        {
            margin.left = maxHmargin;
        }
        if ( margin.right + margin.left > maxHmargin )
        {
            margin.right = maxHmargin - margin.left;
        }
    }

    private void disassembleImage ( BufferedImage ninePatchImage )
    {
        // Disassembles image into editor data
        try
        {
            // If image was actually a nine-patch image
            this.ninePatchIcon = new NinePatchIcon ( ninePatchImage );
            this.ninePatchImage = ninePatchImage;
        }
        catch ( IllegalArgumentException e )
        {
            // If image is not a nine-patch image we will fix it to be one
            BufferedImage fixedImage = ImageUtils
                    .createCompatibleImage ( ninePatchImage.getWidth () + 2, ninePatchImage.getHeight () + 2, Transparency.TRANSLUCENT );
            Graphics2D g2d = fixedImage.createGraphics ();
            g2d.drawImage ( ninePatchImage, 1, 1, null );
            g2d.setPaint ( Color.BLACK );
            g2d.drawLine ( 1, 0, fixedImage.getWidth () - 2, 0 );
            g2d.drawLine ( 0, 1, 0, fixedImage.getHeight () - 2 );
            g2d.dispose ();

            this.ninePatchIcon = new NinePatchIcon ( fixedImage );
            this.ninePatchImage = fixedImage;
        }
    }

    private void assembleImage ()
    {
        // Assembles editor data into valid Nine-patch image

        // New image template
        ninePatchImage =
                ImageUtils.createCompatibleImage ( getImage ().getWidth () + 2, getImage ().getHeight () + 2, Transparency.TRANSLUCENT );
        Graphics2D g2d = ninePatchImage.createGraphics ();
        g2d.drawImage ( getImage (), 1, 1, null );
        g2d.dispose ();

        // Color to fill with marks
        int rgb = Color.BLACK.getRGB ();

        // Stretch
        boolean[] hf = getHorizontalFilledPixels ();
        for ( int i = 0; i < getImage ().getWidth (); i++ )
        {
            if ( hf[ i ] )
            {
                ninePatchImage.setRGB ( i + 1, 0, rgb );
            }
        }
        boolean[] vf = getVerticalFilledPixels ();
        for ( int i = 0; i < getImage ().getHeight (); i++ )
        {
            if ( vf[ i ] )
            {
                ninePatchImage.setRGB ( 0, i + 1, rgb );
            }
        }

        // Content
        Insets margin = ninePatchIcon.getMargin ();
        for ( int i = margin.left; i < getImage ().getWidth () - margin.right; i++ )
        {
            ninePatchImage.setRGB ( i + 1, ninePatchImage.getHeight () - 1, rgb );
        }
        for ( int i = margin.top; i < getImage ().getHeight () - margin.bottom; i++ )
        {
            ninePatchImage.setRGB ( ninePatchImage.getWidth () - 1, i + 1, rgb );
        }
    }

    protected void paintComponent ( Graphics g )
    {
        super.paintComponent ( g );

        // Editor image representation shown only when image is loaded
        if ( ninePatchIcon != null )
        {
            Graphics2D g2d = ( Graphics2D ) g;
            FontMetrics fm = g2d.getFontMetrics ();
            final BufferedImage image = getImage ();
            final int cw = getWidth ();
            final int ch = getHeight ();
            final int iw = image.getWidth () * zoom;
            final int ih = image.getHeight () * zoom;
            final Insets margin = ninePatchIcon.getMargin ();
            final int imageStartX = ( cw + ( showRuler ? RULER_LENGTH : 0 ) ) / 2 - iw / 2;
            final int imageStartY = ( ch + ( showRuler ? RULER_LENGTH : 0 ) ) / 2 - ih / 2;
            Stroke stroke = g2d.getStroke ();

            // Alpha-background
            LafUtils.drawAlphaBackground ( g2d, imageStartX, imageStartY, iw, ih );

            // Border
            g2d.setPaint ( Color.DARK_GRAY );
            g2d.drawRect ( imageStartX, imageStartY, iw, ih );

            // Background image
            g.drawImage ( image, imageStartX, imageStartY, iw, ih, null );

            // Editor stretch guidelines
            g2d.setStroke ( StyleConstants.guidelinesStroke );
            for ( NinePatchInterval npi : ninePatchIcon.getHorizontalStretch () )
            {
                if ( !npi.isPixel () )
                {
                    // Stretched area
                    if ( fillStretchAreas )
                    {
                        g2d.setPaint ( STRETCH_COLOR );
                        g2d.fillRect ( imageStartX + npi.getStart () * zoom, imageStartY, ( npi.getEnd () - npi.getStart () + 1 ) * zoom,
                                ih );
                    }

                    // Stretched area guidelines
                    g2d.setPaint ( STRETCH_GUIDELINES_COLOR );
                    g2d.drawLine ( imageStartX + npi.getStart () * zoom, 0, imageStartX + npi.getStart () * zoom, imageStartY + ih - 1 );
                    g2d.drawLine ( imageStartX + ( npi.getEnd () + 1 ) * zoom, 0, imageStartX + ( npi.getEnd () + 1 ) * zoom,
                            imageStartY + ih - 1 );

                    // Visual representation of nine-patch image information
                    g2d.setPaint ( Color.BLACK );
                    g2d.fillRect ( imageStartX + npi.getStart () * zoom + 1, imageStartY - zoom,
                            ( npi.getEnd () - npi.getStart () + 1 ) * zoom - 1, zoom );
                }
            }
            for ( NinePatchInterval npi : ninePatchIcon.getVerticalStretch () )
            {
                if ( !npi.isPixel () )
                {
                    // Stretched area
                    if ( fillStretchAreas )
                    {
                        g2d.setPaint ( STRETCH_COLOR );
                        g2d.fillRect ( imageStartX, imageStartY + npi.getStart () * zoom, iw,
                                ( npi.getEnd () - npi.getStart () + 1 ) * zoom );
                    }

                    // Stretched area guidelines
                    g2d.setPaint ( STRETCH_GUIDELINES_COLOR );
                    g2d.drawLine ( 0, imageStartY + npi.getStart () * zoom, imageStartX + iw - 1, imageStartY + npi.getStart () * zoom );
                    g2d.drawLine ( 0, imageStartY + ( npi.getEnd () + 1 ) * zoom, imageStartX + iw - 1,
                            imageStartY + ( npi.getEnd () + 1 ) * zoom );

                    // Visual representation of nine-patch image information
                    g2d.setPaint ( Color.BLACK );
                    g2d.fillRect ( imageStartX - zoom, imageStartY + npi.getStart () * zoom + 1, zoom,
                            ( npi.getEnd () - npi.getStart () + 1 ) * zoom - 1 );
                }
            }

            // Editor content area
            int csx = getContentStartX ( imageStartX, cw, iw, margin );
            int cex = getContentEndX ( imageStartX, cw, iw, margin );
            int csy = getContentStartY ( imageStartY, ch, ih, margin );
            int cey = getContentEndY ( imageStartY, ch, ih, margin );
            if ( fillContentArea )
            {
                g2d.setPaint ( CONTENT_COLOR );
                g2d.fillRect ( csx + 1, csy + 1, iw - ( margin.left + margin.right ) * zoom - 1,
                        ih - ( margin.top + margin.bottom ) * zoom - 1 );
            }
            g2d.setPaint ( CONTENT_GUIDELINES_COLOR );
            g2d.drawLine ( csx, imageStartY, csx, ch );
            g2d.drawLine ( cex, imageStartY, cex, ch );
            g2d.drawLine ( imageStartX, csy, cw, csy );
            g2d.drawLine ( imageStartX, cey, cw, cey );

            // Visual representation of nine-patch image information
            g2d.setPaint ( Color.BLACK );
            g2d.fillRect ( imageStartX + iw + 1, csy + 1, zoom, cey - csy - 1 );
            g2d.fillRect ( csx + 1, imageStartY + ih + 1, cex - csx - 1, zoom );

            // Restoring old stroke
            g2d.setStroke ( stroke );

            // Spaces between all guides at top and left sides
            if ( showGuideSpacing )
            {
                g2d.setPaint ( Color.BLACK );
                List<Integer> horizontalGuides = getHorizontalGuides ();
                for ( int i = 0; i < horizontalGuides.size () - 1; i++ )
                {
                    Integer guide = horizontalGuides.get ( i );
                    Integer nextGuide = horizontalGuides.get ( i + 1 );
                    Integer x1 = imageStartX + guide * zoom;
                    Integer x2 = imageStartX + nextGuide * zoom;
                    int y1 = imageStartY - zoom - 10;
                    int y2 = imageStartY - zoom - 7;
                    g2d.drawLine ( x1, y1, x2, y1 );
                    g2d.drawLine ( x1, y1, x1, y2 );
                    g2d.drawLine ( x2, y1, x2, y2 );

                    String px = "" + ( nextGuide - guide );
                    g2d.drawString ( px, ( x1 + x2 ) / 2 - fm.stringWidth ( px ) / 2, imageStartY - zoom - 15 );
                }
                List<Integer> verticalGuides = getVerticalGuides ();
                for ( int i = 0; i < verticalGuides.size () - 1; i++ )
                {
                    Integer guide = verticalGuides.get ( i );
                    Integer nextGuide = verticalGuides.get ( i + 1 );
                    Integer y1 = imageStartY + guide * zoom;
                    Integer y2 = imageStartY + nextGuide * zoom;
                    int x1 = imageStartX - zoom - 10;
                    int x2 = imageStartX - zoom - 7;
                    g2d.drawLine ( x1, y1, x1, y2 );
                    g2d.drawLine ( x1, y1, x2, y1 );
                    g2d.drawLine ( x1, y2, x2, y2 );

                    String px = "" + ( nextGuide - guide );
                    g2d.drawString ( px, x1 - fm.stringWidth ( px ) - 5, ( y1 + y2 ) / 2 + fm.getAscent () / 2 );
                }
            }

            // Ruler
            if ( showRuler )
            {
                drawRuler ( g2d, new Point ( imageStartX - 1, imageStartY - 1 ) );
            }
        }
    }

    private void drawRuler ( Graphics2D g2d, Point zp )
    {
        // Variables
        Rectangle vr = NinePatchEditor.this.getVisibleRect ();
        int minorTick = getMinorTicks ();
        int majorTick = getMajorTicks ();
        int ppu = zoom;

        // Ruler background
        g2d.setPaint ( new GradientPaint ( vr.x, vr.y, METRICS_TOP, vr.x, vr.y + RULER_LENGTH, METRICS_BOTTOM ) );
        g2d.fillRect ( vr.x, vr.y, vr.width, RULER_LENGTH );
        g2d.setPaint ( new GradientPaint ( vr.x, vr.y, METRICS_TOP, vr.x + RULER_LENGTH, vr.y, METRICS_BOTTOM ) );
        g2d.fillRect ( vr.x, vr.y, RULER_LENGTH, vr.height );

        g2d.setPaint ( Color.BLACK );
        String number;
        int i;

        // Horizontal marks
        i = vr.x + ( zp.x - vr.x ) % minorTick;
        for ( int j = i; j <= vr.x + vr.width; j += minorTick )
        {
            g2d.drawLine ( j, vr.y + RULER_LENGTH - 6, j, vr.y + RULER_LENGTH );
        }
        i = vr.x + ( zp.x - vr.x ) % majorTick;
        for ( int j = i; j <= vr.x + vr.width; j += majorTick )
        {
            g2d.drawLine ( j, vr.y + RULER_LENGTH - 15, j, vr.y + RULER_LENGTH );

            number = "" + ( ( j - zp.x ) / ppu );
            g2d.drawString ( number, j + 2, vr.y + RULER_LENGTH - 10 );
        }
        g2d.setPaint ( Color.BLACK );
        g2d.drawLine ( vr.x + RULER_LENGTH, vr.y + RULER_LENGTH, vr.x + vr.width, vr.y + RULER_LENGTH );

        // Vertical marks
        i = vr.y + ( zp.y - vr.y ) % minorTick;
        for ( int j = i; j <= vr.y + vr.height; j += minorTick )
        {
            g2d.drawLine ( vr.x + RULER_LENGTH - 6, j, vr.x + RULER_LENGTH, j );
        }
        i = vr.y + ( zp.y - vr.y ) % majorTick;
        for ( int j = i; j <= vr.y + vr.height; j += majorTick )
        {
            g2d.drawLine ( vr.x + RULER_LENGTH - 15, j, vr.x + RULER_LENGTH, j );

            number = "" + ( ( j - zp.y ) / ppu );
            g2d.rotate ( Math.toRadians ( -90 ) );
            g2d.drawString ( number, 1 - j - getFontMetrics ( getFont () ).stringWidth ( number ) - 2, vr.x + RULER_LENGTH - 10 );
            g2d.rotate ( Math.toRadians ( 90 ) );
        }
        g2d.setPaint ( Color.BLACK );
        g2d.drawLine ( vr.x + RULER_LENGTH, vr.y + RULER_LENGTH, vr.x + RULER_LENGTH, vr.y + vr.height );

        // Ruler corner
        g2d.setPaint ( Color.WHITE );
        g2d.fillRect ( vr.x, vr.y, RULER_LENGTH, RULER_LENGTH );
        String unitsName = zoom + "x";
        FontMetrics fm = g2d.getFontMetrics ();
        g2d.setPaint ( Color.DARK_GRAY );
        g2d.drawString ( unitsName, vr.x + RULER_LENGTH / 2 - fm.stringWidth ( unitsName ) / 2,
                vr.y + RULER_LENGTH / 2 + fm.getHeight () / 4 );
        g2d.setPaint ( Color.BLACK );
        g2d.drawLine ( vr.x + RULER_LENGTH, vr.y, vr.x + RULER_LENGTH, vr.y + RULER_LENGTH );
        g2d.drawLine ( vr.x, vr.y + RULER_LENGTH, vr.x + RULER_LENGTH, vr.y + RULER_LENGTH );
    }

    private int getMajorTicks ()
    {
        switch ( zoom )
        {
            case 1:
                return zoom * 50;
            case 2:
                return zoom * 20;
            case 3:
                return zoom * 20;
            case 4:
                return zoom * 10;
            case 5:
                return zoom * 10;
            case 6:
                return zoom * 10;
            default:
                return zoom * 5;
        }
    }

    private int getMinorTicks ()
    {
        switch ( zoom )
        {
            case 1:
                return zoom * 5;
            case 2:
                return zoom * 5;
            case 3:
                return zoom * 2;
            case 4:
                return zoom * 2;
            case 5:
                return zoom;
            case 6:
                return zoom;
            default:
                return zoom;
        }
    }

    private List<Integer> getHorizontalGuides ()
    {
        List<Integer> horizontalGuides = new ArrayList<Integer> ();

        // Stretch guides
        for ( NinePatchInterval npi : ninePatchIcon.getHorizontalStretch () )
        {
            if ( !horizontalGuides.contains ( npi.getStart () ) )
            {
                horizontalGuides.add ( npi.getStart () );
            }
            if ( !horizontalGuides.contains ( npi.getEnd () + 1 ) )
            {
                horizontalGuides.add ( npi.getEnd () + 1 );
            }
        }

        // Content guides
        Insets margin = ninePatchIcon.getMargin ();
        if ( !horizontalGuides.contains ( margin.left ) )
        {
            horizontalGuides.add ( margin.left );
        }
        if ( !horizontalGuides.contains ( getImage ().getWidth () - margin.right ) )
        {
            horizontalGuides.add ( getImage ().getWidth () - margin.right );
        }

        // Sort ascending
        Collections.sort ( horizontalGuides );

        return horizontalGuides;
    }

    private List<Integer> getVerticalGuides ()
    {
        List<Integer> verticalGuides = new ArrayList<Integer> ();

        // Stretch guides
        for ( NinePatchInterval npi : ninePatchIcon.getVerticalStretch () )
        {
            if ( !verticalGuides.contains ( npi.getStart () ) )
            {
                verticalGuides.add ( npi.getStart () );
            }
            if ( !verticalGuides.contains ( npi.getEnd () + 1 ) )
            {
                verticalGuides.add ( npi.getEnd () + 1 );
            }
        }

        // Content guides
        Insets margin = ninePatchIcon.getMargin ();
        if ( !verticalGuides.contains ( margin.top ) )
        {
            verticalGuides.add ( margin.top );
        }
        if ( !verticalGuides.contains ( getImage ().getHeight () - margin.bottom ) )
        {
            verticalGuides.add ( getImage ().getHeight () - margin.bottom );
        }

        // Sort ascending
        Collections.sort ( verticalGuides );

        return verticalGuides;
    }

    private int getContentStartX ( int imageStartX, int cw, int iw, Insets margin )
    {
        return imageStartX + margin.left * zoom;
    }

    private int getContentEndX ( int imageStartX, int cw, int iw, Insets margin )
    {
        return imageStartX + iw - margin.right * zoom;
    }

    private int getContentStartY ( int imageStartY, int ch, int ih, Insets margin )
    {
        return imageStartY + margin.top * zoom;
    }

    private int getContentEndY ( int imageStartY, int ch, int ih, Insets margin )
    {
        return imageStartY + ih - margin.bottom * zoom;
    }

    public Dimension getPreferredSize ()
    {
        return new Dimension ( RULER_LENGTH +
                ( ( ninePatchImage != null ? ninePatchImage.getWidth () : 0 ) + 2 ) * zoom +
                ADDITIONAL_SPACE, RULER_LENGTH +
                ( ( ninePatchImage != null ? ninePatchImage.getHeight () : 0 ) + 2 ) * zoom +
                ADDITIONAL_SPACE );
    }

    public List<ChangeListener> getChangeListeners ()
    {
        return changeListeners;
    }

    public void addChangeListener ( ChangeListener changeListener )
    {
        changeListeners.add ( changeListener );
    }

    public void removeChangeListener ( ChangeListener changeListener )
    {
        changeListeners.add ( changeListener );
    }

    private void fireStateChanged ()
    {
        ChangeEvent changeEvent = new ChangeEvent ( NinePatchEditor.this );
        for ( ChangeListener listener : CollectionUtils.clone ( changeListeners ) )
        {
            listener.stateChanged ( changeEvent );
        }
    }

    public List<ZoomChangeListener> getZoomChangeListeners ()
    {
        return zoomChangeListeners;
    }

    public void addZoomChangeListener ( ZoomChangeListener zoomChangeListener )
    {
        zoomChangeListeners.add ( zoomChangeListener );
    }

    public void removeZoomChangeListener ( ZoomChangeListener zoomChangeListener )
    {
        zoomChangeListeners.add ( zoomChangeListener );
    }

    private void fireZoomChanged ()
    {
        for ( ZoomChangeListener listener : CollectionUtils.clone ( zoomChangeListeners ) )
        {
            listener.zoomChanged ();
        }
    }
}
