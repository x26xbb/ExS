/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.colorchooser;

import com.alee.laf.StyleConstants;
import com.alee.laf.button.WebButton;
import com.alee.laf.checkbox.WebCheckBox;
import com.alee.laf.panel.WebPanel;
import com.alee.laf.separator.WebSeparator;
import com.alee.managers.hotkey.Hotkey;
import com.alee.managers.hotkey.HotkeyManager;
import com.alee.managers.language.LM;
import com.alee.utils.SwingUtils;
import info.clearthought.layout.TableLayout;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * User: mgarin Date: 01.02.2010 Time: 15:00:20
 */

public class WebColorChooser extends JDialog
{
    public static final ImageIcon COLOR_CHOOSER_ICON = new ImageIcon ( WebColorChooser.class.getResource ( "icons/color_chooser.png" ) );

    private WebColorChooserPanel guiColorChooserPanel;
    private WebCheckBox webOnly;
    private WebButton ok;
    private WebButton reset;
    private WebButton cancel;

    private int result = StyleConstants.NONE_OPTION;

    public WebColorChooser ()
    {
        this ( ( Window ) null );
    }

    public WebColorChooser ( Component parent )
    {
        this ( parent, null );
    }

    public WebColorChooser ( String title )
    {
        this ( null, title );
    }

    public WebColorChooser ( Component parent, String title )
    {
        super ( SwingUtils.getWindowAncestor ( parent ) );
        updateTitle ( title );
        setIconImage ( COLOR_CHOOSER_ICON.getImage () );

        // Hotkeys preview action
        HotkeyManager.installShowAllHotkeysAction ( this, Hotkey.F1 );

        getContentPane ().setLayout ( new BorderLayout ( 0, 0 ) );


        guiColorChooserPanel = new WebColorChooserPanel ();
        getContentPane ().add ( guiColorChooserPanel, BorderLayout.CENTER );


        TableLayout layout = new TableLayout ( new double[][]{
                { 8, TableLayout.PREFERRED, TableLayout.FILL, TableLayout.PREFERRED, 0, TableLayout.PREFERRED, 0, TableLayout.PREFERRED,
                        2 }, { TableLayout.PREFERRED, 2, TableLayout.PREFERRED, 2 } } );
        layout.setHGap ( 2 );
        layout.setVGap ( 2 );
        WebPanel buttonsPanel = new WebPanel ( layout );
        getContentPane ().add ( buttonsPanel, BorderLayout.SOUTH );

        buttonsPanel.add ( new WebSeparator ( WebSeparator.HORIZONTAL ), "0,0,8,0" );

        webOnly = new WebCheckBox ();
        LM.registerComponent ( webOnly, "weblaf.colorchooser.webonly" );
        webOnly.setSelected ( guiColorChooserPanel.isWebOnlyColors () );
        webOnly.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                guiColorChooserPanel.setWebOnlyColors ( webOnly.isSelected () );
            }
        } );
        buttonsPanel.add ( webOnly, "1,2" );

        ok = new WebButton ();
        LM.registerComponent ( ok, "weblaf.colorchooser.choose" );
        ok.addHotkey ( WebColorChooser.this, Hotkey.ENTER );
        if ( StyleConstants.highlightControlButtons )
        {
            ok.setShineColor ( StyleConstants.greenHighlight );
        }
        ok.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                result = StyleConstants.OK_OPTION;
                WebColorChooser.this.dispose ();
            }
        } );
        buttonsPanel.add ( ok, "3,2" );

        reset = new WebButton ();
        LM.registerComponent ( reset, "weblaf.colorchooser.reset" );
        reset.addHotkey ( WebColorChooser.this, Hotkey.ALT_R );
        if ( StyleConstants.highlightControlButtons )
        {
            reset.setShineColor ( StyleConstants.blueHighlight );
        }
        reset.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                guiColorChooserPanel.setColor ( guiColorChooserPanel.getOldColor () );
            }
        } );
        buttonsPanel.add ( reset, "5,2" );

        cancel = new WebButton ();
        LM.registerComponent ( cancel, "weblaf.colorchooser.cancel" );
        cancel.addHotkey ( WebColorChooser.this, Hotkey.ESCAPE );
        if ( StyleConstants.highlightControlButtons )
        {
            cancel.setShineColor ( StyleConstants.redHighlight );
        }
        cancel.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                result = StyleConstants.CANCEL_OPTION;
                guiColorChooserPanel.setColor ( guiColorChooserPanel.getOldColor () );
                WebColorChooser.this.dispose ();
            }
        } );
        buttonsPanel.add ( cancel, "7,2" );

        SwingUtils.equalizeComponentsSize ( ok, reset, cancel );


        addWindowListener ( new WindowAdapter ()
        {
            public void windowClosed ( WindowEvent e )
            {
                result = StyleConstants.CLOSE_OPTION;
            }
        } );

        setResizable ( false );
        setModal ( true );
        pack ();
        setDefaultCloseOperation ( JDialog.DISPOSE_ON_CLOSE );
    }

    public void updateTitle ( String title )
    {
        if ( title == null )
        {
            LM.registerComponent ( WebColorChooser.this, "weblaf.colorchooser.title" );
        }
        else
        {
            LM.unregisterComponent ( WebColorChooser.this );
            setTitle ( title );
        }
    }

    public int getResult ()
    {
        return result;
    }

    public int showDialog ()
    {
        setVisible ( true );
        return getResult ();
    }

    public Color getColor ()
    {
        return guiColorChooserPanel.getColor ();
    }

    public void setColor ( Color color )
    {
        guiColorChooserPanel.setColor ( color );
    }

    public void setVisible ( boolean b )
    {
        if ( b )
        {
            result = StyleConstants.NONE_OPTION;
            setLocationRelativeTo ( getOwner () );
        }
        super.setVisible ( b );
    }

    public static Color showDialog ( Component parent )
    {
        return showDialog ( parent, null, null );
    }

    public static Color showDialog ( Component parent, String title )
    {
        return showDialog ( parent, title, null );
    }

    public static Color showDialog ( Component parent, Color color )
    {
        return showDialog ( parent, null, color );
    }

    public static Color showDialog ( Component parent, String title, Color color )
    {
        WebColorChooser wcc = new WebColorChooser ( parent, title );
        if ( color != null )
        {
            wcc.setColor ( color );
        }
        wcc.setVisible ( true );
        if ( wcc.getResult () == StyleConstants.OK_OPTION )
        {
            return wcc.getColor ();
        }
        else
        {
            return null;
        }
    }
}
