/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.colorchooser;

import com.alee.managers.settings.DefaultValue;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * User: mgarin Date: 23.11.12 Time: 18:00
 */

@XStreamAlias( "GradientData" )
public class GradientData implements Serializable, DefaultValue
{
    // Sorting comparator
    private static final transient Comparator<GradientColorData> locationsComparator = new Comparator<GradientColorData> ()
    {
        public int compare ( GradientColorData o1, GradientColorData o2 )
        {
            return Float.compare ( o1.getLocation (), o2.getLocation () );
        }
    };

    @XStreamImplicit( itemFieldName = "Color" )
    private List<GradientColorData> gradientColorsData;

    public GradientData ()
    {
        super ();
        gradientColorsData = new ArrayList<GradientColorData> ();
    }

    public boolean containtsLocation ( float location )
    {
        for ( GradientColorData gradientColorData : gradientColorsData )
        {
            if ( gradientColorData.getLocation () == location )
            {
                return true;
            }
        }
        return false;
    }

    public void addGradientColorData ( GradientColorData gradientColorData )
    {
        gradientColorsData.add ( gradientColorData );
        sort ();
    }

    public void removeGradientColorData ( GradientColorData gradientColorData )
    {
        gradientColorsData.remove ( gradientColorData );
        sort ();
    }

    public List<GradientColorData> getGradientColorsData ()
    {
        sort ();
        return gradientColorsData;
    }

    public void setGradientColorsData ( List<GradientColorData> gradientColorsData )
    {
        this.gradientColorsData = gradientColorsData;
        sort ();
    }

    public float[] getFractions ()
    {
        sort ();
        float[] fractions = new float[ gradientColorsData.size () ];
        for ( int i = 0; i < gradientColorsData.size (); i++ )
        {
            fractions[ i ] = gradientColorsData.get ( i ).getLocation ();
        }
        return fractions;
    }

    public Color[] getColors ()
    {
        sort ();
        Color[] colors = new Color[ gradientColorsData.size () ];
        for ( int i = 0; i < gradientColorsData.size (); i++ )
        {
            colors[ i ] = gradientColorsData.get ( i ).getColor ();
        }
        return colors;
    }

    public int size ()
    {
        return gradientColorsData.size ();
    }

    public GradientColorData get ( int index )
    {
        return gradientColorsData.get ( index );
    }

    public float getLocation ( int index )
    {
        return get ( index ).getLocation ();
    }

    public Color getColor ( int index )
    {
        return get ( index ).getColor ();
    }

    public GradientColorData getFirst ()
    {
        return gradientColorsData.get ( 0 );
    }

    public GradientColorData getLast ()
    {
        return gradientColorsData.get ( size () - 1 );
    }

    public void sort ()
    {
        Collections.sort ( gradientColorsData, locationsComparator );
    }

    public boolean equals ( Object obj )
    {
        if ( obj == null || !( obj instanceof GradientData ) )
        {
            return false;
        }

        GradientData other = ( GradientData ) obj;
        if ( size () != other.size () )
        {
            return false;
        }

        for ( int i = 0; i < size (); i++ )
        {
            if ( !get ( i ).equals ( other.get ( i ) ) )
            {
                return false;
            }
        }
        return true;
    }

    public GradientData clone ()
    {
        GradientData lineColorLocationData = new GradientData ();
        for ( GradientColorData gradientColorData : gradientColorsData )
        {
            lineColorLocationData.addGradientColorData ( gradientColorData.clone () );
        }
        return lineColorLocationData;
    }

    public static GradientData getDefaultValue ()
    {
        GradientData gradientData = new GradientData ();
        gradientData.addGradientColorData ( new GradientColorData ( 0f, Color.RED ) );
        gradientData.addGradientColorData ( new GradientColorData ( 0.25f, Color.YELLOW ) );
        gradientData.addGradientColorData ( new GradientColorData ( 0.5f, Color.GREEN ) );
        gradientData.addGradientColorData ( new GradientColorData ( 0.75f, Color.CYAN ) );
        gradientData.addGradientColorData ( new GradientColorData ( 1f, Color.BLUE ) );
        return gradientData;
    }
}