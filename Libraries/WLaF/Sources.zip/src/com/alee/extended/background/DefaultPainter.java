/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.background;

import javax.swing.*;
import java.awt.*;

/**
 * User: mgarin Date: 14.12.11 Time: 15:37
 */

public abstract class DefaultPainter<E extends JComponent> implements Painter<E>
{
    protected boolean opaque = false;
    protected Dimension preferredSize = new Dimension ( 0, 0 );
    protected Insets margin = new Insets ( 0, 0, 0, 0 );

    public DefaultPainter ()
    {
        super ();
    }

    public boolean isOpaque ( E c )
    {
        return opaque;
    }

    public void setOpaque ( boolean opaque )
    {
        this.opaque = opaque;
    }

    public Dimension getPreferredSize ( E c )
    {
        return preferredSize;
    }

    public void setPreferredSize ( Dimension preferredSize )
    {
        this.preferredSize = preferredSize;
    }

    public Insets getMargin ( E c )
    {
        return margin;
    }

    public void setMargin ( Insets margin )
    {
        this.margin = margin;
    }

    public void setMargin ( int top, int left, int bottom, int right )
    {
        setMargin ( new Insets ( top, left, bottom, right ) );
    }

    public void setMargin ( int margin )
    {
        setMargin ( margin, margin, margin, margin );
    }
}