/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.date;

import com.alee.extended.layout.ToolbarLayout;
import com.alee.laf.StyleConstants;
import com.alee.laf.button.WebButton;
import com.alee.laf.panel.WebPanel;
import com.alee.laf.text.WebTextField;
import com.alee.managers.focus.DefaultFocusTracker;
import com.alee.managers.focus.FocusManager;
import com.alee.utils.CollectionUtils;
import com.alee.utils.SwingUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * User: mgarin Date: 03.11.11 Time: 10:24
 */

public class WebDateField extends WebPanel
{
    public static final ImageIcon selectDateIcon = new ImageIcon ( WebDateField.class.getResource ( "icons/date.png" ) );

    private List<DateSelectionListener> dateSelectionListeners = new ArrayList<DateSelectionListener> ();

    private SimpleDateFormat dateFormat = new SimpleDateFormat ( "dd.MM.yyyy" );
    private Date date = null;

    private WebTextField dateField;
    private WebButton popupButton;

    private JWindow popup;
    private WebCalendar calendar;

    public WebDateField ()
    {
        this ( new Date ( System.currentTimeMillis () ) );
    }

    public WebDateField ( boolean decorated )
    {
        this ( decorated, new Date ( System.currentTimeMillis () ) );
    }

    public WebDateField ( Date initialDate )
    {
        this ( !WebDateFieldStyle.undecorated, initialDate );
    }

    public WebDateField ( boolean decorated, Date initialDate )
    {
        super ( decorated );

        this.date = initialDate;

        putClientProperty ( SwingUtils.HANDLES_ENABLE_STATE, true );

        setOpaque ( false );
        setWebColored ( WebDateFieldStyle.webColored );
        setDrawBackground ( WebDateFieldStyle.drawBackground );
        setBackground ( WebDateFieldStyle.backgroundColor );
        setWebColored ( WebDateFieldStyle.webColored );
        setDrawFocus ( WebDateFieldStyle.drawFocus );
        setShadeWidth ( WebDateFieldStyle.shadeWidth );
        setLayout ( new ToolbarLayout ( 0, 0, ToolbarLayout.HORIZONTAL ) );

        dateField = WebTextField.createWebTextField ( false );
        dateField.setMargin ( WebDateFieldStyle.fieldMargin );
        dateField.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                setDateFromField ();
            }
        } );
        dateField.addMouseListener ( new MouseAdapter ()
        {
            public void mousePressed ( MouseEvent e )
            {
                if ( SwingUtilities.isRightMouseButton ( e ) )
                {
                    showCalendarPopup ();
                }
            }
        } );
        add ( dateField, ToolbarLayout.FILL );

        popupButton = WebButton.createIconWebButton ( selectDateIcon, WebDateFieldStyle.round );
        popupButton.setFocusable ( false );
        popupButton.setDrawLeft ( false );
        popupButton.setDrawLeftLine ( true );
        popupButton.setRolloverDarkBorderOnly ( false );
        popupButton.setShadeWidth ( 0 );
        popupButton.addActionListener ( new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                showCalendarPopup ();
            }
        } );
        add ( popupButton, ToolbarLayout.END );

        updateDateText ();

        // Initializing default styles
        setRound ( WebDateFieldStyle.round );
        setMargin ( decorated ? WebDateFieldStyle.margin : WebDateFieldStyle.undecoratedMargin );
    }

    public void setRound ( int round )
    {
        super.setRound ( round );
        popupButton.setRound ( round );
    }

    public void setUndecorated ( boolean undecorated )
    {
        super.setUndecorated ( undecorated );
        setMargin ( undecorated ? WebDateFieldStyle.undecoratedMargin : WebDateFieldStyle.margin );
    }

    private void showCalendarPopup ()
    {
        // Update date from field if it was changed
        setDateFromField ();

        // Create popup if it doesn't exist
        if ( popup == null || calendar == null )
        {
            Window ancestor = SwingUtils.getWindowAncestor ( this );

            // Calendar
            calendar = new WebCalendar ( date );
            calendar.setDrawFocus ( false );
            calendar.setRound ( StyleConstants.smallRound );
            calendar.setShadeWidth ( 0 );

            // Popup window
            popup = new JWindow ( ancestor );
            popup.setLayout ( new BorderLayout () );
            popup.add ( calendar );

            // Make popup background transparent
            SwingUtils.setWindowOpaque ( popup, false );

            // Correct popup size
            popup.pack ();

            // Correct popup positioning
            updatePopupLocation ();
            ancestor.addComponentListener ( new ComponentAdapter ()
            {
                public void componentMoved ( ComponentEvent e )
                {
                    if ( popup.isVisible () )
                    {
                        updatePopupLocation ();
                    }
                }

                public void componentResized ( ComponentEvent e )
                {
                    if ( popup.isVisible () )
                    {
                        updatePopupLocation ();
                    }
                }
            } );

            // Focus loss listener
            FocusManager.registerFocusTracker ( new DefaultFocusTracker ( calendar )
            {
                public boolean isTrackingEnabled ()
                {
                    return true;
                }

                public void focusChanged ( boolean focused )
                {
                    if ( !focused )
                    {
                        popup.setVisible ( false );
                    }
                }
            } );

            // Selection listener
            calendar.addDateSelectionListener ( new DateSelectionListener ()
            {
                public void dateSelected ( Date date )
                {
                    popup.setVisible ( false );
                    setDate ( date );
                    dateField.requestFocusInWindow ();
                }
            } );
        }
        else
        {
            // Updating window location
            updatePopupLocation ();

            // Updating date
            calendar.setDate ( date, false );
        }

        // Applying orientation to popup
        SwingUtils.copyOrientation ( WebDateField.this, popup );

        // Showing popup and changing focus
        popup.setVisible ( true );
        calendar.requestFocusInWindow ();
    }

    private void updatePopupLocation ()
    {
        final Point los = WebDateField.this.getLocationOnScreen ();
        final Rectangle gb = popup.getGraphicsConfiguration ().getBounds ();
        final int shadeWidth = isUndecorated () ? 0 : getShadeWidth ();
        final boolean ltr = WebDateField.this.getComponentOrientation ().isLeftToRight ();
        final int w = WebDateField.this.getWidth ();
        final int h = WebDateField.this.getHeight ();

        final int x;
        if ( ltr )
        {
            if ( los.x + shadeWidth + popup.getWidth () <= gb.x + gb.width )
            {
                x = los.x + shadeWidth;
            }
            else
            {
                x = los.x + w - shadeWidth - popup.getWidth ();
            }
        }
        else
        {
            if ( los.x + w - shadeWidth - popup.getWidth () >= gb.x )
            {
                x = los.x + w - shadeWidth - popup.getWidth ();
            }
            else
            {
                x = los.x + shadeWidth;
            }
        }

        final int y;
        if ( los.y + h + popup.getHeight () <= gb.y + gb.height )
        {
            y = los.y + h + ( isUndecorated () ? 1 : 0 );
        }
        else
        {
            y = los.y - popup.getHeight () - ( isUndecorated () ? 1 : 0 );
        }

        popup.setLocation ( x, y );
    }

    private void setDateFromField ()
    {
        try
        {
            setDate ( dateFormat.parse ( dateField.getText () ) );
        }
        catch ( Throwable ex )
        {
            setDate ( date );
        }
    }

    private void updateDateText ()
    {
        dateField.setText ( dateFormat.format ( date ) );
    }

    public Date getDate ()
    {
        return date;
    }

    public void setDate ( Date date )
    {
        if ( !SwingUtils.equals ( this.date, date ) )
        {
            this.date = date;
            updateDateText ();
            fireDateSelected ( date );
        }
    }

    public SimpleDateFormat getDateFormat ()
    {
        return dateFormat;
    }

    public void setDateFormat ( SimpleDateFormat dateFormat )
    {
        this.dateFormat = dateFormat;
        updateDateText ();
    }

    public void setEnabled ( boolean enabled )
    {
        dateField.setEnabled ( enabled );
        popupButton.setEnabled ( enabled );
        super.setEnabled ( enabled );
    }

    public WebTextField getDateField ()
    {
        return dateField;
    }

    public WebButton getPopupButton ()
    {
        return popupButton;
    }

    public void addDateSelectionListener ( DateSelectionListener dateSelectionListener )
    {
        dateSelectionListeners.add ( dateSelectionListener );
    }

    public void removeDateSelectionListener ( DateSelectionListener dateSelectionListener )
    {
        dateSelectionListeners.remove ( dateSelectionListener );
    }

    private void fireDateSelected ( Date date )
    {
        for ( DateSelectionListener listener : CollectionUtils.clone ( dateSelectionListeners ) )
        {
            listener.dateSelected ( date );
        }
    }
}
