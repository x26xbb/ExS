///*
// * This file is part of WebLookAndFeel library.
// *
// * WebLookAndFeel library is free software: you can redistribute it and/or modify
// * it under the terms of the GNU General Public License as published by
// * the Free Software Foundation, either version 3 of the License, or
// * (at your option) any later version.
// *
// * WebLookAndFeel library is distributed in the hope that it will be useful,
// * but WITHOUT ANY WARRANTY; without even the implied warranty of
// * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// * GNU General Public License for more details.
// *
// * You should have received a copy of the GNU General Public License
// * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
// */
//
//package com.alee.extended.transition.transition;
//
//import com.alee.extended.transition.ImageTransition;
//import com.alee.utils.LafUtils;
//
//import java.awt.*;
//
///**
// * User: mgarin Date: 09.11.12 Time: 18:56
// */
//
//public class ZoomTransitionEffect extends DefaultTransitionEffect
//{
//    private static final String ZOOM_INITIAL_RECT = "ZOOM_INITIAL_RECT";
//    private static final String ZOOM_SPEED = "ZOOM_SPEED";
//
//    private float zoomSpeed = 0.05f;
//    private float zoomProgress = 0f;
//    private Rectangle newRect = null;
//
//    public boolean performAnimationTick ( ImageTransition imageTransition )
//    {
//        // Zoom effect
//        if ( !animating )
//        {
//            animating = true;
//
//            // Updating settings
//            int fs = getInt ( ZOOM_SPEED );
//            if ( fs != -1 )
//            {
//                zoomSpeed = fs;
//            }
//
//            // todo
//            if ( newRect == null )
//            {
//                newRect = new Rectangle ( ImageTransition.this.getWidth () / 2, ImageTransition.this.getHeight () / 2, 0, 0 );
//            }
//
//            zoomProgress = 0f;
//            ImageTransition.this.repaint ();
//        }
//        else
//        {
//            if ( zoomProgress < 1f )
//            {
//                zoomProgress = Math.min ( zoomProgress + zoomSpeed, 1f );
//                ImageTransition.this.repaint ();
//            }
//            else
//            {
//                animating = false;
//                animator.stop ();
//                finishTransition ();
//            }
//        }
//    }
//
//    public void paint ( Graphics2D g2d, ImageTransition imageTransition )
//    {
//        int width = ImageTransition.this.getWidth ();
//        int height = ImageTransition.this.getHeight ();
//        Rectangle finalRect = new Rectangle ( 0, 0, width, height );
//
//        Rectangle currentRect = new Rectangle ( 0, 0, Math.round ( width * ( 1 + zoomProgress * width / newRect.width ) ),
//                Math.round ( height * ( 1 + zoomProgress * height / newRect.height ) ) );
//        currentRect.x = ( width - currentRect.width ) / 2;
//        currentRect.y = ( ImageTransition.this.getHeight () - currentRect.height ) / 2;
//
//        Composite old = LafUtils.setupAlphaComposite ( g2d, 1f - zoomProgress );
//        g2d.drawImage ( currentImage, currentRect.x, currentRect.y, currentRect.width, currentRect.height, null );
//        LafUtils.restoreComposite ( g2d, old );
//    }
//}
