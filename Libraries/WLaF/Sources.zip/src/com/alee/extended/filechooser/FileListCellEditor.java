/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.filechooser;

import com.alee.laf.StyleConstants;
import com.alee.laf.list.editor.DefaultListCellEditor;
import com.alee.laf.text.WebTextField;
import com.alee.utils.FileUtils;

import javax.swing.*;
import java.io.File;

/**
 * User: mgarin Date: 07.07.11 Time: 13:28
 */

public class FileListCellEditor extends DefaultListCellEditor
{
    private Object savedSelection = null;

    public boolean isCellEditable ( JList list, int index, Object value )
    {
        // Check if file can be edited
        Object element = list.getModel ().getElementAt ( index );
        return element != null && ( ( File ) element ).getParentFile () != null &&
                super.isCellEditable ( list, index, value );
    }

    public JComponent createEditor ( JList list, int index, Object value )
    {
        // Creating name editor
        File fileValue = ( File ) value;
        String name = fileValue.getName ();
        editor = WebTextField.createWebTextField ( true, StyleConstants.smallRound, StyleConstants.shadeWidth );
        editor.setDrawFocus ( false );
        editor.setText ( name );
        editor.setSelectionStart ( 0 );
        editor.setSelectionEnd ( fileValue.isDirectory () ? name.length () : FileUtils.getFileNamePart ( name ).length () );
        return editor;
    }

    public Object getEditorValue ( JList list, int index, Object oldValue )
    {
        // Saving initial selection
        savedSelection = list.getSelectedValue ();

        // Finishing edit
        File file = ( File ) oldValue;
        File renamed = new File ( file.getParent (), editor.getText () );
        if ( file.renameTo ( renamed ) )
        {
            if ( savedSelection == oldValue )
            {
                savedSelection = renamed;
            }
            return renamed;
        }
        else
        {
            return file;
        }
    }

    public boolean updateModelValue ( JList list, int index, Object oldValue, Object newValue, boolean updateSelection )
    {
        // Updating model
        if ( list.getModel () instanceof FileListModel )
        {
            File file = ( File ) newValue;
            File oldFile = ( File ) oldValue;
            FileListModel model = ( FileListModel ) list.getModel ();

            // If name was actually changed
            if ( !oldFile.getAbsolutePath ().equals ( file.getAbsolutePath () ) )
            {
                // Updating model value
                model.setElementAt ( index, file );

                // Updating sorting
                FileUtils.sortFiles ( model.getFiles () );

                // Updating list
                if ( savedSelection != null )
                {
                    list.setSelectedValue ( savedSelection, true );
                }
                else
                {
                    list.clearSelection ();
                }
                list.repaint ();
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return super.updateModelValue ( list, index, oldValue, newValue, updateSelection );
        }
    }
}
