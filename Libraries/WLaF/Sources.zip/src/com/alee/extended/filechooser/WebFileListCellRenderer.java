/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.filechooser;

import com.alee.extended.layout.VerticalFlowLayout;
import com.alee.laf.GlobalConstants;
import com.alee.laf.WebLookAndFeel;
import com.alee.laf.label.WebLabel;
import com.alee.laf.list.WebListCellRenderer;
import com.alee.laf.list.WebListElement;
import com.alee.laf.panel.WebPanel;
import com.alee.utils.FileUtils;
import com.alee.utils.GeometryUtils;
import com.alee.utils.ImageUtils;
import com.alee.utils.SwingUtils;
import com.alee.utils.file.Description;
import info.clearthought.layout.TableLayout;

import javax.swing.*;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * User: mgarin Date: 07.08.11 Time: 3:44
 */

public class WebFileListCellRenderer extends WebListCellRenderer
{
    private static final int LENGTH = 50;

    private Map<String, ImageIcon> iconsCache = new HashMap<String, ImageIcon> ();
    private List<String> loaded = new ArrayList<String> ();

    private FilesView filesView = FilesView.tiles;
    private int editedCell = -1;

    private WebFileList list;

    private WebLabel iconLabel;
    private WebPanel descriptionPanel;
    private WebLabel nameLabel;
    private WebLabel sizeLabel;
    private WebLabel descriptionLabel;
    private WebLabel dateLabel;

    public WebFileListCellRenderer ( WebFileList list )
    {
        super ();

        this.list = list;

        iconLabel = new WebLabel ();
        iconLabel.setHorizontalAlignment ( JLabel.CENTER );
        iconLabel.setPreferredSize ( new Dimension ( 54, 54 ) );

        descriptionPanel = new WebPanel ();
        descriptionPanel.setLayout ( new VerticalFlowLayout ( VerticalFlowLayout.MIDDLE, 0, 0, true, false ) );
        descriptionPanel.setOpaque ( false );

        nameLabel = new WebLabel ();
        nameLabel.setFont ( nameLabel.getFont ().deriveFont ( Font.PLAIN ) );
        nameLabel.setForeground ( Color.BLACK );
        nameLabel.setVerticalAlignment ( JLabel.CENTER );

        descriptionLabel = new WebLabel ();
        descriptionLabel.setFont ( descriptionLabel.getFont ().deriveFont ( Font.PLAIN ) );
        descriptionLabel.setForeground ( Color.GRAY );

        sizeLabel = new WebLabel ();
        sizeLabel.setFont ( sizeLabel.getFont ().deriveFont ( Font.PLAIN ) );
        sizeLabel.setForeground ( new Color ( 49, 77, 179 ) );

        dateLabel = new WebLabel ();
        dateLabel.setFont ( dateLabel.getFont ().deriveFont ( Font.PLAIN ) );
        dateLabel.setForeground ( Color.GRAY );

        renderer.setLayout ( new BorderLayout ( 0, 0 ) );
        renderer.add ( iconLabel, BorderLayout.WEST );
        renderer.add ( descriptionPanel, BorderLayout.CENTER );
        renderer.setPreferredSize ( new Dimension ( 220, 65 ) );

        list.addPropertyChangeListener ( WebLookAndFeel.COMPONENT_ENABLED_PROPERTY, new PropertyChangeListener ()
        {
            public void propertyChange ( PropertyChangeEvent evt )
            {
                updateEnabledState ();
            }
        } );
    }

    public FilesView getFilesView ()
    {
        return filesView;
    }

    public void setFilesView ( FilesView filesView )
    {
        this.filesView = filesView;
        if ( this.filesView.equals ( FilesView.table ) )
        {
            this.filesView = FilesView.tiles;
        }
        if ( filesView.equals ( FilesView.tiles ) )
        {
            renderer.removeAll ();
            renderer.setBorder ( BorderFactory.createEmptyBorder ( 6, 6, 5, 7 ) );
            TableLayout layout = new TableLayout ( new double[][]{ { 54, TableLayout.FILL }, { TableLayout.PREFERRED } } );
            layout.setHGap ( 4 );
            renderer.setLayout ( layout );
            renderer.add ( iconLabel, "0,0" );
            renderer.add ( descriptionPanel, "1,0" );
            renderer.setPreferredSize ( new Dimension ( 220, 65 ) );
            nameLabel.setHorizontalAlignment ( JLabel.LEADING );
            nameLabel.setMargin ( 0 );
        }
        else
        {
            renderer.removeAll ();
            renderer.setBorder ( BorderFactory.createEmptyBorder ( 5, 5, 5, 5 ) );
            TableLayout layout = new TableLayout ( new double[][]{ { TableLayout.FILL, 54, TableLayout.FILL }, { 54, TableLayout.FILL } } );
            layout.setHGap ( 0 );
            layout.setVGap ( 4 );
            renderer.setLayout ( layout );
            renderer.add ( iconLabel, "1,0" );
            renderer.add ( descriptionPanel, "0,1,2,1" );
            renderer.setPreferredSize ( new Dimension ( 90, 90 ) );
            nameLabel.setHorizontalAlignment ( JLabel.CENTER );
            nameLabel.setMargin ( 0, 2, 0, 2 );
        }
        updateFixedCellSize ();
        updateEnabledState ();
    }

    private void updateEnabledState ()
    {
        SwingUtils.setEnabledRecursively ( renderer, list.isEnabled () );
    }

    public JLabel getIconLabel ()
    {
        return iconLabel;
    }

    public JPanel getDescriptionPanel ()
    {
        return descriptionPanel;
    }

    public JLabel getNameLabel ()
    {
        return nameLabel;
    }

    public JLabel getSizeLabel ()
    {
        return sizeLabel;
    }

    public JLabel getDescriptionLabel ()
    {
        return descriptionLabel;
    }

    public JLabel getDateLabel ()
    {
        return dateLabel;
    }

    public int getEditedCell ()
    {
        return editedCell;
    }

    public void setEditedCell ( int editedCell )
    {
        this.editedCell = editedCell;
    }

    public Component getListCellRendererComponent ( JList list, Object value, final int index, boolean isSelected, boolean cellHasFocus )
    {
        WebListElement renderer = ( WebListElement ) super.getListCellRendererComponent ( list, "", index, isSelected, cellHasFocus );

        final File file = ( File ) value;

        // Setting icon
        String imageSize = null;
        final String absolutePath = file.getAbsolutePath ();

        if ( iconsCache.containsKey ( absolutePath ) )
        {
            ImageIcon icon = iconsCache.get ( absolutePath );
            iconLabel.setIcon ( icon );
            if ( icon != null )
            {
                imageSize = icon.getDescription ();
            }
        }
        else
        {
            // Adding load queue
            if ( !loaded.contains ( absolutePath ) )
            {
                loaded.add ( absolutePath );
                queueFile ( file, index );
            }

            // Showing temp default image
            iconLabel.setIcon ( FileUtils.getStandartFileIcon ( file, true )/*emptyIcon*/ );
        }

        // Settings description
        Description description = FileUtils.getFileDescription ( file, imageSize );
        descriptionPanel.removeAll ();

        if ( editedCell != index )
        {
            nameLabel.setText ( description.getName () );
            descriptionPanel.add ( nameLabel );

            if ( filesView.equals ( FilesView.tiles ) )
            {
                descriptionLabel.setText ( description.getDescription () );
                descriptionPanel.add ( descriptionLabel );

                if ( description.getSize () != null )
                {
                    sizeLabel.setText ( description.getSize () );
                    descriptionPanel.add ( sizeLabel );
                }
            }

            //            if ( description.getDate () != null )
            //            {
            //                dateLabel.setText ( description.getDate () );
            //                descriptionPanel.add ( dateLabel );
            //            }
        }

        return renderer;
    }

    /**
     * Setting fixed cells size to disable full list rendering at appearance
     */

    public void updateFixedCellSize ()
    {
        if ( getFilesView ().equals ( FilesView.tiles ) )
        {
            list.setFixedCellWidth ( 220 );
            list.setFixedCellHeight ( 65 );
        }
        else
        {
            list.setFixedCellWidth ( 90 );
            list.setFixedCellHeight ( 90 );
        }
    }

    /**
     * Images load queue
     */

    private static final Object queueLock = new Object ();
    private static List<File> queue = new ArrayList<File> ();
    private static List<Integer> cells = new ArrayList<Integer> ();
    private static Thread queueThread = null;

    private void queueFile ( File file, Integer cell )
    {
        synchronized ( queueLock )
        {
            queue.add ( file );
            cells.add ( cell );
        }
        pushQueue ();
    }

    private void pushQueue ()
    {
        if ( queueThread == null || !queueThread.isAlive () )
        {
            queueThread = new Thread ( new Runnable ()
            {
                public void run ()
                {
                    boolean hasMore;
                    synchronized ( queueLock )
                    {
                        hasMore = queue.size () > 0;
                    }
                    java.util.List<Rectangle> cellRects = new ArrayList<Rectangle> ();
                    int i = 0;
                    while ( hasMore )
                    {
                        // Removing file from queue
                        File file;
                        int cell;
                        synchronized ( queueLock )
                        {
                            file = queue.get ( 0 );
                            cell = cells.get ( 0 );
                            queue.remove ( 0 );
                            cells.remove ( 0 );
                        }

                        // Retrieving image
                        final String absolutePath = file.getAbsolutePath ();
                        if ( list.isGenerateImagePreviews () && GlobalConstants.IMAGE_FORMATS
                                .contains ( FileUtils.getFileExtPart ( file.getName (), false ).toLowerCase () ) )
                        {
                            final ImageIcon thumb =
                                    ImageUtils.getImageThumbnailIcon ( list.getCachedImagesPrefix (), absolutePath, LENGTH );
                            if ( thumb != null )
                            {
                                iconsCache.put ( absolutePath, thumb );
                            }
                            else
                            {
                                iconsCache.put ( absolutePath, FileUtils.getFileIcon ( file, true ) );
                            }
                        }
                        else
                        {
                            iconsCache.put ( absolutePath, FileUtils.getFileIcon ( file, true ) );
                        }

                        synchronized ( queueLock )
                        {
                            hasMore = queue.size () > 0;
                        }

                        // Updating list element
                        cellRects.add ( list.getCellBounds ( cell, cell ) );
                        if ( !hasMore || i % 5 == 0 )
                        {
                            // Adding few cells update into queue
                            final Rectangle[] rects = cellRects.toArray ( new Rectangle[ cellRects.size () ] );
                            SwingUtilities.invokeLater ( new Runnable ()
                            {
                                public void run ()
                                {
                                    list.repaint ( GeometryUtils.getContainingRect ( rects ) );
                                }
                            } );

                            // Clearing cells to update list
                            cellRects.clear ();
                        }
                        i++;
                    }
                }
            } );
            queueThread.start ();
        }
    }
}