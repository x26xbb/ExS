/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.filechooser;

import com.alee.extended.drag.FileDropHandler;
import com.alee.laf.tree.WebTree;

import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import java.awt.*;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;

/**
 * User: mgarin Date: 08.07.11 Time: 15:59
 */

public class WebFileTree extends WebTree
{
    private FileSystemTreeModel model;
    private FileSystemRenderer renderer;

    private boolean autoExpandSelectedPath = false;
    private boolean filesDropEnabled = true;

    public WebFileTree ()
    {
        this ( ( File ) null );
    }

    public WebFileTree ( String rootFilePath )
    {
        this ( new File ( rootFilePath ) );
    }

    public WebFileTree ( File rootFile )
    {
        this ( rootFile, true );
    }

    public WebFileTree ( boolean disksOnly )
    {
        this ( null, disksOnly );
    }

    public WebFileTree ( File rootFile, boolean disksOnly )
    {
        super ();

        setDropMode ( DropMode.ON );

        setEditable ( false );
        setRootVisible ( rootFile != null );
        setShowsRootHandles ( false );
        setSelectionMode ( TreeSelectionModel.SINGLE_TREE_SELECTION );
        setScrollsOnExpand ( true );

        // Files TransferHandler
        setTransferHandler ( new FileDropHandler ()
        {
            protected boolean isDropEnabled ()
            {
                return filesDropEnabled;
            }

            protected boolean filesImported ( List<File> files )
            {
                // Setting dragged files
                if ( files.size () > 0 )
                {
                    setSelectedFile ( files.get ( 0 ), true );
                    return true;
                }
                return false;
            }
        } );

        model = new FileSystemTreeModel ( rootFile, disksOnly );
        setModel ( model );

        renderer = new FileSystemRenderer ();
        setCellRenderer ( renderer );

        addTreeSelectionListener ( new TreeSelectionListener ()
        {
            public void valueChanged ( TreeSelectionEvent e )
            {
                if ( autoExpandSelectedPath && getSelectionCount () > 0 )
                {
                    WebFileTree.this.expandPath ( getSelectionPath () );
                }
            }
        } );
    }

    public boolean isAutoExpandSelectedPath ()
    {
        return autoExpandSelectedPath;
    }

    public void setAutoExpandSelectedPath ( boolean autoExpandSelectedPath )
    {
        this.autoExpandSelectedPath = autoExpandSelectedPath;
    }

    public boolean isFilesDropEnabled ()
    {
        return filesDropEnabled;
    }

    public void setFilesDropEnabled ( boolean filesDropEnabled )
    {
        this.filesDropEnabled = filesDropEnabled;
    }

    public void setRootName ( String rootName )
    {
        model.getRoot ().setSpecifiedName ( rootName );
    }

    public void setFileFilter ( FileFilter fileFilter )
    {
        model.setFileFilter ( fileFilter );
    }

    public FileFilter getFileFilter ()
    {
        return model.getFileFilter ();
    }

    public boolean isShowHiddenFiles ()
    {
        return model.isShowHiddenFiles ();
    }

    public void setShowHiddenFiles ( boolean showHiddenFiles )
    {
        model.setShowHiddenFiles ( showHiddenFiles );
    }

    public FileSystemTreeModel getModel ()
    {
        return model;
    }

    public void setSelectionMode ( int mode )
    {
        WebFileTree.this.getSelectionModel ().setSelectionMode ( mode );
    }

    public void setSelectedFile ( File file )
    {
        setSelectedFile ( file, false );
    }

    public void setSelectedFile ( File file, boolean expandFileNode )
    {
        clearSelection ();
        if ( file != null )
        {
            FileFilter filter = getFileFilter ();

            // Creating parent files list with ascending depth
            List<File> parents = new ArrayList<File> ();
            File parentFile = new File ( file.getAbsolutePath () );
            parents.add ( 0, parentFile );
            while ( parentFile.getParent () != null )
            {
                parentFile = parentFile.getParentFile ();
                parents.add ( 0, parentFile );
            }

            // Checking filtering
            if ( filter != null )
            {
                for ( int i = 0; i < parents.size (); i++ )
                {
                    if ( !filter.accept ( parents.get ( i ) ) )
                    {
                        // Removing all sublevels of unaccepted file
                        for ( int j = parents.size () - 1; j >= i; j-- )
                        {
                            parents.remove ( j );
                        }
                        break;
                    }
                }
            }

            // Expanding whole path
            FileSystemTreeModel model = getModel ();
            FileNode parent = null;
            while ( parents.size () > 0 )
            {
                // Creating sublevel node
                FileNode child = model.getFileNode ( parent, parents.get ( 0 ) );
                parents.remove ( 0 );

                // Selecting and expanding element
                TreePath path = new TreePath ( child.getPath () );
                if ( parents.size () == 0 )
                {
                    try
                    {
                        WebFileTree.this.setSelectionPath ( path );
                        WebFileTree.this.scrollPathToVisible ( path );

                        if ( expandFileNode )
                        {
                            // Expanding
                            WebFileTree.this.expandPath ( path );

                            // Scrolling view to node childs
                            Rectangle pathBounds = WebFileTree.this.getPathBounds ( path );
                            if ( pathBounds != null )
                            {
                                Rectangle vr = WebFileTree.this.getVisibleRect ();
                                Rectangle rect = new Rectangle ( vr.x, pathBounds.y, vr.width, vr.height );
                                WebFileTree.this.scrollRectToVisible ( rect );
                            }
                        }
                    }
                    catch ( Throwable e )
                    {
                        e.printStackTrace ();
                    }
                }
                else
                {
                    WebFileTree.this.expandPath ( path );
                }

                parent = child;
            }
        }
    }

    public File getSelectedFile ()
    {
        if ( getSelectionPath () != null )
        {
            return ( ( FileNode ) getSelectionPath ().getLastPathComponent () ).getFile ();
        }
        else
        {
            return null;
        }
    }

    public List<File> getSelectedFiles ()
    {
        List<File> selectedFiles = new ArrayList<File> ();
        if ( getSelectionPaths () != null )
        {
            for ( TreePath path : getSelectionPaths () )
            {
                selectedFiles.add ( ( ( FileNode ) path.getLastPathComponent () ).getFile () );
            }
        }
        return selectedFiles;
    }
}
