/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.layout;

import com.alee.laf.StyleConstants;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * User: mgarin Date: 14.10.11 Time: 13:01
 * <p/>
 * This layout allows you to quickly and easily place components in a toolbar-like components without overloading interface with lots of
 * panels and different layouts
 */

public class ToolbarLayout implements LayoutManager, SwingConstants
{
    // Positions component at the leading side of the container
    public static final String START = "START";
    // Positions component in the middle between leading and trailing sides
    public static final String MIDDLE = "MIDDLE";
    // Forces component to fill all the space left between leading and trailing sides
    public static final String FILL = "FILL";
    // Positions component at the trailing side of the container
    public static final String END = "END";

    // Additional object settings
    public static final String IGNORE_BORDER = "IGNORE_BORDER";

    // Saved layout constraints
    private Map<Component, String> constraints = new HashMap<Component, String> ();

    // Spacing between components
    private int spacing = StyleConstants.contentSpacing;

    // Spacing between left and right (top and bottom) layout parts
    private int partsSpacing = StyleConstants.largeContentSpacing;

    // Layout orientation
    private int orientation = HORIZONTAL;

    // Layout margin
    private Insets margin = null;

    /*
    * Some extended constructors
    */

    public ToolbarLayout ()
    {
        super ();
    }

    public ToolbarLayout ( int spacing )
    {
        super ();
        this.spacing = spacing;
    }

    public ToolbarLayout ( int spacing, int orientation )
    {
        super ();
        this.spacing = spacing;
        this.orientation = orientation;
    }

    public ToolbarLayout ( int spacing, int partsSpacing, int orientation )
    {
        super ();
        this.spacing = spacing;
        this.partsSpacing = partsSpacing;
        this.orientation = orientation;
    }

    /*
    * Layout constraints
    */

    public Map<Component, String> getConstraints ()
    {
        return constraints;
    }

    public void setConstraints ( Map<Component, String> constraints )
    {
        this.constraints = constraints;
    }

    /*
    * Layout cells spacing
    */

    public int getSpacing ()
    {
        return spacing;
    }

    public void setSpacing ( int spacing )
    {
        this.spacing = spacing;
    }

    /*
    * Start-end parts spacing
    * This one does not affect layout if there are any components in FILL part
    */

    public int getPartsSpacing ()
    {
        return partsSpacing;
    }

    public void setPartsSpacing ( int partsSpacing )
    {
        this.partsSpacing = partsSpacing;
    }

    /*
    * Layout orientation
    */

    public int getOrientation ()
    {
        return orientation;
    }

    public void setOrientation ( int orientation )
    {
        this.orientation = orientation;
    }

    /*
    * Layout sides margin
    * In case this value is null component border is taken into account instead
    */

    public Insets getMargin ()
    {
        return margin;
    }

    public void setMargin ( Insets margin )
    {
        this.margin = margin;
    }

    /*
    * Standard LayoutManager methods
    */

    public void addLayoutComponent ( String name, Component comp )
    {
        if ( name != null && !name.trim ().equals ( "" ) && !name.equals ( START ) &&
                !name.equals ( MIDDLE ) && !name.equals ( FILL ) && !name.equals ( END ) )
        {
            throw new IllegalArgumentException (
                    "Cannot add to layout: constraint must be null or an empty/'START'/'MIDDLE'/'FILL'/'END' string" );
        }
        constraints.put ( comp, name == null || name.trim ().equals ( "" ) ? START : name );
    }

    public void removeLayoutComponent ( Component comp )
    {
        constraints.remove ( comp );
    }

    public void layoutContainer ( Container parent )
    {
        Insets insets = margin == null ? parent.getInsets () : margin;
        if ( orientation == HORIZONTAL )
        {
            if ( parent.getComponentOrientation ().isLeftToRight () )
            {
                // LTR component orientation

                // Filling start with components
                int startX = insets.left;
                boolean first = true;
                for ( int i = 0; i < parent.getComponentCount (); i++ )
                {
                    Component component = parent.getComponent ( i );
                    if ( constraints.get ( component ) == null ||
                            constraints.get ( component ).trim ().equals ( "" ) ||
                            constraints.get ( component ).equals ( START ) )
                    {
                        boolean ignoresBorder = isIgnoresBorder ( component );
                        if ( first && ignoresBorder )
                        {
                            startX -= insets.left;
                        }
                        Dimension ps = component.getPreferredSize ();
                        component.setBounds ( startX, ignoresBorder ? 0 : insets.top, ps.width,
                                parent.getHeight () - ( ignoresBorder ? 0 : insets.top + insets.bottom ) );
                        startX += ps.width + spacing;
                        first = false;
                    }
                }

                // Filling end with components
                int endX = parent.getWidth () - insets.right;
                boolean last = true;
                if ( constraints.containsValue ( END ) )
                {
                    for ( int i = parent.getComponentCount () - 1; i >= 0; i-- )
                    {
                        Component component = parent.getComponent ( i );
                        if ( constraints.get ( component ) != null && constraints.get ( component ).equals ( END ) )
                        {
                            boolean ignoresBorder = isIgnoresBorder ( component );
                            if ( last && ignoresBorder )
                            {
                                endX += insets.right;
                            }
                            Dimension ps = component.getPreferredSize ();
                            endX -= ps.width;
                            component.setBounds ( endX, ignoresBorder ? 0 : insets.top, ps.width,
                                    parent.getHeight () - ( ignoresBorder ? 0 : insets.top + insets.bottom ) );
                            endX -= spacing;
                            last = false;
                        }
                    }
                }

                if ( endX > startX && ( constraints.containsValue ( MIDDLE ) || constraints.containsValue ( FILL ) ) )
                {
                    for ( Component component : parent.getComponents () )
                    {
                        if ( constraints.get ( component ) != null )
                        {
                            boolean ignoresBorder = isIgnoresBorder ( component );
                            if ( constraints.get ( component ).equals ( MIDDLE ) )
                            {
                                Dimension ps = component.getPreferredSize ();
                                component.setBounds ( Math.max ( startX, ( startX + endX ) / 2 - ps.width / 2 ),
                                        ignoresBorder ? 0 : insets.top, Math.min ( ps.width, endX - startX ),
                                        parent.getHeight () - ( ignoresBorder ? 0 : insets.top + insets.bottom ) );
                            }
                            else if ( constraints.get ( component ).equals ( FILL ) )
                            {
                                component.setBounds ( startX, ignoresBorder ? 0 : insets.top, Math.max ( 0, endX - startX ),
                                        parent.getHeight () - ( ignoresBorder ? 0 : insets.top + insets.bottom ) );
                            }
                        }
                    }
                }
            }
            else
            {
                // RTL component orientation

                // Filling start with components
                int startX = insets.left;
                boolean first = true;
                if ( constraints.containsValue ( END ) )
                {
                    for ( int i = parent.getComponentCount () - 1; i >= 0; i-- )
                    {
                        Component component = parent.getComponent ( i );
                        if ( constraints.get ( component ) != null && constraints.get ( component ).equals ( END ) )
                        {
                            boolean ignoresBorder = isIgnoresBorder ( component );
                            if ( first && ignoresBorder )
                            {
                                startX -= insets.left;
                            }
                            Dimension ps = component.getPreferredSize ();
                            component.setBounds ( startX, ignoresBorder ? 0 : insets.top, ps.width,
                                    parent.getHeight () - ( ignoresBorder ? 0 : insets.top + insets.bottom ) );
                            startX += ps.width + spacing;
                            first = false;
                        }
                    }
                }

                // Filling end with components
                int endX = parent.getWidth () - insets.right;
                boolean last = true;
                for ( int i = 0; i < parent.getComponentCount (); i++ )
                {
                    Component component = parent.getComponent ( i );
                    if ( constraints.get ( component ) == null ||
                            constraints.get ( component ).trim ().equals ( "" ) ||
                            constraints.get ( component ).equals ( START ) )
                    {
                        boolean ignoresBorder = isIgnoresBorder ( component );
                        if ( last && ignoresBorder )
                        {
                            endX += insets.right;
                        }
                        Dimension ps = component.getPreferredSize ();
                        endX -= ps.width;
                        component.setBounds ( endX, ignoresBorder ? 0 : insets.top, ps.width,
                                parent.getHeight () - ( ignoresBorder ? 0 : insets.top + insets.bottom ) );
                        endX -= spacing;
                        last = false;
                    }
                }

                if ( endX > startX && ( constraints.containsValue ( MIDDLE ) || constraints.containsValue ( FILL ) ) )
                {
                    for ( Component component : parent.getComponents () )
                    {
                        if ( constraints.get ( component ) != null )
                        {
                            boolean ignoresBorder = isIgnoresBorder ( component );
                            if ( constraints.get ( component ).equals ( MIDDLE ) )
                            {
                                Dimension ps = component.getPreferredSize ();
                                component.setBounds ( Math.max ( startX, ( startX + endX ) / 2 - ps.width / 2 ),
                                        ignoresBorder ? 0 : insets.top, Math.min ( ps.width, endX - startX ),
                                        parent.getHeight () - ( ignoresBorder ? 0 : insets.top + insets.bottom ) );
                            }
                            else if ( constraints.get ( component ).equals ( FILL ) )
                            {
                                component.setBounds ( startX, ignoresBorder ? 0 : insets.top, Math.max ( 0, endX - startX ),
                                        parent.getHeight () - ( ignoresBorder ? 0 : insets.top + insets.bottom ) );
                            }
                        }
                    }
                }
            }
        }
        else
        {
            // Filling start with components
            int startY = insets.top;
            boolean first = true;
            for ( int i = 0; i < parent.getComponentCount (); i++ )
            {
                Component component = parent.getComponent ( i );
                if ( constraints.get ( component ) == null || constraints.get ( component ).equals ( START ) )
                {
                    boolean ignoresBorder = isIgnoresBorder ( component );
                    if ( first && ignoresBorder )
                    {
                        startY -= insets.top;
                    }
                    Dimension ps = component.getPreferredSize ();
                    component.setBounds ( ignoresBorder ? 0 : insets.left, startY,
                            parent.getWidth () - ( ignoresBorder ? 0 : insets.left + insets.right ), ps.height );
                    startY += ps.height + spacing;
                    first = false;
                }
            }

            // Filling end with components
            int endY = parent.getHeight () - insets.bottom;
            boolean last = true;
            if ( constraints.containsValue ( END ) )
            {
                for ( int i = parent.getComponentCount () - 1; i >= 0; i-- )
                {
                    Component component = parent.getComponent ( i );
                    if ( constraints.get ( component ) != null && constraints.get ( component ).equals ( END ) )
                    {
                        boolean ignoresBorder = isIgnoresBorder ( component );
                        if ( last && ignoresBorder )
                        {
                            endY += insets.bottom;
                        }
                        Dimension ps = component.getPreferredSize ();
                        endY -= ps.height;
                        component.setBounds ( ignoresBorder ? 0 : insets.left, endY,
                                parent.getWidth () - ( ignoresBorder ? 0 : insets.left + insets.right ), ps.height );
                        endY -= spacing;
                        last = false;
                    }
                }
            }

            if ( endY > startY && ( constraints.containsValue ( MIDDLE ) || constraints.containsValue ( FILL ) ) )
            {
                for ( Component component : parent.getComponents () )
                {
                    if ( constraints.get ( component ) != null )
                    {
                        boolean ignoresBorder = isIgnoresBorder ( component );
                        if ( constraints.get ( component ).equals ( MIDDLE ) )
                        {
                            Dimension ps = component.getPreferredSize ();
                            component.setBounds ( ignoresBorder ? 0 : insets.left,
                                    Math.max ( startY, ( startY + endY ) / 2 - ps.height / 2 ),
                                    parent.getWidth () - ( ignoresBorder ? 0 : insets.left + insets.right ),
                                    Math.min ( ps.height, endY - startY ) );
                        }
                        else if ( constraints.get ( component ).equals ( FILL ) )
                        {
                            component.setBounds ( ignoresBorder ? 0 : insets.left, startY,
                                    parent.getWidth () - ( ignoresBorder ? 0 : insets.left + insets.right ),
                                    Math.max ( 0, endY - startY ) );
                        }
                    }
                }
            }
        }
    }

    public Dimension minimumLayoutSize ( Container parent )
    {
        return preferredLayoutSize ( parent );
    }

    public Dimension preferredLayoutSize ( Container parent )
    {
        Insets insets = margin == null ? parent.getInsets () : margin;
        Dimension ps = new Dimension ( insets.left + insets.right, insets.top + insets.bottom );
        int componentCount = parent.getComponentCount ();
        for ( int i = 0; i < componentCount; i++ )
        {
            Component component = parent.getComponent ( i );
            Dimension cps = component.getPreferredSize ();
            if ( orientation == HORIZONTAL )
            {
                ps.width += cps.width + ( i < componentCount - 1 ? spacing : 0 );
                ps.height = Math.max ( ps.height, cps.height + ( isIgnoresBorder ( component ) ? 0 : insets.top + insets.bottom ) );
            }
            else
            {
                ps.width = Math.max ( ps.width, cps.width + ( isIgnoresBorder ( component ) ? 0 : insets.left + insets.right ) );
                ps.height += cps.height + ( i < componentCount - 1 ? spacing : 0 );
            }
        }
        if ( orientation == HORIZONTAL )
        {
            // ps.height = insets.top + ps.height + insets.bottom;
            if ( constraints.containsValue ( END ) && !constraints.containsValue ( MIDDLE ) &&
                    !constraints.containsValue ( FILL ) )
            {
                ps.width += partsSpacing;
            }
        }
        else
        {
            // ps.width = insets.left + ps.width + insets.right;
            if ( constraints.containsValue ( END ) && !constraints.containsValue ( MIDDLE ) &&
                    !constraints.containsValue ( FILL ) )
            {
                ps.height += partsSpacing;
            }
        }
        return ps;
    }

    private boolean isIgnoresBorder ( Component component )
    {
        if ( component instanceof JComponent )
        {
            JComponent jComponent = ( JComponent ) component;
            Object property = jComponent.getClientProperty ( IGNORE_BORDER );
            if ( property != null && ( Boolean ) property )
            {
                return true;
            }
        }
        return false;
    }
}
