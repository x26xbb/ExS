/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.image;

import com.alee.laf.WebLookAndFeel;
import com.alee.utils.ImageUtils;
import com.alee.utils.LafUtils;
import com.alee.utils.SwingUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.net.URL;

/**
 * User: mgarin Date: 26.10.11 Time: 18:41
 * <p/>
 * This component allows you to display images (without any text unlike JLabel) in many different ways. Also it wastes much less resources
 * than a JLabel due to text part exclusion.
 */

public class WebImage extends JComponent implements SwingConstants
{
    private BufferedImage image;
    private BufferedImage disabledImage;

    private DisplayType displayType;
    private int horizontalAlignment;
    private int verticalAlignment;
    private float transprency;

    public WebImage ()
    {
        this ( ( Image ) null );
    }

    public WebImage ( String src )
    {
        this ( ImageUtils.loadImage ( src ) );
    }

    public WebImage ( Class nearClass, String src )
    {
        this ( ImageUtils.loadImage ( nearClass, src ) );
    }

    public WebImage ( URL url )
    {
        this ( ImageUtils.loadImage ( url ) );
    }

    public WebImage ( ImageIcon icon )
    {
        this ( icon.getImage () );
    }

    public WebImage ( Image image )
    {
        this ( ImageUtils.getBufferedImage ( image ) );
    }

    public WebImage ( BufferedImage image )
    {
        super ();

        this.image = image;
        this.disabledImage = null;

        this.displayType = DisplayType.fitImage;
        this.horizontalAlignment = CENTER;
        this.verticalAlignment = CENTER;
        this.transprency = 1f;

        SwingUtils.setOrientation ( this );
        setOpaque ( false );

        addPropertyChangeListener ( WebLookAndFeel.COMPONENT_ENABLED_PROPERTY, new PropertyChangeListener ()
        {
            public void propertyChange ( PropertyChangeEvent evt )
            {
                if ( !isEnabled () )
                {
                    disabledImage = ImageUtils.createDisabledCopy ( WebImage.this.image );
                    lastPreviewImage = null;
                    repaint ();
                }
                else if ( disabledImage != null )
                {
                    disabledImage.flush ();
                    disabledImage = null;
                    lastPreviewImage = null;
                    repaint ();
                }
            }
        } );
    }

    public int getImageWidth ()
    {
        return image != null ? image.getWidth () : -1;
    }

    public int getImageHeight ()
    {
        return image != null ? image.getHeight () : -1;
    }

    public BufferedImage getImage ()
    {
        return image;
    }

    public void setIcon ( ImageIcon icon )
    {
        setImage ( icon.getImage () );
    }

    public void setImage ( Image image )
    {
        setImage ( ImageUtils.getBufferedImage ( image ) );
    }

    public void setImage ( BufferedImage image )
    {
        this.image = image;
        revalidate ();
        repaint ();
    }

    public DisplayType getDisplayType ()
    {
        return displayType;
    }

    public void setDisplayType ( DisplayType displayType )
    {
        this.displayType = displayType;
        updateView ();
    }

    public int getHorizontalAlignment ()
    {
        return horizontalAlignment;
    }

    public void setHorizontalAlignment ( int horizontalAlignment )
    {
        this.horizontalAlignment = horizontalAlignment;
        updateView ();
    }

    public int getVerticalAlignment ()
    {
        return verticalAlignment;
    }

    public void setVerticalAlignment ( int verticalAlignment )
    {
        this.verticalAlignment = verticalAlignment;
        updateView ();
    }

    public float getTransprency ()
    {
        return transprency;
    }

    public void setTransprency ( float transprency )
    {
        this.transprency = transprency;
        updateView ();
    }

    private void updateView ()
    {
        if ( isShowing () )
        {
            repaint ();
        }
    }

    protected void paintComponent ( Graphics g )
    {
        super.paintComponent ( g );

        if ( transprency <= 0f )
        {
            return;
        }

        Graphics2D g2d = ( Graphics2D ) g;
        Composite oc = LafUtils.setupAlphaComposite ( g2d, transprency, transprency < 1f );

        // todo Optimize for repaint (check if image is out of repainted/clipped bounds)
        BufferedImage currentImage = getCurrentImage ();
        if ( currentImage != null )
        {
            Insets insets = getInsets ();
            switch ( displayType )
            {
                case fitImage:
                {
                    // Drawing preferred sized image at specified side
                    int x = horizontalAlignment == LEFT ? insets.left :
                            ( horizontalAlignment == RIGHT ? getWidth () - currentImage.getWidth () - insets.right :
                                    getWidth () / 2 - currentImage.getWidth () / 2 );
                    int y = verticalAlignment == TOP ? insets.top :
                            ( verticalAlignment == BOTTOM ? getHeight () - currentImage.getHeight () - insets.bottom :
                                    getHeight () / 2 - currentImage.getHeight () / 2 );
                    g2d.drawImage ( currentImage, x, y, null );
                    break;
                }
                case fitComponent:
                {
                    // Drawing sized to fit object image
                    BufferedImage preview = getPreviewImage ();
                    g2d.drawImage ( preview, getWidth () / 2 - preview.getWidth () / 2, getHeight () / 2 - preview.getHeight () / 2, null );
                    break;
                }
                case repeat:
                {
                    // Drawing repeated in background image
                    int x = horizontalAlignment == LEFT ? insets.left :
                            ( horizontalAlignment == RIGHT ? getWidth () - currentImage.getWidth () - insets.right :
                                    getWidth () / 2 - currentImage.getWidth () / 2 );
                    int y = verticalAlignment == TOP ? insets.top :
                            ( verticalAlignment == BOTTOM ? getHeight () - currentImage.getHeight () - insets.bottom :
                                    getHeight () / 2 - currentImage.getHeight () / 2 );
                    g2d.setPaint ( new TexturePaint ( currentImage,
                            new Rectangle2D.Double ( x, y, currentImage.getWidth (), currentImage.getHeight () ) ) );
                    g2d.fillRect ( insets.left, insets.top, getWidth () - insets.left - insets.right,
                            getHeight () - insets.top - insets.bottom );
                    break;
                }
            }
        }

        LafUtils.restoreComposite ( g2d, oc, transprency < 1f );
    }

    private Dimension lastDimention = null;
    private BufferedImage lastPreviewImage = null;

    private BufferedImage getPreviewImage ()
    {
        if ( image.getWidth () > getWidth () || image.getHeight () > getHeight () )
        {
            if ( lastPreviewImage == null || lastDimention != null && !lastDimention.equals ( getSize () ) )
            {
                if ( lastPreviewImage != null )
                {
                    lastPreviewImage.flush ();
                    lastPreviewImage = null;
                }
                lastPreviewImage = ImageUtils.createPreviewImage ( getCurrentImage (), getSize () );
                lastDimention = getSize ();
            }
            return lastPreviewImage;
        }
        else
        {
            return image;
        }
    }

    private BufferedImage getCurrentImage ()
    {
        return !isEnabled () && disabledImage != null ? disabledImage : image;
    }

    public Dimension getPreferredSize ()
    {
        if ( !isPreferredSizeSet () )
        {
            Insets insets = getInsets ();
            return new Dimension ( insets.left + ( image != null ? image.getWidth () : 0 ) + insets.right,
                    insets.top + ( image != null ? image.getHeight () : 0 ) + insets.bottom );
        }
        else
        {
            return super.getPreferredSize ();
        }
    }
}
