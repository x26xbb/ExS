/*
 * This file is part of WebLookAndFeel library.
 *
 * WebLookAndFeel library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * WebLookAndFeel library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebLookAndFeel library.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.alee.extended.button;

import com.alee.laf.StyleConstants;
import com.alee.laf.label.WebLabel;
import com.alee.laf.panel.WebPanel;
import com.alee.utils.SwingUtils;
import com.alee.utils.swing.Timer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * User: mgarin Date: 02.11.12 Time: 14:07
 */

public class WebSwitch extends WebPanel
{
    private boolean selected = false;

    private boolean sliding = false;

    private WebSwitchGripper gripper;
    private WebLabel leftComponent;
    private WebLabel rightComponent;

    private Timer animator;

    public WebSwitch ()
    {
        super ( true, new WebSwitchLayout () );
        setRound ( StyleConstants.round );
        setDrawFocus ( true );
        setFocusable ( true );

        gripper = new WebSwitchGripper ();
        add ( gripper, WebSwitchLayout.GRIPPER );

        leftComponent = new WebLabel ( "ON", WebLabel.CENTER );
        leftComponent.setMargin ( 2, 5, 2, 5 );
        leftComponent.setDrawShade ( true );
        leftComponent.setForeground ( Color.DARK_GRAY );
        add ( SwingUtils.setBoldFont ( leftComponent ), WebSwitchLayout.LEFT );

        rightComponent = new WebLabel ( "OFF", WebLabel.CENTER );
        rightComponent.setMargin ( 2, 5, 2, 5 );
        rightComponent.setDrawShade ( true );
        rightComponent.setForeground ( Color.DARK_GRAY );
        add ( SwingUtils.setBoldFont ( rightComponent ), WebSwitchLayout.RIGHT );

        animator = new Timer ( "WebSwitch.animator", StyleConstants.maxAnimationDelay, new ActionListener ()
        {
            public void actionPerformed ( ActionEvent e )
            {
                // Updating gripper location
                WebSwitchLayout switchLayout = getSwitchLayout ();
                switchLayout.setGripperLocation ( switchLayout.getGripperLocation () + ( selected ? 0.05f : -0.05f ) );

                // Checking what to do
                if ( selected && switchLayout.getGripperLocation () >= 1f || !selected && switchLayout.getGripperLocation () <= 0f )
                {
                    // Updating final gripper and view
                    switchLayout.setGripperLocation ( selected ? 1f : 0f );
                    revalidate ();

                    // Finishing animation
                    sliding = false;
                    animator.stop ();
                }
                else
                {
                    // Updating view
                    revalidate ();
                }
            }
        } );

        MouseAdapter mouseAdapter = new MouseAdapter ()
        {
            public void mousePressed ( MouseEvent e )
            {
                selected = !selected;
                if ( !sliding )
                {
                    sliding = true;
                    animator.start ();
                }
            }
        };
        gripper.addMouseListener ( mouseAdapter );
        addMouseListener ( mouseAdapter );
    }

    public WebSwitchLayout getSwitchLayout ()
    {
        return ( WebSwitchLayout ) getLayout ();
    }

    public WebSwitchGripper getGripper ()
    {
        return gripper;
    }

    public WebLabel getLeftComponent ()
    {
        return leftComponent;
    }

    public void setLeftComponent ( WebLabel leftComponent )
    {
        if ( this.leftComponent != null )
        {
            remove ( this.leftComponent );
        }
        this.leftComponent = leftComponent;
        add ( leftComponent, WebSwitchLayout.LEFT );
        revalidate ();
    }

    public WebLabel getRightComponent ()
    {
        return rightComponent;
    }

    public void setRightComponent ( WebLabel rightComponent )
    {
        if ( this.rightComponent != null )
        {
            remove ( this.rightComponent );
        }
        this.rightComponent = rightComponent;
        add ( rightComponent, WebSwitchLayout.RIGHT );
        revalidate ();
    }
}
